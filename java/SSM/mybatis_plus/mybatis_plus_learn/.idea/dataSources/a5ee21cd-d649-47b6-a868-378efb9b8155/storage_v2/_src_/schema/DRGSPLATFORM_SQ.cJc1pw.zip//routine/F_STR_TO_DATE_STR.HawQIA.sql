create function F_STR_TO_DATE_STR(str in varchar2) return varchar2 is
result varchar2(10);
v_date date;
begin
  CASE

    WHEN NOT regexp_like(str,'^[1-9][0-9]{3}[-|.|/]?((1[0-2])|(0?[1-9]))[-|.|/]?(([1-2][0-9])|(3[0-1])|(0?[1-9]))(|\s?(20|21|22|23|[0-1][0-9]):[0-5][0-9]:[0-5][0-9])(.[0-9]{3})?$')
      THEN
         case
           when regexp_like(str,'^[1-9][0-9]*\.[0-9]*$')
              then return TO_CHAR(to_date('1900/01/01','yyyy/mm/dd')+ to_number(SUBSTR(str,0,INSTR(str,'.',1,1)-1))-2,'yyyy/mm/dd');
           when regexp_like(str,'^[1-9][0-9]{7}')
                then return to_char(to_date(regexp_substr(str,'^[1-9][0-9]{7}'),'yyyyMMdd'),'yyyy/mm/dd');
           else return to_char(to_date(str,'MM/dd/yy HH24:mi:ss'),'yyyy/mm/dd');
         end case;
    WHEN INSTR(str,'/') > 0 AND length(str)-length(replace(str, '/', ''))=2
      THEN
        result := SUBSTR(str,0,INSTR(str,'/',1,1)-1)|| '-' ||
          replace(lpad(SUBSTR(str,INSTR(str,'/',1,1)+1,LENGTH(str)-INSTR(str,'/',1,2)),2),' ','0')|| '-' ||
          replace(lpad(SUBSTR(str,INSTR(str,'/',1,2)+1),2),' ','0');
    WHEN INSTR(str,'-') > 0 AND length(str)-length(replace(str, '-', ''))=2
      THEN
        result := SUBSTR(str,0,INSTR(str,'-',1,1)-1)|| '-' ||
          replace(lpad(SUBSTR(str,INSTR(str,'-',1,1)+1,LENGTH(str)-INSTR(str,'-',1,2)),2),' ','0')|| '-' ||
          replace(lpad(SUBSTR(str,INSTR(str,'-',1,2)+1),2),' ','0');
    WHEN INSTR(str,'.') > 0 AND length(str)-length(replace(str, '.', ''))=2
      THEN
        result := SUBSTR(str,0,INSTR(str,'.',1,1)-1)|| '-' ||
          replace(lpad(SUBSTR(str,INSTR(str,'.',1,1)+1,LENGTH(str)-INSTR(str,'.',1,2)),2),' ','0')|| '-' ||
          replace(lpad(SUBSTR(str,INSTR(str,'.',1,2)+1),2),' ','0');
    WHEN regexp_like(str,'^[1-9][0-9]{7}$')
      THEN
        result := SUBSTR(str,0,4)|| '-' ||
          replace(lpad(SUBSTR(str,5,2),2),' ','0')|| '-' ||
          replace(lpad(SUBSTR(str,7),2),' ','0');
    ELSE
          case
           when regexp_like(str,'^[1-9][0-9]*\.[0-9]*$')
                then return TO_CHAR(to_date('1900/01/01','yyyy/mm/dd')+ to_number(SUBSTR(str,0,INSTR(str,'.',1,1)-1))-2,'yyyy/mm/dd');
           when regexp_like(str,'^[1-9][0-9]{7}')
                then return to_char(to_date(regexp_substr(str,'^[1-9][0-9]{7}'),'yyyyMMdd'),'yyyy/mm/dd');
          else return str;
          end case;
  END CASE;
  --v_date :=to_date(result,'yyyy-MM-dd');
  return result;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
end F_STR_TO_DATE_STR;


/

