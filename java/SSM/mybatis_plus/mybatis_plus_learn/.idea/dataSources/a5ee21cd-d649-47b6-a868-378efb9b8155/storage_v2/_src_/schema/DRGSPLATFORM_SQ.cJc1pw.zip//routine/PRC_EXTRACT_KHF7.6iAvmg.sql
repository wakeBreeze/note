create procedure PRC_EXTRACT_KHF7(prm_bke930 IN VARCHAR2, --抽取时间
                                             ExtractNum OUT NUMBER,
                                             AppCode    OUT VARCHAR2,
                                             ErrorMsg   OUT VARCHAR2) is
  v_insert_num  NUMBER;
  v_insert_num1 NUMBER;
  v_insert_num2 NUMBER;

BEGIN
 insert into khf7
  (AAZ955, AKB020, AAE002, BKEL11, BKF428, bkf440, BKF532)

  SELECT SE_AAZ955.nextval, akb020, aae002, bkel11, bkf428, bkf440, bkf531 as bkf532
    from (select akb020,
                 aae002,
                 bkf440,
                 bkf531,
                 aka130,
                 sum(bkel11) bkel11,
                 sum(bkf428) as bkf428
            from (select akb020,
                         aae002,
                         bkel11,
                         bkf428,
                         bkf440,
                         bkf531,
                         case
                           when aka130 in ('11', '21', '13') then
                            aka130
                           when aka130 = '22' then
                            '21'
                           when aka130 = '28' then
                            '27'
                           when aka130 in ('52', '5302') then
                            '59'
                           when aka130 in ('51', '5301') then
                            '11'
                           when aka130 = '1401' then
                            '14'
                           when aka130 = '1402' then
                            '15'
                           when aka130 in ('24') then
                            '13'
                           when aka130 in ('2302', '24') then
                            '24'

                           when aka130 in ('4101', '4102') then
                            '12'
                           when aka130 = '8802' then
                            '141'
                           when aka130 in ('9904', '9907') then
                            '16'
                           when aka130 in ('9908') then
                            '19'

                         end as aka130
                    from (select b.akb020,
                                 to_char(a.updt_time, 'yyyyMM') as AAE002,
                                 count(1) as BKEL11,
                                 sum(nvl(HIFP_PAY, 0)) as BKF428,
                                 CASE
                                   WHEN insutype = '390' THEN
                                    '16'
                                   ELSE
                                    '11'
                                 END BKF440,
                                 MED_TYPE as aka130,
                                 '2' as bkf531
                            from data_sync.outmed_setl_d a
                            left join kb01 b
                              on a.FIXMEDINS_CODE = b.bkf498
                           where b.akb020 is not null
                           and a.REFD_SETL_FLAG = '0'
                           AND a.VALI_FLAG = '1'
                           and to_char(a.updt_time, 'yyyyMM')= prm_bke930
                           group by b.akb020,
                                    to_char(a.updt_time, 'yyyyMM'),
                                    insutype,
                                    MED_TYPE))
           group by akb020, aae002, bkf440, bkf531, aka130);
           v_insert_num := SQL%ROWCOUNT;

  insert into khf7
  (AAZ955, AKB020, AAE002, BKEL11, BKF428, bkf440, BKF532)
  SELECT SE_AAZ955.nextval, akb020, aae002, bkel11, bkf428, bkf440, bkf531 as bkf532
  from (select akb020,
               aae002,
               bkf440,
               bkf531,
               aka130,
               sum(bkel11) bkel11,
               sum(bkf428) as bkf428
          from (select akb020,
                       aae002,
                       bkel11,
                       bkf428,
                       bkf440,
                       bkf531,
                       case
                         when aka130 in ('11', '21', '13') then
                          aka130
                         when aka130 = '22' then
                          '21'
                         when aka130 = '28' then
                          '27'
                         when aka130 in ('52', '5302') then
                          '59'
                         when aka130 in ('51', '5301') then
                          '11'
                         when aka130 = '1401' then
                          '14'
                         when aka130 = '1402' then
                          '15'
                         when aka130 in ('24') then
                          '13'
                         when aka130 in ('2302', '2301') then
                          '24'

                         when aka130 in ('4101', '4102') then
                          '12'
                         when aka130 = '9903' then
                          '141'
                         when aka130 in ('9904', '9907') then
                          '16'
                         when aka130 in ('9908') then
                          '19'

                       end as aka130
                  from (select b.akb020,
                               to_char(a.updt_time, 'yyyyMM') as AAE002,
                               count(1) as BKEL11,
                               sum(nvl(HIFP_PAY, 0)) as BKF428,
                               CASE
                                 WHEN insutype = '390' THEN
                                  '16'
                                 ELSE
                                  '11'
                               END BKF440,
                               MED_TYPE as aka130,
                               '1' as bkf531
                          from data_sync.SETL_D_OUTPATIENT a
                          left join kb01 b
                            on a.FIXMEDINS_CODE = b.bkf498
                         where b.akb020 is not null
                           and a.pay_loc = '2'
                           and a.REFD_SETL_FLAG = '0'
                           AND a.VALI_FLAG = '1'
                           and to_char(a.updt_time, 'yyyyMM')=prm_bke930
                         group by b.akb020,
                                  to_char(a.updt_time, 'yyyyMM'),
                                  insutype,
                                  MED_TYPE))
         group by akb020, aae002, bkf440, bkf531, aka130);
         v_insert_num1 := SQL%ROWCOUNT;

insert into khf7
  (AAZ955, AKB020, AAE002, BKEL11, BKF428, bkf440, BKF532)
  SELECT SE_AAZ955.nextval, akb020, aae002, bkel11, bkf428, bkf440, bkf531 as bkf532
  from (select akb020,
               aae002,
               bkf440,
               bkf531,
               aka130,
               sum(bkel11) bkel11,
               sum(bkf428) as bkf428
          from (select akb020,
                       aae002,
                       bkel11,
                       bkf428,
                       bkf440,
                       bkf531,
                       case
                         when aka130 in ('11', '21', '13') then
                          aka130
                         when aka130 = '22' then
                          '21'
                         when aka130 = '28' then
                          '27'
                         when aka130 in ('52', '5302') then
                          '59'
                         when aka130 in ('51', '5301') then
                          '11'
                         when aka130 = '1401' then
                          '14'
                         when aka130 = '1402' then
                          '15'
                         when aka130 in ('24') then
                          '13'
                         when aka130 in ('2302', '2301') then
                          '24'

                         when aka130 in ('4101', '4102') then
                          '12'
                         when aka130 = '9903' then
                          '141'
                         when aka130 in ('9904', '9907') then
                          '16'
                         when aka130 in ('9908') then
                          '19'

                       end as aka130
                  from (select b.akb020,
                               to_char(a.updt_time, 'yyyyMM') as AAE002,
                               count(1) as BKEL11,
                               sum(nvl(HIFP_PAY, 0)) as BKF428,
                               CASE
                                 WHEN insutype = '390' THEN
                                  '16'
                                 ELSE
                                  '11'
                               END BKF440,
                               MED_TYPE as aka130,
                               '1' as bkf531
                          from data_sync.SETL_D_hosp a
                          left join kb01 b
                            on a.FIXMEDINS_CODE = b.bkf498
                         where b.akb020 is not null
                           and a.pay_loc = '2'
                           and a.REFD_SETL_FLAG = '0'
                           AND a.VALI_FLAG = '1'
                           and to_char(a.updt_time, 'yyyyMM')=prm_bke930
                         group by b.akb020,
                                  to_char(a.updt_time, 'yyyyMM'),
                                  insutype,
                                  MED_TYPE))
         group by akb020, aae002, bkf440, bkf531, aka130);
          v_insert_num2 := SQL%ROWCOUNT;
          ExtractNum    := (v_insert_num + v_insert_num1+v_insert_num2);
          AppCode       :=1;

EXCEPTION
  WHEN OTHERS THEN
    AppCode  := pkg_comm.def_err;
    ErrorMsg := '抽取表KHF7有误：' || SQLERRM;
    commit;
end PRC_EXTRACT_KHF7;
/

