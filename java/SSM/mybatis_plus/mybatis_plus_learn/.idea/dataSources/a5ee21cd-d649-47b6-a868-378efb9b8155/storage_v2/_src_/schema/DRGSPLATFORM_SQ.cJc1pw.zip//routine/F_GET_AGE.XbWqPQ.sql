create FUNCTION f_get_age(param_akc023 NUMBER, -- 年龄
                                     param_ake304 NUMBER, -- (年龄不足1周岁的)年龄(月)
                                     param_ake305 NUMBER, -- 新生儿出生体重(克)
                                     param_ake306 NUMBER -- 新生儿入院体重(克）
)
return VARCHAR2
AS
       v_age VARCHAR2(10);
BEGIN
  /**
       年龄字段为不空情况：
                           1、1-3岁 ---> C
                           2、4-6岁 ---> D
                           3、7-12岁 ---> E
                           4、13-17岁 ---> F
                           5、18-65岁 ---> G
                           6、66-72岁 ---> H
                           7、73-84岁 ---> I
                           8、85岁以上 ---> J
        年龄字段为空情况：
                           新生儿体重为空：G（18-65岁）
                           新生儿体重不为空：
                                            新生儿月龄为空： B（29天-1岁）
                                            新生儿月龄不为空：
                                                              1、为0：A（0天-28天）
                                                              2、不为0：B（29天-1岁）


  */
  IF param_akc023 IS NOT NULL THEN
    IF param_akc023 >= 1 AND param_akc023 <= 3 THEN
      v_age := 'C';
    ELSIF param_akc023 >= 4 AND param_akc023 <= 6 THEN
      v_age := 'D';
    ELSIF param_akc023 >= 7 AND param_akc023 <= 12 THEN
      v_age := 'E';
    ELSIF param_akc023 >= 13 AND param_akc023 <= 17 THEN
      v_age := 'F';
    ELSIF param_akc023 >= 18 AND param_akc023 <= 65 THEN
      v_age := 'G';
    ELSIF param_akc023 >= 66 AND param_akc023 <= 72 THEN
      v_age := 'H';
    ELSIF param_akc023 >= 73 AND param_akc023 <= 84 THEN
      v_age := 'I';
    ELSE
      v_age := 'J';
    END IF;
  ELSE
    IF param_ake305 IS NOT NULL AND param_ake306 IS NOT NULL THEN
      IF param_ake304 IS NOT NULL THEN
        IF param_ake304 = 0 THEN
          v_age := 'A';
        ELSE
          v_age := 'B';
        END IF;
      ELSE
         v_age := 'B';
      END IF;
    ELSE
       v_age := 'G';
    END IF;
  END IF;

  RETURN v_age;
end f_get_age;


/

