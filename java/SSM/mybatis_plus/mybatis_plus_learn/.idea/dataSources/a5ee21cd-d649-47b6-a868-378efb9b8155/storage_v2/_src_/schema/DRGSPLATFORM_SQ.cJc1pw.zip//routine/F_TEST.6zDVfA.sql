create procedure f_test
AS
      v_bke139 NUMBER(16);
      CURSOR cur_codes IS
      SELECT akb020 FROM kec1_2020 GROUP BY akb020;
BEGIN
      FOR c IN cur_codes LOOP
        SELECT se_bke139.nextval INTO v_bke139 FROM dual;
        UPDATE kec1_2020 SET bke139 = v_bke139 WHERE akb020 = c.akb020;
      END LOOP;

end f_test;


/

