create FUNCTION f_genera_operation_name (
    param_operation_code IN VARCHAR
)
RETURN VARCHAR
AS
    TYPE ref_cursor_type IS REF CURSOR;
    v_cur_codes  ref_cursor_type;
    v_code VARCHAR2(1000);
    v_temp_code VARCHAR2(1000);
    v_operation_name VARCHAR(1000);
BEGIN
    -- 获取手术编码
    open v_cur_codes for SELECT regexp_substr(param_operation_code,'[^-]+',1,ROWNUM) AS operation_code FROM dual
      CONNECT BY ROWNUM <= LENGTH(param_operation_code)-LENGTH(REPLACE(param_operation_code,'-','')) + 1;
    loop
        fetch v_cur_codes into v_code;
        exit when v_cur_codes%notfound;
        SELECT bke740 INTO v_temp_code FROM kac4 WHERE bke734 = 'ICD-9' AND bke731 = '10' AND bke739 = v_code;
        IF v_operation_name IS NULL THEN
          v_operation_name := v_temp_code;
        ELSE
          IF v_temp_code IS NULL THEN
            v_operation_name := CONCAT(CONCAT(v_operation_name,'NULL'),v_temp_code);
          ELSE 
            v_operation_name := CONCAT(CONCAT(v_operation_name,'/'),v_temp_code);
          END IF;
        END IF;

    end loop;
    close v_cur_codes;
    -- 返回手术名称
    RETURN v_operation_name;
END;


/

