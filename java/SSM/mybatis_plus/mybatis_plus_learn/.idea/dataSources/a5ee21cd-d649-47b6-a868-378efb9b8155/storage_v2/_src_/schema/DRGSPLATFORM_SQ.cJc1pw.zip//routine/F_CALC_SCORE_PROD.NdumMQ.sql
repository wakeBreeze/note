create FUNCTION                 f_calc_score_prod(prm_drgs IN NUMBER,
                                             prm_cmi IN NUMBER,
                                             prm_cmi_avg IN NUMBER,
                                             prm_drgs_avg IN NUMBER,
                                             ld_score OUT NUMBER
                                             ) RETURN NUMBER AS
  ld_score_diag number (12, 4) ; -- 诊疗得分
  ld_tech_score number (12, 4) ; -- 技术得分
BEGIN
  /*
    产能得分 =（诊疗范围分数 * 技术难度分数）开方
    诊疗范围分数 = 某医院DRG组数除以各医院DRG组数平均值
    技术难度分数 = 某医院CMI除以各医院CMI均值
 */
  ld_score_diag := round(prm_drgs/prm_drgs_avg,4);
  ld_tech_score := ROUND(prm_cmi/prm_cmi_avg,4);
  ld_score :=round(sqrt(ld_score_diag*ld_tech_score),4);
   return ld_score;
END;


/

