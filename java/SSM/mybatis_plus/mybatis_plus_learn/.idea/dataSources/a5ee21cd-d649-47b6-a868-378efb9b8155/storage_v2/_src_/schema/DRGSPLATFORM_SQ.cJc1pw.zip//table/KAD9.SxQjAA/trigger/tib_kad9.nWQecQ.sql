create trigger "tib_kad9"
    before insert
    on KAD9
    for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
    dummy            integer;
    found            boolean;

begin
    --  Column "BKEA76" uses sequence SE_BKEA76
    select SE_BKEA76.NEXTVAL INTO :new.BKEA76 from dual;
    --  Column "BKEA70" uses sequence SE_BKEA70
    select SE_BKEA70.NEXTVAL INTO :new.BKEA70 from dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;


/

