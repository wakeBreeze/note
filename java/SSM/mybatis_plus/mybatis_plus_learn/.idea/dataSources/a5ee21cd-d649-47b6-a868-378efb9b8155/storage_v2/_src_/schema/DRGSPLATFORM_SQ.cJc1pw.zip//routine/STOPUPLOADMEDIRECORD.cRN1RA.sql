create procedure stopUploadMediRecord is
begin
  update wske01 set wsaae100 = '0';
end;
/

