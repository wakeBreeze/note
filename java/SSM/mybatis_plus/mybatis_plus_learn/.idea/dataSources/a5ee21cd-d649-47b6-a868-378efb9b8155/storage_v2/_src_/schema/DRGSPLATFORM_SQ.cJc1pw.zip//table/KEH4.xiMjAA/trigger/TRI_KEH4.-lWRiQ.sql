create trigger TRI_KEH4
    before insert
    on KEH4
    for each row
    when (new.AAZ796 is null)
begin
select SE_AAZ796.nextval into :new.AAZ796 from dual;
end;


/

