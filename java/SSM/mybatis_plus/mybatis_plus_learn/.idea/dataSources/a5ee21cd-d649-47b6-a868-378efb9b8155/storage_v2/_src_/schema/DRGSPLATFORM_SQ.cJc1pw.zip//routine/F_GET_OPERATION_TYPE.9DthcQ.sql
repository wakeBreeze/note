create FUNCTION f_get_operation_type(AKE394    in VARCHAR2,
                                                AKE405    in VARCHAR2,
                                                AKE416    IN VARCHAR2,
                                                AKE427    IN VARCHAR2,
                                                AKE438    IN VARCHAR2,
                                                AKE449    IN VARCHAR2,
                                                AKE460    IN VARCHAR2
                                                )
/**
     获取手术类型
  
  */
 return VARCHAR2 as
  v_count          VARCHAR2(100);
  v_operation_code VARCHAR2(100);
BEGIN
  -- 编码1
  IF AKE394 IS NOT NULL AND ake394 NOT LIKE '%-%' THEN
    v_operation_code := ake394;
    SELECT count(1)
      INTO V_COUNT
      FROM kac4
     where bke731 = '10'
       and bke734 = 'ICD-9'
       and bkf305 in ('0', '3')
       and bke739 = v_operation_code;
    IF V_COUNT > 0 THEN
      RETURN '1';
    END IF;
  END IF;
  -- 编码2
  IF AKE405 IS NOT NULL AND AKE405 NOT LIKE '%-%' THEN
    v_operation_code := AKE405;
    SELECT count(1)
      INTO V_COUNT
      FROM kac4
     where bke731 = '10'
       and bke734 = 'ICD-9'
       and bkf305 in ('0', '3')
       and bke739 = v_operation_code;
    IF V_COUNT > 0 THEN
      RETURN '1';
    END IF;
  END IF;

  -- 编码3
  IF AKE416 IS NOT NULL AND AKE416 NOT LIKE '%-%' THEN
    v_operation_code := AKE416;
    SELECT count(1)
      INTO V_COUNT
      FROM kac4
     where bke731 = '10'
       and bke734 = 'ICD-9'
       and bkf305 in ('0', '3')
       and bke739 = v_operation_code;
    IF V_COUNT > 0 THEN
      RETURN '1';
    END IF;
  END IF;

  -- 编码4
  IF AKE427 IS NOT NULL AND AKE427 NOT LIKE '%-%' THEN
    v_operation_code := AKE427;
    SELECT count(1)
      INTO V_COUNT
      FROM kac4
     where bke731 = '10'
       and bke734 = 'ICD-9'
       and bkf305 in ('0', '3')
       and bke739 = v_operation_code;
    IF V_COUNT > 0 THEN
      RETURN '1';
    END IF;
  END IF;

  -- 编码5
  IF AKE438 IS NOT NULL AND AKE438 NOT LIKE '%-%' THEN
    v_operation_code := AKE438;
    SELECT count(1)
      INTO V_COUNT
      FROM kac4
     where bke731 = '10'
       and bke734 = 'ICD-9'
       and bkf305 in ('0', '3')
       and bke739 = v_operation_code;
    IF V_COUNT > 0 THEN
      RETURN '1';
    END IF;
  END IF;

  -- 编码6
  IF AKE449 IS NOT NULL AND AKE449 NOT LIKE '%-%' THEN
    v_operation_code := AKE449;
    SELECT count(1)
      INTO V_COUNT
      FROM kac4
     where bke731 = '10'
       and bke734 = 'ICD-9'
       and bkf305 in ('0', '3')
       and bke739 = v_operation_code;
    IF V_COUNT > 0 THEN
      RETURN '1';
    END IF;
  END IF;

  -- 编码7
  IF AKE460 IS NOT NULL AND AKE460 NOT LIKE '%-%' THEN
    v_operation_code := AKE460;
    SELECT count(1)
      INTO V_COUNT
      FROM kac4
     where bke731 = '10'
       and bke734 = 'ICD-9'
       and bkf305 in ('0', '3')
       and bke739 = v_operation_code;
    IF V_COUNT > 0 THEN
      RETURN '1';
    END IF;
  END IF;
  RETURN '0';
end f_get_operation_type;
/

