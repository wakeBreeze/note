create procedure PRC_EXTRACT_KHG9(prm_bke930 IN VARCHAR2, --抽取时间
                                             ExtractNum OUT NUMBER,
                                             AppCode    OUT VARCHAR2,
                                             ErrorMsg   OUT VARCHAR2) is
  v_insert_num NUMBER;

BEGIN
  insert into khg9
    (aaz958, bkel11, bke983, aae139, bkf934, baa001, bke930)
    select se_aaz958.nextval,
           BKEL11,
           bke983,
           aae139,
           bkf934,
           baa001,
           bke930
      from (select count(1) BKEL11,
                   sum(a.HIFP_PAY) bke983,
                   '1' as aae139,
                   '1' as bkf934,
                   b.baa001 as baa001,
                   to_char(a.updt_time, 'yyyyMM') bke930
              from data_sync.setl_d_outpatient a
             inner join kb01 b
                on a.FIXMEDINS_CODE = b.bkf498

             where to_char(a.updt_time, 'yyyyMM') =prm_bke930
               and REFD_SETL_FLAG = '0'
               AND VALI_FLAG = '1'
               and pay_loc = '2'

             group by b.baa001, to_char(a.updt_time, 'yyyyMM')
            union all
            select count(1) BKEL11,
                   sum(a.HIFP_PAY) bke983,
                   '1' as aae139,
                   '2' as bkf934,
                   b.baa001 as baa001,
                   to_char(a.updt_time, 'yyyyMM') bke930
              from data_sync.setl_d_outpatient a
             inner join kb01 b
                on a.FIXMEDINS_CODE = b.bkf498

             where to_char(a.updt_time, 'yyyyMM') =prm_bke930
               and REFD_SETL_FLAG = '0'
               AND VALI_FLAG = '1'
               and pay_loc = '2'

             group by b.baa001, to_char(a.updt_time, 'yyyyMM')
            union all
            select count(1) BKEL11,
                   sum(ake039) BKE983,
                   aae139,
                   bkf934,
                   baa001,
                   bke930
              from (select a.HIFP_PAY ake039,
                           '2' as aae139,
                           case
                             when a.med_type in
                                  ('11', '1401', '1402', '9904', '9907') then
                              '1'
                             else
                              '2'
                           end bkf934,
                           b.baa001 as baa001,
                           to_char(a.updt_time, 'yyyyMM') bke930
                      from data_sync.outmed_setl_d a
                     inner join kb01 b
                        on a.FIXMEDINS_CODE = b.bkf498

                     where to_char(a.updt_time, 'yyyyMM') =prm_bke930
                       and REFD_SETL_FLAG = '0'
                       AND VALI_FLAG = '1')

             group by aae139, bkf934, baa001, bke930);
  v_insert_num := SQL%ROWCOUNT;
  ExtractNum   := v_insert_num;
  AppCode      := 1;

EXCEPTION
  WHEN OTHERS THEN
    AppCode  := pkg_comm.def_err;
    ErrorMsg := '抽取表KHG9有误：' || SQLERRM;
    commit;
end PRC_EXTRACT_KHG9;
/

