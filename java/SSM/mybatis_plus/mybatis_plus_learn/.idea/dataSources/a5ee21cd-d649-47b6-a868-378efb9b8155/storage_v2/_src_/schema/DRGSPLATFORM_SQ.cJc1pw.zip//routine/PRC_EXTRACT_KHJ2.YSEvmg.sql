create procedure PRC_EXTRACT_KHJ2(prm_bke930 IN VARCHAR2,
                                             ExtractNum OUT NUMBER,
                                             AppCode    OUT VARCHAR2,
                                             ErrorMsg   OUT VARCHAR2) is
  v_insert_num NUMBER;

BEGIN
  INSERT INTO khj2
    (bke930, --期号
     ake001, --医保目录编码
     ake002, --医保目录名称
     aka065, --收费项目等级
     akc226, --数量
     akc225, --单价
     akb065, --明细项目费用总额
     bkf217, --目录类别
     akb020, --定点医药机构编号
     bkf101, --定价上限金额
     bkf632, --超限价自费费用
     bkf259 --类型
     )
    select m.bke930,
           m.ake001,
           m.ake002,
           m.aka065,
           SUM(m.akc226) akc226,
           m.akc225,
           SUM(m.akb065) akb065,
           m.bkf217,
           n.akb020,
           m.bkf101,
           sum(m.bkf632) bkf632,
           m.bkf259
      from (select bke930,
                   ake001,
                   ake002,
                   aka065,
                   akc226,
                   akc225,
                   akb065,
                   substr(bkf217, 0, 1) bkf217,
                   akb020,
                   bkf101,
                   bkf632,
                   case
                     when bkf217 = '101' then
                      case
                        when bkf250 = '11' then
                         '2'
                        else
                         '1'
                      end
                     when bkf217 = '102' then
                      '3'
                     when bkf217 = '103' then
                      '4'
                     when bkf217 = '201' then
                      '6'
                     when bkf217 = '301' then
                      '5'
                     else
                      '1'
                   end bkf259
              from (SELECT to_char(opt_time, 'yyyymm') AS BKE930, --期号
                           HILIST_CODE AS AKE001, --医保目录编码
                           HILIST_NAME AS AKE002, --医保目录名称
                           substr(CHRGITM_LV, -1) AS AKA065, --收费项目等级
                           SUM(CNT) AS AKC226, --数量
                           PRIC AS AKC225, --单价
                           SUM(DET_ITEM_FEE_SUMAMT) AS AKB065, --明细项目费用总额
                           LIST_TYPE AS BKF217, --目录类别
                           FIXMEDINS_CODE AS AKB020, --定点医药机构编号
                           PRIC_UPLMT_AMT AS BKF101, --定价上限金额
                           SUM(OVERLMT_SELFPAY) AS BKF632, --超限价自费费用
                           MED_CHRGITM_TYPE as bkf250
                      FROM data_sync.fee_list_d

                     WHERE to_char(opt_time, 'yyyymm') = prm_bke930
                     GROUP BY to_char(opt_time, 'yyyymm'),
                              HILIST_CODE, --医保目录编码
                              HILIST_NAME, --医保目录名称
                              LIST_TYPE, --目录类别
                              CHRGITM_LV, --收费项目等级
                              PRIC_UPLMT_AMT, --定价上限金额
                              FIXMEDINS_CODE, --定点医药机构编号
                              PRIC, --单价
                              MED_CHRGITM_TYPE)) m
     inner join drgsplatform_sq.kb01 n
        ON m.akb020 = n.BKF498
     group by m.bke930,
              m.ake001,
              m.ake002,
              m.aka065,
              m.akc225,
              m.bkf217,
              n.akb020,
              m.bkf101,
              m.bkf259;
  v_insert_num := SQL%ROWCOUNT;
  ExtractNum   := v_insert_num;
  AppCode      := '1';
EXCEPTION
  WHEN OTHERS THEN
    AppCode  := pkg_comm.def_err;
    ErrorMsg := '抽取表KHJ2有误：' || SQLERRM;
    commit;
end PRC_EXTRACT_KHJ2;
/

