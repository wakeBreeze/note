create PACKAGE pkg_comm
/******************************************************************************/
/*  程序包名 : pkg_COMM                                                       */
/*  业务环节 : 公共业务包                                                     */
/*  对象列表 : 私有过程函数                                                   */
/*             ---------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*             公用过程函数                                                   */
/*             ---------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/******************************************************************************/
/*  其它说明 :                                                                */
/*  完成日期 :                                                                */
/*  版本编号 : Ver 1.0                                                        */
/*  审 查 人 : ×××                      审查日期 : YYYY-MM-DD                 */
/******************************************************************************/
 AS

   /*-------------------------------------------------------------------------*/
   /* 公用全局常量声明                                                        */
   /*-------------------------------------------------------------------------*/
   -- 执行代码
   def_ok  CONSTANT NUMBER := 1; -- 成功
   def_err CONSTANT NUMBER := -1; -- 系统错误
   --数据格式化
   date_format     CONSTANT VARCHAR2(10) := 'YYYYMMDD'; --日期格式化
   issue_format    CONSTANT VARCHAR2(10) := 'YYYYMM'; --期号格式化
   bke803_year     CONSTANT VARCHAR2(3) := '4'; --年度报表
   bke803_semester CONSTANT VARCHAR2(3) := '3'; --半年度报表
   bke803_quarter  CONSTANT VARCHAR2(3) := '2'; --季度报表
   bke803_month    CONSTANT VARCHAR2(3) := '1'; --月度报表
   bke803_total    CONSTANT VARCHAR2(3) := '5'; --累计报表
   datetime_format CONSTANT VARCHAR2(21) := 'YYYY-MM-DD HH24:MI:SS'; --时间格式化
   --业务编码
   def_AAA027 CONSTANT VARCHAR2(6) := '3213'; --统筹区
   --统计级别
   bke804_aaa027 CONSTANT VARCHAR2(3) := '1'; --统筹区级
   bke804_baa001 CONSTANT VARCHAR2(3) := '2'; --分中心级
   bke804_aab301 CONSTANT VARCHAR2(3) := '3'; --区县级
   bke804_akb020 CONSTANT VARCHAR2(3) := '4'; --医院级级
   --统计记录表名常量
   bke805_KEJ1 CONSTANT VARCHAR2(4) := 'KEJ1'; --KEJ1(病案首页统计表)
   bke805_KEJ3 CONSTANT VARCHAR2(4) := 'KEJ3'; --KEJ3(服务能力情况统计表)
   bke805_KEJ4 CONSTANT VARCHAR2(4) := 'KEJ4'; --KEJ4(服务效率情况统计表)
   bke805_KEJ5 CONSTANT VARCHAR2(4) := 'KEJ5'; --KEJ5(服务安全情况统计表)
   bke805_KEJ6 CONSTANT VARCHAR2(4) := 'KEJ6'; --KEJ6(费用占比情况统计表)
   bke805_KEJ7 CONSTANT VARCHAR2(4) := 'KEJ7'; --KEJ7(MDC情况统计表)
   bke805_KEJ8 CONSTANT VARCHAR2(4) := 'KEJ8'; --KEJ8(ADRGs情况统计表)
   bke805_KEJ9 CONSTANT VARCHAR2(4) := 'KEJ9'; --KEJ9(DRGs情况统计表)
   bke805_KEK1 CONSTANT VARCHAR2(4) := 'KEK1'; --KEK1(手术能力情况统计表)
   bke805_KEK2 CONSTANT VARCHAR2(4) := 'KEK2'; --KEK2(医疗机构盈亏分析统计表)
   bke805_KEK3 CONSTANT VARCHAR2(4) := 'KEK3'; --KEK3(DRGs盈亏分析统计表)
   bke805_KEK4 CONSTANT VARCHAR2(4) := 'KEK4'; --KEK4(考核情况统计表)
   bke805_KEK6 CONSTANT VARCHAR2(4) := 'KEK6'; --KEK6(服务评分统计表)
   --制表标志
   def_bke807_ok  CONSTANT VARCHAR2(3) := '1'; --制表成功
   def_bke807_err CONSTANT VARCHAR2(3) := '-1'; --制表失败
   /*-------------------------------------------------------------------------*/
   PROCEDURE prc_getDate(prm_bke803 IN VARCHAR2, -- 报表类型
                         prm_bke800 IN VARCHAR2, --执行期号
                         prm_aae030 OUT VARCHAR2, --数据范围开始时间
                         prm_aae031 OUT VARCHAR2 --数据范围结束时间
                         );

   --字段解析
   FUNCTION fun_ParseXML(prm_XML    IN VARCHAR2,
                         prm_Marker IN VARCHAR2) RETURN VARCHAR2;

   --字段组合
   FUNCTION fun_CombineXML(prm_Marker IN VARCHAR2,
                           prm_Value  IN VARCHAR2) RETURN VARCHAR2;

   --获取顺序号
   FUNCTION fun_getsequence(prm_seq    IN VARCHAR2, --Sequence名称
                            prm_len    IN NUMBER, --长度
                            prm_prefix IN VARCHAR2 --前缀
                            ) RETURN VARCHAR2;

END pkg_comm;


/

