create trigger TIGGER_AAZ797
    before insert
    on KEH3
    for each row
    when (NEW.AAZ797 IS NULL)
BEGIN
  SELECT SE_AAZ797.NEXTVAL INTO:NEW.AAZ797 FROM DUAL;
  END;


/

