create PACKAGE BODY pkg_comm IS

   /******************************************************************************/
   /*  程序包名 : pkg_comm                                               */
   /*  业务环节 : DRG公共过程                                                */
   /*  对象列表 : 私有过程函数                                                   */
   /*             ---------------------------------------------------------------*/
   /*                                                                            */
   /*                                                                            */
   /*             公用过程函数                                                   */
   /*             ---------------------------------------------------------------*/
   /*                                                                            */
   /*                                                                            */
   /******************************************************************************/
   /*  其它说明 :                                                                */
   /*  完成日期 :                                                                */
   /*  版本编号 : Ver 1.0                                                        */
   /*  审 查 人 : ×××                      审查日期 : YYYY-MM-DD                 */
   /******************************************************************************/
   PROCEDURE prc_getDate(prm_bke803 IN VARCHAR2, -- 报表类型
                         prm_bke800 IN VARCHAR2, --执行期号
                         prm_aae030 OUT VARCHAR2, --数据范围开始时间
                         prm_aae031 OUT VARCHAR2 --数据范围结算时间
                         ) IS
      e_param_null EXCEPTION;
      s_addmonth NUMBER(2);
   BEGIN
      /* 变量初始化 */
      s_addmonth := -1;
      IF (prm_bke800 IS NULL OR prm_bke803 IS NULL) THEN
         RAISE e_param_null;
      ELSE
         --终止期号
         prm_aae031 := to_char(last_day(to_date(prm_bke800, 'yyyymm')), 'yyyymmdd');
         --开始期号
         CASE prm_bke803
            WHEN pkg_comm.bke803_year THEN
               s_addmonth := -11;
            WHEN pkg_comm.bke803_semester THEN
               s_addmonth := -5;
            WHEN pkg_comm.bke803_quarter THEN
               s_addmonth := -2;
            WHEN pkg_comm.bke803_month THEN
               s_addmonth := 0;
            WHEN pkg_comm.bke803_total THEN
               s_addmonth := -months_between(to_date(prm_bke800, 'yyyymm'),
                                             trunc(to_date(prm_bke800, 'yyyymm'), 'yy'));
            ELSE
               NULL;
         END CASE;
         prm_aae030 := to_char(trunc(add_months(to_date(prm_bke800, 'yyyymm'), s_addmonth), 'mm'),
                               'yyyymmdd');
      END IF;
   EXCEPTION
      WHEN e_param_null THEN
         RETURN;
      WHEN OTHERS THEN
         RETURN;
   END prc_getDate;

   /*---------------------------------------------------------------------------
   || 业务环节 ：解析XML格式字符串
   || 函数名称 ：fun_ParseXML
   || 功能描述 ：解析XML格式字符串
   || 使用场合 ：
   || 参数描述 ：标识                  名称             输入输出   数据类型
   ||            ---------------------------------------------------------------
   ||            prm_XML            字符串               输入     VARCHAR2
   ||            prm_Marker         标签                 输入     VARCHAR2
   ||
   || 参数说明 ：标识               详细说明
   ||            ---------------------------------------------------------------
   || 其它说明 ：
   || 作    者 ：
   || 完成日期 ：
   ||---------------------------------------------------------------------------
   ||                                 修改记录
   ||---------------------------------------------------------------------------
   || 修 改 人 ：×××                        修改日期 ：YYYY-MM-DD
   || 修改描述 ：
   ||-------------------------------------------------------------------------*/
   FUNCTION fun_ParseXML(prm_XML    IN VARCHAR2,
                         prm_Marker IN VARCHAR2) RETURN VARCHAR2 IS
      s_null   VARCHAR2(20); -- 空串
      s_Marker VARCHAR2(200); -- 标签
      s_XML    VARCHAR2(4000); -- 字符串
   BEGIN
      /*初始化变量*/
      s_null := '';
      /*参数检查*/
      IF prm_XML IS NULL THEN
         RETURN s_null;
      END IF;
      IF prm_Marker IS NULL THEN
         RETURN s_null;
      END IF;
      /*转换为大写*/
      s_Marker := UPPER(prm_Marker);
      /*检查字符串中是否有需要匹配的项*/
      IF INSTR(UPPER(prm_XML), '<' || s_Marker || '>', 1) < 1 THEN
         RETURN s_null;
      END IF;
      /*截掉字符串所匹配项的值的左边*/
      s_XML := SUBSTR(prm_XML,
                      INSTR(UPPER(prm_XML), '<' || s_Marker || '>', 1) + LENGTH(s_Marker) + 2);
      IF s_XML IS NULL THEN
         RETURN s_null;
      END IF;
      IF INSTR(UPPER(s_XML), '</' || s_Marker || '>', 1) < 1 THEN
         RETURN s_null;
      END IF;
      /*截掉字符串所匹配项的值的右边*/
      s_XML := SUBSTR(s_XML, 1, INSTR(UPPER(s_XML), '</' || s_Marker || '>', 1) - 1);
      IF s_XML IS NULL THEN
         RETURN s_null;
      END IF;
      RETURN s_XML;
   EXCEPTION
      WHEN OTHERS THEN
         RETURN s_null;
   END fun_ParseXML;

   /*---------------------------------------------------------------------------
   || 业务环节 ：合并XML格式字符串
   || 函数名称 ：fun_CombineXML
   || 功能描述 ：合并XML格式字符串
   || 使用场合 ：
   || 参数描述 ：标识                  名称             输入输出   数据类型
   ||            ---------------------------------------------------------------
   ||            prm_Marker            标签               输入     VARCHAR2
   ||            prm_Marker            值                 输入     VARCHAR2
   ||
   || 参数说明 ：标识               详细说明
   ||            ---------------------------------------------------------------
   || 其它说明 ：
   || 作    者 ：
   || 完成日期 ：
   ||---------------------------------------------------------------------------
   ||                                 修改记录
   ||---------------------------------------------------------------------------
   || 修 改 人 ：×××                        修改日期 ：YYYY-MM-DD
   || 修改描述 ：
   ||-------------------------------------------------------------------------*/
   FUNCTION fun_CombineXML(prm_Marker IN VARCHAR2,
                           prm_Value  IN VARCHAR2) RETURN VARCHAR2 IS
      s_null   VARCHAR2(20); -- 空串
      s_Marker VARCHAR2(200); -- 标签
      s_XML    VARCHAR2(4000); -- 字符串
   BEGIN
      /*初始化变量*/
      s_null := '';
      /*参数检查*/
      IF prm_Marker IS NULL OR prm_Marker = '' THEN
         RETURN s_null;
      END IF;
      /*转换为大写*/
      s_Marker := LOWER(prm_Marker);
      /*合并为XML格式串*/
      s_XML := '<' || s_Marker || '>' || prm_Value || '</' || s_Marker || '>';
      RETURN s_XML;
   EXCEPTION
      WHEN OTHERS THEN
         RETURN s_null;
   END fun_CombineXML;

   /*--------------------------------------------------------------------------
   || 业务环节 : 公共业务
   || 函数名称 : fun_GetSequence
   || 功能描述 : 获取顺序号
   || 使用场合 :
   || 参数描述 : 标识                  名称             输入输出   数据类型
   ||            ---------------------------------------------------------------
   ||            Prm_Seq             Sequence名称       输入       VARCHAR2
   ||            Prm_len             长度               输入       NUMBER
   ||            Prm_Prefix          前缀               输入       VARCHAR2
   ||
   || 参数说明 : 标识               详细说明
   ||            ---------------------------------------------------------------
   ||
   || 其它说明 :
   || 作    者 :
   || 完成日期 :
   ||---------------------------------------------------------------------------
   ||                                 修改记录
   ||---------------------------------------------------------------------------
   || 修 改 人 : ×××                        修改日期 : YYYY-MM-DD
   || 修改描述 :
   ||-------------------------------------------------------------------------*/
   FUNCTION fun_getsequence(prm_seq    IN VARCHAR2, --Sequence名称
                            prm_len    IN NUMBER, --长度
                            prm_prefix IN VARCHAR2 --前缀
                            ) RETURN VARCHAR2 IS
      /*变量声明*/
      n_seqid    NUMBER(20); -- 流水号
      sql_stmt   VARCHAR2(200); --SQL语句
      str_serial VARCHAR2(30); --业务流水号
   BEGIN
      /*初始化变量*/
      str_serial := '';
      sql_stmt   := 'SELECT ' || upper(TRIM(prm_seq)) || '.NEXTVAL  FROM DUAL';
      EXECUTE IMMEDIATE sql_stmt
         INTO n_seqid; --获取序列号
      --业务流水号
      str_serial := to_char(n_seqid);
      IF prm_len > 0 THEN
         IF length(str_serial) <= prm_len - length(prm_prefix) THEN
            str_serial := prm_prefix || lpad(str_serial, prm_len - length(prm_prefix), '0');
         ELSE
            RETURN '';
         END IF;
      ELSE
         str_serial := prm_prefix || str_serial;
      END IF;
      RETURN str_serial;
   EXCEPTION
      WHEN OTHERS THEN
         RETURN str_serial;
   END fun_getsequence;

END pkg_comm;
/

