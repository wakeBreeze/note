create procedure PRC_MEGET_BATCH(prm_bke930 VARCHAR2)
AS
      v_bke139 NUMBER(16);
      CURSOR kec1_cur_codes IS
      SELECT akb020 as kec1_akb020 FROM kec1 GROUP BY akb020;
      CURSOR kec2_cur_codes IS
      SELECT akb020 as kec2_akb020 FROM kec2 GROUP BY akb020;
BEGIN
      FOR c IN kec1_cur_codes LOOP
        SELECT se_bke139.nextval INTO v_bke139 FROM dual;
        UPDATE kec1 SET bke139 = v_bke139 WHERE akb020 = c.kec1_akb020 AND to_char(ake100,'yyyyMM')=prm_bke930 ;
      END LOOP;
      FOR c IN kec2_cur_codes LOOP
        SELECT se_bke139.nextval INTO v_bke139 FROM dual;
        UPDATE kec2 SET bke139 = v_bke139 WHERE akb020 = c.kec2_akb020 AND to_char(ake100,'yyyyMM')=prm_bke930;
      END LOOP;

end PRC_MEGET_BATCH;
/

