create procedure f_update_bke139
AS
      CURSOR cur_kec2_akb020s IS
      SELECT akb020 FROM kec2 WHERE bke701 = 0 GROUP BY akb020;
      CURSOR cur_kec1_akb020s IS
      SELECT akb020 FROM kec1 WHERE bke701 = 0 GROUP BY akb020;
BEGIN
      FOR c IN cur_kec2_akb020s LOOP
         UPDATE kec2 SET bke139 = se_bke139.nextval WHERE akb020 = c.akb020 AND bke701 = 0;
      END LOOP;
      FOR c IN cur_kec1_akb020s LOOP
         UPDATE kec1 SET bke139 = se_bke139.nextval WHERE akb020 = c.akb020 AND bke701 = 0;
      END LOOP;

end f_update_bke139;


/

