create procedure PRC_EXTRACT_KKN1(prm_bke930 IN VARCHAR2,
                                             ExtractNum OUT NUMBER,
                                             AppCode  OUT VARCHAR2,
                                             ErrorMsg OUT VARCHAR2) is
  v_insert_num NUMBER;

BEGIN
 INSERT INTO kkn1
  (aaz892, --三目录费用统计表
   akc190, --住院流水号
   akb020, --医疗机构编码
   aka063, --收费类别
   bkel23, --甲类费用
   akc254, --乙类费用
   akc253, --丙类费用
   bkf374, --其他费用
   kkh066, --总费用
   akc265, --自费金额
   bke139 --期号
   )
  SELECT se_aaz892.nextval AS aaz892,
         a.akc190, --住院流水号
         b.akb020, --医疗机构编码
         a.aka063, --收费类别
         a.bkel23, --甲类费用
         a.akc254, --乙类费用
         a.akc253, --丙类费用
         a.bkf374, --其他费用
         a.kkh066, --总费用
         a.akc265, --自费金额
         a.bke139
    FROM (SELECT MDTRT_ID AS akc190,
                 setl_id AS AAZ605,
                 OPTINS_NO AS akb020,
                 MED_CHRGITM_TYPE AS aka063,
                 sum(ITEM_CLAA_AMT) AS bkel23,
                 sum(ITEM_CLAB_AMT) AS akc254,
                 sum(ITEM_OWNPAY_AMT) AS akc253,
                 sum(ITEM_OTH_AMT) AS bkf374,
                 sum(ITEM_SUMAMT) AS kkh066,
                 sum(ITEM_OWNPAY_AMT) AS akc265,
                 to_char(OPT_TIME, 'yyyymm') AS bke139
            FROM data_sync.setl_fee_stt_d
           WHERE to_char(OPT_TIME, 'yyyymm') = prm_bke930
             AND VALI_FLAG = 1
           GROUP BY MDTRT_ID,
                    OPTINS_NO,
                    MED_CHRGITM_TYPE,
                    setl_id,
                    to_char(OPT_TIME, 'yyyymm')) a
   INNER JOIN drgsplatform_sq.kb01 b
      ON a.akb020 = b.BKF498
   INNER JOIN drgsplatform_sq.kea5 c
      ON c.AAZ605 = a.AAZ605;
  v_insert_num := SQL%ROWCOUNT;
  ExtractNum   := v_insert_num;
  AppCode    := '1';

EXCEPTION
  WHEN OTHERS THEN
    AppCode  := pkg_comm.def_err;
    ErrorMsg := '抽取表KKN1有误：' || SQLERRM;
    commit;
end PRC_EXTRACT_KKN1;
/

