create package pkg_a_statistics_dip IS
  --执行入口
  PROCEDURE prc_execute(prm_bke800   IN VARCHAR2, --执行期号
                        prm_appcode  OUT NUMBER, --执行代码
                        prm_errormsg OUT VARCHAR2); --错误信息
  --生成统计日志信息
  PROCEDURE prc_generateexelog(prm_bke800   IN VARCHAR2, --统计期号
                               prm_aae001   IN VARCHAR2, --年度
                               prm_bke803   IN VARCHAR2, --报表类型
                               prm_bke805   IN VARCHAR2, --报表表名
                               prm_aae030   IN VARCHAR2, --开始日期
                               prm_aae031   IN VARCHAR2, --终止日期
                               prm_aaz706   IN NUMBER, --分组器信息ID
                               prm_appcode  OUT NUMBER, --执行代码
                               prm_errormsg OUT VARCHAR2); --错误信息
  --生成统计分析使用临时数据
  PROCEDURE prc_generatestadata(prm_bke800   IN VARCHAR2, --统计期号
                                prm_aae001   IN VARCHAR2, --年度
                                prm_bke803   IN VARCHAR2, --报表类型
                                prm_aae030   IN VARCHAR2, --开始日期
                                prm_aae031   IN VARCHAR2, --终止日期
                               -- prm_aaz706   IN NUMBER, --分组器信息ID
                                prm_appcode  OUT NUMBER, --执行代码
                                prm_errormsg OUT VARCHAR2); --错误信息
  --KEJ1(病案首页统计表)
  PROCEDURE prc_kej1(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEJ3(服务能力情况统计表)
  PROCEDURE prc_kej3(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEJ4(服务效率情况统计表)
  PROCEDURE prc_kej4(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEJ5(服务安全情况统计表)
  PROCEDURE prc_kej5(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEJ6(费用占比情况统计表)
  PROCEDURE prc_kej6(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEJ7(MDC情况统计表)
  PROCEDURE prc_kej7(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEJ8(ADRGs情况统计表)
  PROCEDURE prc_kej8(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEJ9(DRGs情况统计表)
  PROCEDURE prc_kej9(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEK1(手术能力情况统计表)
  PROCEDURE prc_kek1(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEK2(医疗机构盈亏分析统计表)
  PROCEDURE prc_kek2(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEK3(DRGs盈亏分析统计表)
  PROCEDURE prc_kek3(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEK4(考核情况统计表)
  PROCEDURE prc_kek4(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息
  --KEK6(服务评分统计表)
  PROCEDURE prc_kek6(prm_bke800   IN VARCHAR2, --统计期号
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2); --错误信息

end pkg_a_statistics_dip;


/

