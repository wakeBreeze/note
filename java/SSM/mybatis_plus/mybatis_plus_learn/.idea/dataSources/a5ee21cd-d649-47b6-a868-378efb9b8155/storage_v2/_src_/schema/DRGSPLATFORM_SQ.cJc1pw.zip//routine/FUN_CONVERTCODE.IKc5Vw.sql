create FUNCTION fun_convertcode(prm_aaa100 IN VARCHAR2,
                                           prm_aaa102 IN VARCHAR2)
  RETURN VARCHAR2 IS
  /*--------------------------------------------------------------------------
  || 业务环节 : 码值转换函数
  || 函数名称 ：fun_convertcode
  || 功能描述 ：转换sql语句的代码值
  || 使用场合 ：
  || 参数描述 ：标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||            prm_aaa100            代码类别        输入     VARCHAR2
  ||            PRM_AAA102            代码值
  ||
  || 参数说明 ：标识               详细说明
  ||            ---------------------------------------------------------------
  ||            prm_aaa100            必须传为字符串（如'BAC002'）
  ||            PRM_AAA102          表的别名.代码值（如a.bac002）
  || 其它说明 ：
  || 作    者 ：
  || 完成日期 ：
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 ：×××                        修改日期 ：YYYY-MM-DD
  || 修改描述 ：
  ||-------------------------------------------------------------------------*/

  v_aaa103 VARCHAR(100) := '';
  v_aaa100 VARCHAR(100) := upper(TRIM(prm_aaa100));

BEGIN
  IF v_aaa100 = 'BKF014' THEN
    SELECT bkf033
      INTO v_aaa103
      FROM kaa3
     WHERE bkf014 = replace(prm_aaa102, '.')
       AND aae100 = '1'
       AND aae030 <= to_char(SYSDATE, 'yyyymmdd')
       AND (aae031 >= to_char(SYSDATE, 'yyyymmdd') OR aae031 IS NULL);
  ELSE
    SELECT aaa103
      INTO v_aaa103
      FROM aa10
     WHERE aaa131 = '0'
       AND aaa100 = v_aaa100
       AND aaa102 = prm_aaa102;
  END IF;
  RETURN nvl(v_aaa103, prm_aaa102);
EXCEPTION
  WHEN OTHERS THEN
    RETURN prm_aaa102;
END fun_convertcode;


/

