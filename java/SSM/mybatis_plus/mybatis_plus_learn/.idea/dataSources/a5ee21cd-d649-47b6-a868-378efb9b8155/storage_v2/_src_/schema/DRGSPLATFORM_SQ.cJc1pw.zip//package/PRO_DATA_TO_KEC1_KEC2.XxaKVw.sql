create package pro_data_to_kec1_kec2  is

  -- Author  : 79295
  -- Created : 2020/12/23 11:59:20
  -- Purpose : 
  
 PROCEDURE pro_data;
 PROCEDURE pro_hisdata_to_kec1;
 PROCEDURE pro_hisdata_to_kec2;

end pro_data_to_kec1_kec2 ;


/

