create PACKAGE BODY DRGs_PKG IS

   /******************************************************************************/
   /*  程序包名 ：DRGs_PKG                                                */
   /*  业务环节 ：DRGs数据分析                                            */
   /*  功能描述 ：为DRGs分析提供存储过程                                 */
   /*                                                                            */
   /*  作    者 ： hzq                作成日期 ：2018/8/27 15:10:24     版本编号 ：Ver 2.0.0  */
   /*----------------------------------------------------------------------------*/
   /*  修改记录 ：                                                               */
   /******************************************************************************/
   /*-------------------------------------------------------------------------*/
   /* 公用全局常量声明                                                        */
   /*-------------------------------------------------------------------------*/
    /*-------------------------------------------------------------------------*/
   /*
   //      数据抽取（中西医同时）
   //      参数
   //      prm_bke139 IN VARCHAR(2)   批次号
   //      prm_appcode OUT VARCHAR(2) 调用存储过程 prm_appcode 成功状态
   //      prm_errormsg OUT VARCHAR(50) 错误日志
   //      ExtractNum OUT NUMBER(12) 抽数数据量
   */
   PROCEDURE PRC_KEC3ANDKEC4( prm_bke139 IN VARCHAR2,
                              ExtractNum OUT NUMBER,
                              AppCode    OUT VARCHAR2,
                              ErrorMsg   OUT VARCHAR2
                             ) IS
      v_insert_num NUMBER;
      v_insert_kec3_num NUMBER;
      v_insert_kec4_num NUMBER;
      v_update_kec1_num NUMBER;
      v_update_kec2_num NUMBER;

   BEGIN
     INSERT INTO KEC3
              select
              --查询中医数据到kec3
              a.baz506            as baz506,--住院病案首页id
              a.ake554            as ake554,--住院病案首页类型
              a.akc190            as akc190,--就诊登记号
              a.akb020            as akb020,--医疗服务机构编号
              a.aaa027            as aaa027,--统筹区编码
              b.baa001            as baa001,--分中心编码
              a.aae036            as aae036,--病案上传时间
              nvl(b.aae036,a.ake100) as ake100,--结算时间
              a.username          as akb021,--医疗服务机构名称
              a.ylfkfs            AS ake300,--医疗付款方式
              a.bah               AS ake302,--病案号
              a.xm                AS aac003,--姓名
              a.xb                AS aac004,--性别
              a.csrq              AS aac006,--出生日期
              a.nl                AS akc023,--年龄
              a.bzyzs_nl          AS ake304,--(年龄不足1周岁的)年龄(月)
              a.xsetz             AS ake305,--新生儿出生体重(克)
              a.xserytz           AS ake306,--新生儿入院体重(克）
              a.mz                AS aac005,--民族
              a.sfzh              AS aac002,--身份证号
              a.xzz               AS aae006,--现住址
              a.rytj              AS ake317,--入院途径
              F_STR_TO_DATE_STR(a.rysj)   AS bkc009,--入院时间   转换
              a.rysj_s            AS ake318,--入院时间时
              replace(a.rykb,'.','')    AS akf001,--入院科别
              replace(a.zkkb,'.','')    AS ake319,--转院科别
              --(select bkec28 from kaa3 where akf001 = a.rykb and bkf014  = '2') AS akf001,--入院科别(标准)
              --(select bkec28 from kaa3 where akf001 = a.zkkb and bkf014  = '2') AS ake319,--转院科别(标准)
              F_STR_TO_DATE_STR(a.cysj)   AS bkc010,--出院时间  转换
              a.cysj_s            AS ake320,--出院时间时
              replace(a.cykb,'.','')    AS bkf002,--入院科别
              --(select bkec28 from kaa3 where akf001 = a.cykb and bkf014  = '2') AS bkf002,--出院科别(标准)
              a.sjzy              AS bkc041,--实际住院天数
              a.lyfs              AS ake471,--离院方式
              a.yzzy_jgmc         AS ake472,--医嘱转院，拟接收医疗机构名称
              a.wsy_jgmc          AS ake473,--医嘱转社区卫生服务机构/乡镇卫生院，拟接收医疗机构名称
              NVL(b.akc264, a.zfy)AS akc264,--住院费用(元)：总费用
              a.zfje              AS ake482,--自付金额
              a.ylfwf             AS ake483,--综合医疗服务类：(1)一般医疗服务费
              a.bzlzf             AS ake538,--综合医疗服务类：(1)一般医疗服务费-中医辨证论治费
              a.zyblzhzf          AS ake539,--综合医疗服务类：(1)一般医疗服务费-中医辨证论治会诊费
              a.zlczf             AS ake484,--综合医疗服务类：(2)一般治疗操作费
              a.hlf               AS alc113,--综合医疗服务类：(3)护理费
              a.qtfy              AS ake485,--综合医疗服务类：(4)其他费用
              a.blzdf             AS ake486,--诊断类：(5)病理诊断费
              a.zdf               AS ake487,--诊断类：(6)实验室诊断费
              a.yxxzdf            AS ake488,--诊断类：(7)影像学诊断费
              a.lczdxmf           AS ake489,--诊断类：(8)临床诊断项目费
              a.fsszlxmf          AS ake490,--治疗类：(9)非手术治疗项目费
              a.zlf               AS ake491,--治疗类：(9)非手术治疗项目费-临床物理治疗费
              a.sszlf             AS ake492,--治疗类：(10)手术治疗费
              a.mzf               AS ake493,--治疗类：(10)手术治疗费-麻醉费
              a.ssf               AS ake045,--治疗类：(10)手术治疗费-手术费
              a.kff               AS ake494,--康复类：(11)康复费
              a.zyl_zyzd          AS ake540,--中医类(中医和名族医医疗服务)：(12)中医诊断
              a.zyzl              AS ake541,--中医类(中医和名族医医疗服务)：(13)中医治疗
              a.zywz              AS ake542,--中医类(中医和名族医医疗服务)：(13)中医治疗-中医外治
              a.zygs              AS ake543,--中医类(中医和名族医医疗服务)：(13)中医治疗-中医骨伤
              a.zcyjf             AS ake544,--中医类(中医和名族医医疗服务)：(13)中医治疗-针刺与灸法
              a.zytnzl            AS ake545,--中医类(中医和名族医医疗服务)：(13)中医治疗-中医推拿治疗
              a.zygczl            AS ake546,--中医类(中医和名族医医疗服务)：(13)中医治疗-中医肛肠治疗
              a.zytszl            AS ake547,--中医类(中医和名族医医疗服务)：(13)中医治疗-中医特殊治疗
              a.zyqt              AS ake548,--中医类(中医和名族医医疗服务)：(14)中医其他
              a.zytstpjg          AS ake549,--中医类(中医和名族医医疗服务)：(14)中医其他-中医特殊调配加工
              a.bzss              AS ake550,--中医类(中医和名族医医疗服务)：(14)中医其他-辨证施膳
              a.xyf               AS ake047,--西药类：(15)西药费
              a.kjywf             AS ake496,--西药类：(15)西药费-抗菌药物费
              a.zcyf              AS ake050,--中药类：(16)中成药费
              a.zyzjf             AS ake551,--中药类：(16)中成药费-医疗机构中药制剂费
              a.zcyf1             AS ake049,--中药类：(17)中草药费
              a.xf                AS ake046,--血液和血液制品类：(18)血费
              a.bdblzpf           AS ake497,--血液和血液制品类：(19)白蛋白类制品费
              a.qdblzpf           AS ake498,--血液和血液制品类：(20)球蛋白类制品费
              a.nxyzlzpf          AS ake499,--血液和血液制品类：(21)凝血因子类制品费
              a.xbyzlzpf          AS ake500,--血液和血液制品类：(22)细胞因子类制品费
              a.jcyyclf           AS ake501,--耗材类：(23)检查用一次性医用材料费
              a.yyclf             AS ake502,--耗材类：(24)治疗用一次性医用材料费
              a.ssycxclf          AS ake503,--耗材类：(25)手术用一次性医用材料费
              a.qtf               AS ake044,--其他类：(26)其他费
              b.bac002            AS bac002,--人群类别
              a.aaa131            AS aaa131,--撤销标志
              a.bke139            AS bke139,--批次号
              '0'                 AS bke899,--DRG结算标志
              a.ake582            AS ake582, --病案修改次数
              replace(a.rykb,'.','')    AS bkec25,--入院科别
              replace(a.zkkb,'.','')    AS bkec26,--转科科别     
              replace(a.cykb,'.','')    AS bkec27 --出院科别 
              from kec1 a
               LEFT JOIN kea5 b
             ON a.akc190 = b.akc190
            AND b.aaa131 = '0'
          WHERE a.bke701 = '0'
            AND a.AAA131 = '0'
            AND a.BkE139 = prm_bke139

              union all

              SELECT
              --西医抽取数据到kec3
              a.baz506            as baz506,--住院病案首页id
              a.ake554            as ake554,--住院病案首页类型
              a.akc190            as akc190,--就诊登记号
              a.akb020            as akb020,--医疗服务机构编号
              a.aaa027            as aaa027,--统筹区编码
              b.baa001            as baa001,--分中心编码
              a.aae036            as aae036,--病案上传时间
              nvl(b.aae036,a.ake100)            as ake100,--结算时间
              a.username          as akb021,--医疗服务机构名称
              a.ylfkfs            AS ake300,--医疗付款方式
              a.bah               AS ake302,--病案号
              a.xm                AS aac003,--姓名
              a.xb                AS aac004,--性别
              a.csrq              AS aac006,--出生日期
              a.nl                AS akc023,--年龄
              a.bzyzsnl           AS ake304,--(年龄不足1周岁的
              a.xsecstz           AS ake305,--新生儿出生体重(克
              a.xserytz           AS ake306,--新生儿入院体重(克
              a.mz                AS aac005,--民族
              a.sfzh              AS aac002,--身份证号
              a.xzz               AS aae006,--现住址
              a.rytj              AS ake317,--入院途径
              F_STR_TO_DATE_STR(a.rysj)    AS bkc009,--入院时间   转换
              a.rysjs             AS ake318,--入院时间时
              replace(a.rykb,'.','')    AS akf001,--入院科别
              replace(a.zkkb,'.','')    AS ake319,--转院科别
              --(select bkec28 from kaa3 where akf001 = a.rykb and bkf014  = '2') AS akf001,--入院科别(标准)
              --(select bkec28 from kaa3 where akf001 = a.zkkb and bkf014  = '2') AS ake319,--转院科别(标准)
              F_STR_TO_DATE_STR(a.cysj)   AS bkc010,--出院时间  转换
              a.cysjs            AS ake320,--出院时间时
              replace(a.cykb,'.','')    AS bkf002,--入院科别
              --(select bkec28 from kaa3 where akf001 = a.cykb and bkf014  = '2') AS bkf002,--出院科别(标准)
              a.sjzyts            AS bkc041,--实际住院天数
              a.lyfs              AS ake471,--离院方式
              a.yzzy_yljg         AS ake472,--医嘱转院，拟接收医
              a.wsy_yljg          AS ake473,--医嘱转社区卫生服务
              nvl(b.akc264, a.zfy)AS akc264,--住院费用(元)：总
              a.zfje              AS ake482,--自付金额
              a.ylfuf             AS ake483,--综合医疗服务类：(
              NULL                AS ake538,--综合医疗服务类：(
              NULL                AS ake539,--综合医疗服务类：(
              a.zlczf             AS ake484,--综合医疗服务类：(
              a.hlf               AS alc113,--综合医疗服务类：(
              a.qtfy              AS ake485,--综合医疗服务类：(
              a.blzdf             AS ake486,--诊断类：(5)病理
              a.syszdf            AS ake487,--诊断类：(6)实验
              a.yxxzdf            AS ake488,--诊断类：(7)影像
              a.lczdxmf           AS ake489,--诊断类：(8)临床
              a.fsszlxmf          AS ake490,--治疗类：(9)非手
              a.wlzlf             AS ake491,--治疗类：(9)非手
              a.sszlf             AS ake492,--治疗类：(10)手
              a.maf               AS ake493,--治疗类：(10)手
              a.ssf               AS ake045,--治疗类：(10)手
              a.kff               AS ake494,--康复类：(11)康
              NULL                AS ake540,--中医类(中医和名族
              a.zyzlf             AS ake541,--中医类(中医和名族
              NULL                AS ake542,--中医类(中医和名族
              NULL                AS ake543,--中医类(中医和名族
              NULL                AS ake544,--中医类(中医和名族
              NULL                AS ake545,--中医类(中医和名族
              NULL                AS ake546,--中医类(中医和名族
              NULL                AS ake547,--中医类(中医和名族
              NULL                AS ake548,--中医类(中医和名族
              NULL                AS ake549,--中医类(中医和名族
              NULL                AS ake550,--中医类(中医和名族
              a.xyf               AS ake047,--西药类：(15)西
              a.kjywf             AS ake496,--西药类：(15)西
              a.zcyf              AS ake050,--中药类：(16)中
              NULL                AS ake551,--中药类：(16)中
              a.zcyf1             AS ake049,--中药类：(17)中
              a.xf                AS ake046,--血液和血液制品类：
              a.bdblzpf           AS ake497,--血液和血液制品类：
              a.qdblzpf           AS ake498,--血液和血液制品类：
              a.nxyzlzpf          AS ake499,--血液和血液制品类：
              a.xbyzlzpf          AS ake500,--血液和血液制品类：
              a.hcyyclf           AS ake501,--耗材类：(23)检
              a.yyclf             AS ake502,--耗材类：(24)治
              a.ycxyyclf          AS ake503,--耗材类：(25)手
              a.qtf               AS ake044,--其他类：(26)其
              b.bac002            AS bac002,--人群类别
              a.aaa131            AS aaa131, --撤销标志
              a.bke139            AS bke139,--批次号
              '0'                 AS bke899,--DRG结算标志
              a.ake582            AS ake582, --病案修改次数
              replace(a.rykb,'.','')    AS bkec25,--入院科别
              replace(a.zkkb,'.','')    AS bkec26,--转科科别     
              replace(a.cykb,'.','')    AS bkec27 --出院科别 
              from kec2 a
               LEFT JOIN kea5 b
             ON a.akc190 = b.akc190
            AND b.aaa131 = '0'
          WHERE a.bke701 = '0'
            AND a.AAA131 = '0'
            AND a.BkE139 = prm_bke139;
         -- kec3数据抽取
          v_insert_kec3_num := SQL%ROWCOUNT;


      /******************KEC3抽取结束****************/

      /*****************开始抽取KEC4表数据***********/

      insert into kec4
      select
          --西医数据抽取
          a.baz506  AS baz506,--住院病案首页id
          a.ake554  AS ake554,--住院病案首页类型
          a.akc190  AS akc190,--就诊登记号
          a.akb020  AS akb020,--医疗服务机构编号
          a.aaa027  AS aaa027,--统筹区编码
          ''        AS baa001,--分中心编码
          a.aae036  AS aae036,--病案上传时间
          nvl(b.aae036,a.ake100) AS ake100,--结算时间
          NULL      AS ake514,--主病诊断
          NULL      AS ake515,--主病诊断疾病编码
          NULL      AS ake516,--主病诊断入院病情
          a.zyzd    AS ake324,--主要诊断
          a.jbdm    AS ake325,--主要诊断疾病编码
          a.rybq    AS ake326,--主要诊断入院病情
          NULL      AS ake517,--主证诊断1
          NULL      AS ake518,--主证诊断1疾病编码
          NULL      AS ake519,--主证诊断1入院病情
          a.qtzd1   AS ake327,--其他诊断1
          a.jbdm1   AS ake328,--其他诊断1疾病编码
          a.rybq1   AS ake329,--其他诊断1入院病情
          NULL      AS ake520,--主证诊断2
          NULL      AS ake521,--主证诊断2疾病编码
          NULL      AS ake522,--主证诊断2入院病情
          a.qtzd2   AS ake330,--其他诊断2
          a.jbdm2   AS ake331,--其他诊断2疾病编码
          a.rybq2   AS ake332,--其他诊断2入院病情
          NULL      AS ake523,--主证诊断3
          NULL      AS ake524,--主证诊断3疾病编码
          NULL      AS ake525,--主证诊断3入院病情
          a.qtzd3   AS ake333,--其他诊断3
          a.jbdm3   AS ake334,--其他诊断3疾病编码
          a.rybq3   AS ake335,--其他诊断3入院病情
          NULL      AS ake526,--主证诊断4
          NULL      AS ake527,--主证诊断4疾病编码
          NULL      AS ake528,--主证诊断4入院病情
          a.qtzd4   AS ake336,--其他诊断4
          a.jbdm4   AS ake337,--其他诊断4疾病编码
          a.rybq4   AS ake338,--其他诊断4入院病情
          NULL      AS ake529,--主证诊断5
          NULL      AS ake530,--主证诊断5疾病编码
          NULL      AS ake531,--主证诊断5入院病情
          a.qtzd5   AS ake339,--其他诊断5
          a.jbdm5   AS ake340,--其他诊断5疾病编码
          a.rybq5   AS ake341,--其他诊断5入院病情
          NULL      AS ake532,--主证诊断6
          NULL      AS ake533,--主证诊断6疾病编码
          NULL      AS ake534,--主证诊断6入院病情
          a.qtzd6   AS ake342,--其他诊断6
          a.jbdm6   AS ake343,--其他诊断6疾病编码
          a.rybq6   AS ake344,--其他诊断6入院病情
          NULL      AS ake535,--主证诊断7
          NULL      AS ake536,--主证诊断7疾病编码
          NULL      AS ake537,--主证诊断7入院病情
          a.qtzd7   AS ake345,--其他诊断7
          a.jbdm7   AS ake346,--其他诊断7疾病编码
          a.rybq7   AS ake347,--其他诊断7入院病情
          a.qtzd8   AS ake348,--其他诊断8
          a.jbdm8   AS ake349,--其他诊断8疾病编码
          a.rybq8   AS ake350,--其他诊断8入院病情
          a.qtzd9   AS ake351,--其他诊断9
          a.jbdm9   AS ake352,--其他诊断9疾病编码
          a.rybq9   AS ake353,--其他诊断9入院病情
          a.qtzd10  AS ake354,--其他诊断10
          a.jbdm10  AS ake355,--其他诊断10疾病编码
          a.rybq10  AS ake356,--其他诊断10入院病情
          a.qtzd11  AS ake357,--其他诊断11
          a.jbdm11  AS ake358,--其他诊断11疾病编码
          a.rybq11  AS ake359,--其他诊断11入院病情
          a.qtzd12  AS ake360,--其他诊断12
          a.jbdm12  AS ake361,--其他诊断12疾病编码
          a.rybq12  AS ake362,--其他诊断12入院病情
          a.qtzd13  AS ake363,--其他诊断13
          a.jbdm13  AS ake364,--其他诊断13疾病编码
          a.rybq13  AS ake365,--其他诊断13入院病情
          a.qtzd14  AS ake366,--其他诊断14
          a.jbdm14  AS ake367,--其他诊断14疾病编码
          a.rybq14  AS ake368,--其他诊断14入院病情
          a.qtzd15  AS ake369,--其他诊断15
          a.jbdm15  AS ake370,--其他诊断15疾病编码
          a.rybq15  AS ake371,--其他诊断15入院病情
          a.ssjczbm1    AS ake394,--手术及操作编码1
          a.ssjczrq1    AS ake395,--手术及操作日期1
          a.ssjb1       AS ake396,--手术级别1
          a.ssjczmc1    AS ake397,--手术及操作名称1
          a.sz1         AS ake398,--术者1
          a.yz1         AS ake399,--i助1
          a.ez1         AS ake400,--ii助1
          a.qkdj1       AS ake401,--切口等级1
          a.qkyhlb1     AS ake402,--切口愈合类别1
          a.mzfs1       AS ake403,--麻醉方式1
          a.mzys1       AS ake404,--麻醉医师1
          a.ssjczbm2    AS ake405,--手术及操作编码2
          a.ssjczrq2    AS ake406,--手术及操作日期2
          a.ssjb2       AS ake407,--手术级别2
          a.ssjczmc2    AS ake408,--手术及操作名称2
          a.sz2         AS ake409,--术者2
          a.yz2         AS ake410,--i助2
          a.ez2         AS ake411,--ii助2
          a.qkdj2       AS ake412,--切口等级2
          a.qkyhlb2     AS ake413,--切口愈合类别2
          a.mzfs2       AS ake414,--麻醉方式2
          a.mzys2       AS ake415,--麻醉医师2
          a.ssjczbm3    AS ake416,--手术及操作编码3
          a.ssjczrq3    AS ake417,--手术及操作日期3
          a.ssjb3       AS ake418,--手术级别3
          a.ssjczmc3    AS ake419,--手术及操作名称3
          a.sz3         AS ake420,--术者3
          a.yz3         AS ake421,--i助3
          a.ez3         AS ake422,--ii助3
          a.qkdj3       AS ake423,--切口等级3
          a.qkyhlb3     AS ake424,--切口愈合类别3
          a.mzfs3       AS ake425,--麻醉方式3
          a.mzys3       AS ake426,--麻醉医师3
          a.ssjczbm4    AS ake427,--手术及操作编码4
          a.ssjczrq4    AS ake428,--手术及操作日期4
          a.ssjb4       AS ake429,--手术级别4
          a.ssjczmc4    AS ake430,--手术及操作名称4
          a.sz4         AS ake431,--术者4
          a.yz4         AS ake432,--i助4
          a.ez4         AS ake433,--ii助4
          a.qkdj4       AS ake434,--切口等级4
          a.qkyhlb4     AS ake435,--切口愈合类别4
          a.mzfs4       AS ake436,--麻醉方式4
          a.mzys4       AS ake437,--情况麻醉医师4
          a.ssjczbm5    AS ake438,--手术及操作编码5
          a.ssjczrq5    AS ake439,--手术及操作日期5
          a.ssjb5       AS ake440,--手术级别5
          a.ssjczmc5    AS ake441,--手术及操作名称5
          a.sz5         AS ake442,--术者5
          a.yz5         AS ake443,--i助5
          a.ez5         AS ake444,--ii助5
          a.qkdj5       AS ake445,--切口等级5
          a.qkyhlb5     AS ake446,--切口愈合类别5
          a.mzfs5       AS ake447,--麻醉方式5
          a.mzys5       AS ake448,--麻醉医师5
          a.ssjczbm6    AS ake449,--手术及操作编码6
          a.ssjczrq6    AS ake450,--手术及操作日期6
          a.ssjb6       AS ake451,--手术级别6
          a.ssjczmc6    AS ake452,--手术及操作名称6
          a.sz6         AS ake453,--术者6
          a.yz6         AS ake454,--i助6
          a.ez6         AS ake455,--ii助6
          a.qkdj6       AS ake456,--切口等级6
          a.qkyhlb6     AS ake457,--切口愈合类别6
          a.mzfs6       AS ake458,--麻醉方式6
          a.mzys6       AS ake459,--麻醉医师6
          a.ssjczbm7  AS ake460,--手术及操作编码7
          a.ssjczrq7  AS ake461,--手术及操作日期7
          a.ssjb7     AS ake462,--手术级别7
          a.ssjczmc7  AS ake463,--手术及操作名称7
          a.sz7       AS ake464,--术者7
          a.yz7       AS ake465,--i助7
          a.ez7       AS ake466,--ii助7
          a.qkdj7     AS ake467,--切口等级7
          a.qkyhlb7   AS ake468,--切口愈合类别7
          a.mzfs7     AS ake469,--麻醉方式7
          a.mzys7     AS ake470,--麻醉医师7
          NULL        AS ake580,--实施临床路径管理标志
          NULL        AS ake581,--执行临床路径状态
          a.kzr       AS ake382,--科主任
          a.zrys      AS ake383,--主任（副主任）医师
          a.zzys      AS ake384,--主治医师
          a.zyys      AS ake385,--住院医师
          a.zrhs      AS ake386,--责任护士
          a.jxys      AS ake387,--进修医师
          a.sxys      AS ake388,--实习医师
          a.bmy       AS ake389,--编码员
          a.bazl      AS ake390,--病案质量
          a.zkys      AS ake391,--质控医师
          a.zkhs      AS ake392,--质控护士
          a.zkrq      AS ake393,--质控日期
          a.rybf      AS ake020,--入院病房
          a.cybf      AS ake321,--出院病房
          a.aaa131    AS aaa131, --撤销标志
          null        AS akeb71,--重点疾病编号
          null        AS akeb72,--重点疾病名称
          null        AS akeb73,--重点手术编号
          null        AS akeb74, --重点手术名称
          a.bke139    AS bke139 --数据批次号
          from kec2 a
          LEFT JOIN kea5 b
             ON a.akc190 = b.akc190
            AND b.aaa131 = '0'
          WHERE a.bke701 = '0'
            AND a.AAA131 = '0'
            AND a.BkE139 = prm_bke139

          union all

          SELECT
          --中医数据抽取
          a.baz506      AS baz506,--住院病案首页id
          a.ake554      AS ake554,--住院病案首页类型
          a.akc190      AS akc190,--就诊登记号
          a.akb020      AS akb020,--医疗服务机构编号
          a.aaa027      AS aaa027,--统筹区编码
          ''            AS baa001,--分中心编码
          a.aae036      AS aae036,--病案上传时间
          nvl(b.aae036,a.ake100)  AS ake100,--结算时间
          a.zb          AS ake514,--主病诊断
          a.zb_jbbm     AS ake515,--主病诊断疾病编码
          a.zb_rybq     AS ake516,--主病诊断入院病情
          a.zyzd        AS ake324,--主要诊断
          a.zyzd_jbbm   AS ake325,--主要诊断疾病编码
          a.xy_rybq     AS ake326,--主要诊断入院病情
          a.zz1         AS ake517,--主证诊断1
          a.zz_jbbm1    AS ake518,--主证诊断1疾病编码
          a.zz_rybq1    AS ake519,--主证诊断1入院病情
          a.qtzd1       AS ake327,--其他诊断1
          a.zyzd_jbbm1  AS ake328,--其他诊断1疾病编码
          a.rybq1       AS ake329,--其他诊断1入院病情
          a.zz2         AS ake520,--主证诊断2
          a.zz_jbbm2    AS ake521,--主证诊断2疾病编码
          a.zz_rybq2    AS ake522,--主证诊断2入院病情
          a.qtzd1       AS ake330,--其他诊断2
          a.zyzd_jbbm2  AS ake331,--其他诊断2疾病编码
          a.rybq2       AS ake332,--其他诊断2入院病情
          a.zz3         AS ake523,--主证诊断3
          a.zz_jbbm3    AS ake524,--主证诊断3疾病编码
          a.zz_rybq3    AS ake525,--主证诊断3入院病情
          a.qtzd3       AS ake333,--其他诊断3
          a.zyzd_jbbm3  AS ake334,--其他诊断3疾病编码
          a.rybq3       AS ake335,--其他诊断3入院病情
          a.zz4         AS ake526,--主证诊断4
          a.zz_jbbm4    AS ake527,--主证诊断4疾病编码
          a.zz_rybq4    AS ake528,--主证诊断4入院病情
          a.qtzd4       AS ake336,--其他诊断4
          a.zyzd_jbbm4  AS ake337,--其他诊断4疾病编码
          a.rybq4       AS ake338,--其他诊断4入院病情
          a.zz5         AS ake529,--主证诊断5
          a.zz_jbbm5    AS ake530,--主证诊断5疾病编码
          a.zz_rybq5    AS ake531,--主证诊断5入院病情
          a.qtzd5       AS ake339,--其他诊断5
          a.zyzd_jbbm5  AS ake340,--其他诊断5疾病编码
          a.rybq5       AS ake341,--其他诊断5入院病情
          a.zz6         AS ake532,--主证诊断6
          a.zz_jbbm6    AS ake533,--主证诊断6疾病编码
          a.zz_rybq6    AS ake534,--主证诊断6入院病情
          a.qtzd6       AS ake342,--其他诊断6
          a.zyzd_jbbm6  AS ake343,--其他诊断6疾病编码
          a.rybq6       AS ake344,--其他诊断6入院病情
          a.zz7         AS ake535,--主证诊断7
          a.zz_jbbm7    AS ake536,--主证诊断7疾病编码
          a.zz_rybq7    AS ake537,--主证诊断7入院病情
          a.qtzd7       AS ake345,--其他诊断7
          a.zyzd_jbbm7  AS ake346,--其他诊断7疾病编码
          a.rybq7       AS ake347,--其他诊断7入院病情
          NULL          AS ake348,--其他诊断8
          NULL          AS ake349,--其他诊断8疾病编码
          NULL          AS ake350,--其他诊断8入院病情
          NULL          AS ake351,--其他诊断9
          NULL          AS ake352,--其他诊断9疾病编码
          NULL          AS ake353,--其他诊断9入院病情
          NULL          AS ake354,--其他诊断10
          NULL          AS ake355,--其他诊断10疾病编码
          NULL          AS ake356,--其他诊断10入院病情
          NULL          AS ake357,--其他诊断11
          NULL          AS ake358,--其他诊断11疾病编码
          NULL          AS ake359,--其他诊断11入院病情
          NULL          AS ake360,--其他诊断12
          NULL          AS ake361,--其他诊断12疾病编码
          NULL          AS ake362,--其他诊断12入院病情
          NULL          AS ake363,--其他诊断13
          NULL          AS ake364,--其他诊断13疾病编码
          NULL          AS ake365,--其他诊断13入院病情
          NULL          AS ake366,--其他诊断14
          NULL          AS ake367,--其他诊断14疾病编码
          NULL          AS ake368,--其他诊断14入院病情
          NULL          AS ake369,--其他诊断15
          NULL          AS ake370,--其他诊断15疾病编码
          NULL          AS ake371,--其他诊断15入院病情
          a.ssjczbm1    AS ake394,--手术及操作编码1
          a.ssjczrq1    AS ake395,--手术及操作日期1
          a.shjb1       AS ake396,--手术级别1
          a.ssjczmc1    AS ake397,--手术及操作名称1
          a.sz1         AS ake398,--术者1
          a.yz1         AS ake399,--i助1
          a.ez1         AS ake400,--ii助1
          a.qkdj1       AS ake401,--切口等级1
          a.qkylb1      AS ake402,--切口愈合类别1
          a.mzfs1       AS ake403,--麻醉方式1
          a.mzys1       AS ake404,--麻醉医师1
          a.ssjczbm2    AS ake405,--手术及操作编码2
          a.ssjczrq2    AS ake406,--手术及操作日期2
          a.shjb2       AS ake407,--手术级别2
          a.ssjczmc2    AS ake408,--手术及操作名称2
          a.sz2         AS ake409,--术者2
          a.yz2         AS ake410,--i助2
          a.ez2         AS ake411,--ii助2
          a.qkdj2       AS ake412,--切口等级2
          a.qkylb2      AS ake413,--切口愈合类别2
          a.mzfs2       AS ake414,--麻醉方式2
          a.mzys2       AS ake415,--麻醉医师2
          a.ssjczbm3    AS ake416,--手术及操作编码3
          a.ssjczrq3    AS ake417,--手术及操作日期3
          a.shjb3       AS ake418,--手术级别3
          a.ssjczmc3    AS ake419,--手术及操作名称3
          a.sz3         AS ake420,--术者3
          a.yz3         AS ake421,--i助3
          a.ez3         AS ake422,--ii助3
          a.qkdj3       AS ake423,--切口等级3
          a.qkylb3      AS ake424,--切口愈合类别3
          a.mzfs3       AS ake425,--麻醉方式3
          a.mzys3       AS ake426,--麻醉医师3
          a.ssjczbm4    AS ake427,--手术及操作编码4
          a.ssjczrq4    AS ake428,--手术及操作日期4
          a.shjb4       AS ake429,--手术级别4
          a.ssjczmc4    AS ake430,--手术及操作名称4
          a.sz4         AS ake431,--术者4
          a.yz4         AS ake432,--i助4
          a.ez4         AS ake433,--ii助4
          a.qkdj4       AS ake434,--切口等级4
          a.qkylb4      AS ake435,--切口愈合类别4
          a.mzfs4       AS ake436,--麻醉方式4
          a.mzys4       AS ake437,--情况麻醉医师4
          a.ssjczbm5    AS ake438,--手术及操作编码5
          a.ssjczrq5    AS ake439,--手术及操作日期5
          a.shjb5       AS ake440,--手术级别5
          a.ssjczmc5    AS ake441,--手术及操作名称5
          a.sz5         AS ake442,--术者5
          a.yz5         AS ake443,--i助5
          a.ez5         AS ake444,--ii助5
          a.qkdj5       AS ake445,--切口等级5
          a.qkylb5      AS ake446,--切口愈合类别5
          a.mzfs5       AS ake447,--麻醉方式5
          a.mzys5       AS ake448,--麻醉医师5
          a.ssjczbm6    AS ake449,--手术及操作编码6
          a.ssjczrq6    AS ake450,--手术及操作日期6
          a.shjb6       AS ake451,--手术级别6
          a.ssjczmc6    AS ake452,--手术及操作名称6
          a.sz6         AS ake453,--术者6
          a.yz6         AS ake454,--i助6
          a.ez6         AS ake455,--ii助6
          a.qkdj6       AS ake456,--切口等级6
          a.qkylb6      AS ake457,--切口愈合类别6
          a.mzfs6       AS ake458,--麻醉方式6
          a.mzys6       AS ake459,--麻醉医师6
          NULL          AS ake460,--手术及操作编码7
          NULL          AS ake461,--手术及操作日期7
          NULL          AS ake462,--手术级别7
          NULL          AS ake463,--手术及操作名称7
          NULL          AS ake464,--术者7
          NULL          AS ake465,--i助7
          NULL          AS ake466,--ii助7
          NULL          AS ake467,--切口等级7
          NULL          AS ake468,--切口愈合类别7
          NULL          AS ake469,--麻醉方式7
          NULL          AS ake470,--麻醉医师7
          a.sslclj      AS ake580,--实施临床路径管理标志
          NULL          AS ake581,--执行临床路径状态
          a.kzr         AS ake382,--科主任
          a.zrys        AS ake383,--主任（副主任）医师
          a.zzys        AS ake384,--主治医师
          a.zyys        AS ake385,--住院医师
          a.zrhs        AS ake386,--责任护士
          a.jxys        AS ake387,--进修医师
          a.sxys        AS ake388,--实习医师
          a.bmy         AS ake389,--编码员
          a.bazl        AS ake390,--病案质量
          a.zkys        AS ake391,--质控医师
          a.zkhs        AS ake392,--质控护士
          a.zkrq        AS ake393,--质控日期
          a.rybf        AS ake020,--入院病房
          a.cybf        AS ake321,--出院病房
          a.aaa131      AS aaa131, --撤销标志
          null        AS akeb71,--重点疾病编号
          null        AS akeb72,--重点疾病名称
          null        AS akeb73,--重点手术编号
          null        AS akeb74, --重点手术名称
          a.bke139    AS bke139 --数据批次号
            from kec1 a
          LEFT JOIN kea5 b
             ON a.akc190 = b.akc190
          WHERE a.bke701 = '0'
            AND a.AAA131 = '0'
            AND a.BkE139 = prm_bke139;
         -- kec4数据抽取
          v_insert_kec4_num := SQL%ROWCOUNT;
           --更新kec1
      UPDATE KEC1
         SET bke701 = '1'
       WHERE bke701 = '0'
         AND BkE139 = prm_bke139 --批次号
         AND AAA131 = '0'; -- 更新抽取标志
      v_update_kec1_num := SQL%ROWCOUNT;
      --更新kec2
      UPDATE KEC2
         SET bke701 = '1'
       WHERE bke701 = '0'
         AND BkE139 = prm_bke139 --批次号
         AND AAA131 = '0'; -- 更新抽取标志
      v_update_kec2_num := SQL%ROWCOUNT;
      IF v_insert_kec3_num = (v_update_kec1_num + v_update_kec2_num) AND v_insert_kec3_num = v_insert_kec4_num  THEN
         ExtractNum := v_insert_kec3_num;
         AppCode    := '1';
         ErrorMsg   := '';
         COMMIT;
      ELSE
         AppCode    := '0';
         ErrorMsg   := '抽取数据与更新数据不统一！';
         ROLLBACK;
      END IF;

   END PRC_KEC3ANDKEC4;

  /******************************************************************************/
  /*  程序包名 ：DRGs_PKG                                                */
  /*  业务环节 ：DRGs数据分析  根据ISSUE进行抽取                                       */
  /*  功能描述 ：为DRGs分析提供存储过程                                 */
  /*                                                                            */
  /*  作    者 ： all                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：                                                               */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  //      数据抽取（中西医同时）
  //      参数
  //      PRM_BKE800 IN VARCHAR2(6) 抽取期号
  //      ExtractNum OUT NUMBER 错误类型（0 成功）
  //      ERROR_MESSAGE OUT VARCHAR(50) 错误日志
  //      EXTRACTION_NUM OUT NUMBER(12) 抽数数据量
  */
       PROCEDURE PRC_KEC3ANDKEC4_ISSUE(
                              prm_bke800  IN VARCHAR2, --开始期号
                              prm_aae030  IN VARCHAR2, --开始日期
                              prm_aae031  IN VARCHAR2, --终止日期
                              prm_appcode           OUT NUMBER,  --执行代码
                              prm_errormsg          OUT VARCHAR2 --错误信息
                              ) IS
      v_insert_num      NUMBER;
      v_insert_kec3_num NUMBER;
      v_insert_kec4_num NUMBER;
      v_update_kec1_num NUMBER;
      v_update_kec2_num NUMBER;
      v_bke800    VARCHAR2(6); --开始期号
      v_aae030    VARCHAR2(8); --开始日期
      v_aae031    VARCHAR2(8); --终止日期
      v_aae001    VARCHAR2(4);--年度
      v_extract_num NUMBER(8);--抽取条数
      rec_KEM5    KEM5%ROWTYPE; --KEM5(统计信息生成日志表)
      n_tablename constant VARCHAR2(50) := 'KEC3/KEC4';--数据表名
      d_sysdate  constant DATE :=SYSDATE;--当前时间常量

   BEGIN
      v_bke800 := prm_bke800;
      v_aae030 := prm_aae030;
      v_aae031 := prm_aae031;
      v_aae001 := substr(v_bke800,0,4);
      v_extract_num :=0;

      rec_KEM5.BKE807 := pkg_comm.def_bke807_ok; --制表标志
      rec_KEM5.BAE108 := to_char(d_sysdate,pkg_comm.datetime_format); --执行开始时间
      rec_KEM5.BAE191 := NULL; --错误代码
      rec_KEM5.BAE188 := NULL; -- 错误信息

     --记录数据操作日志

     DRGs_PKG.PRC_TIMEDTASKEXELOG(v_bke800,v_aae001,n_tablename,v_aae030,v_aae031,prm_appcode,prm_errormsg);
   BEGIN
     INSERT INTO KEC3
              select
              --查询中医数据到kec3
              a.baz506            as baz506,--住院病案首页id
              a.ake554            as ake554,--住院病案首页类型
              a.akc190            as akc190,--就诊登记号
              a.akb020            as akb020,--医疗服务机构编号
              a.aaa027            as aaa027,--统筹区编码
              b.baa001            as baa001,--分中心编码
              a.aae036            as aae036,--病案上传时间
              nvl(b.aae036,a.ake100) as ake100,--结算时间
              a.username          as akb021,--医疗服务机构名称
              a.ylfkfs            AS ake300,--医疗付款方式
              a.bah               AS ake302,--病案号
              a.xm                AS aac003,--姓名
              a.xb                AS aac004,--性别
              a.csrq              AS aac006,--出生日期
              a.nl                AS akc023,--年龄
              a.bzyzs_nl          AS ake304,--(年龄不足1周岁的)年龄(月)
              a.xsetz             AS ake305,--新生儿出生体重(克)
              a.xserytz           AS ake306,--新生儿入院体重(克）
              a.mz                AS aac005,--民族
              a.sfzh              AS aac002,--身份证号
              a.xzz               AS aae006,--现住址
              a.rytj              AS ake317,--入院途径
              F_STR_TO_DATE_STR(a.rysj)    AS bkc009,--入院时间   转换
              a.rysj_s            AS ake318,--入院时间时
              replace(a.rykb,'.','')    AS akf001,--入院科别
              replace(a.zkkb,'.','')    AS ake319,--转院科别
              --(select bkec28 from kaa3 where akf001 = a.rykb and bkf014  = '2') AS akf001,--入院科别(标准)
              --(select bkec28 from kaa3 where akf001 = a.zkkb and bkf014  = '2') AS ake319,--转院科别(标准)
              F_STR_TO_DATE_STR(a.cysj)    AS bkc010,--出院时间  转换
              a.cysj_s            AS ake320,--出院时间时
              replace(a.cykb,'.','')    AS bkf002,--入院科别
              --(select bkec28 from kaa3 where akf001 = a.cykb and bkf014  = '2') AS bkf002,--出院科别(标准)
              a.sjzy              AS bkc041,--实际住院天数
              a.lyfs              AS ake471,--离院方式
              a.yzzy_jgmc         AS ake472,--医嘱转院，拟接收医疗机构名称
              a.wsy_jgmc          AS ake473,--医嘱转社区卫生服务机构/乡镇卫生院，拟接收医疗机构名称
              NVL(b.akc264, a.zfy)AS akc264,--住院费用(元)：总费用
              a.zfje              AS ake482,--自付金额
              a.ylfwf             AS ake483,--综合医疗服务类：(1)一般医疗服务费
              a.bzlzf             AS ake538,--综合医疗服务类：(1)一般医疗服务费-中医辨证论治费
              a.zyblzhzf          AS ake539,--综合医疗服务类：(1)一般医疗服务费-中医辨证论治会诊费
              a.zlczf             AS ake484,--综合医疗服务类：(2)一般治疗操作费
              a.hlf               AS alc113,--综合医疗服务类：(3)护理费
              a.qtfy              AS ake485,--综合医疗服务类：(4)其他费用
              a.blzdf             AS ake486,--诊断类：(5)病理诊断费
              a.zdf               AS ake487,--诊断类：(6)实验室诊断费
              a.yxxzdf            AS ake488,--诊断类：(7)影像学诊断费
              a.lczdxmf           AS ake489,--诊断类：(8)临床诊断项目费
              a.fsszlxmf          AS ake490,--治疗类：(9)非手术治疗项目费
              a.zlf               AS ake491,--治疗类：(9)非手术治疗项目费-临床物理治疗费
              a.sszlf             AS ake492,--治疗类：(10)手术治疗费
              a.mzf               AS ake493,--治疗类：(10)手术治疗费-麻醉费
              a.ssf               AS ake045,--治疗类：(10)手术治疗费-手术费
              a.kff               AS ake494,--康复类：(11)康复费
              a.zyl_zyzd          AS ake540,--中医类(中医和名族医医疗服务)：(12)中医诊断
              a.zyzl              AS ake541,--中医类(中医和名族医医疗服务)：(13)中医治疗
              a.zywz              AS ake542,--中医类(中医和名族医医疗服务)：(13)中医治疗-中医外治
              a.zygs              AS ake543,--中医类(中医和名族医医疗服务)：(13)中医治疗-中医骨伤
              a.zcyjf             AS ake544,--中医类(中医和名族医医疗服务)：(13)中医治疗-针刺与灸法
              a.zytnzl            AS ake545,--中医类(中医和名族医医疗服务)：(13)中医治疗-中医推拿治疗
              a.zygczl            AS ake546,--中医类(中医和名族医医疗服务)：(13)中医治疗-中医肛肠治疗
              a.zytszl            AS ake547,--中医类(中医和名族医医疗服务)：(13)中医治疗-中医特殊治疗
              a.zyqt              AS ake548,--中医类(中医和名族医医疗服务)：(14)中医其他
              a.zytstpjg          AS ake549,--中医类(中医和名族医医疗服务)：(14)中医其他-中医特殊调配加工
              a.bzss              AS ake550,--中医类(中医和名族医医疗服务)：(14)中医其他-辨证施膳
              a.xyf               AS ake047,--西药类：(15)西药费
              a.kjywf             AS ake496,--西药类：(15)西药费-抗菌药物费
              a.zcyf              AS ake050,--中药类：(16)中成药费
              a.zyzjf             AS ake551,--中药类：(16)中成药费-医疗机构中药制剂费
              a.zcyf1             AS ake049,--中药类：(17)中草药费
              a.xf                AS ake046,--血液和血液制品类：(18)血费
              a.bdblzpf           AS ake497,--血液和血液制品类：(19)白蛋白类制品费
              a.qdblzpf           AS ake498,--血液和血液制品类：(20)球蛋白类制品费
              a.nxyzlzpf          AS ake499,--血液和血液制品类：(21)凝血因子类制品费
              a.xbyzlzpf          AS ake500,--血液和血液制品类：(22)细胞因子类制品费
              a.jcyyclf           AS ake501,--耗材类：(23)检查用一次性医用材料费
              a.yyclf             AS ake502,--耗材类：(24)治疗用一次性医用材料费
              a.ssycxclf          AS ake503,--耗材类：(25)手术用一次性医用材料费
              a.qtf               AS ake044,--其他类：(26)其他费
              b.bac002            AS bac002,--人群类别
              a.aaa131            AS aaa131,--撤销标志
              a.bke139            AS bke139,--批次号
              '0'                 AS bke899,--DRG结算标志
              a.ake582            AS ake582, --病案修改次数
              replace(a.rykb,'.','')    AS bkec25,--入院科别
              replace(a.zkkb,'.','')    AS bkec26,--转科科别     
              replace(a.cykb,'.','')    AS bkec27 --出院科别 
              from kec1 a
               LEFT JOIN kea5 b
             ON a.akc190 = b.akc190 AND b.aaa131 = '0'

          WHERE a.bke701 = '0'
            AND a.AAA131 = '0'
             --结算时间根据期号判断开始结束时间
             AND a.ake100 >= to_date(v_aae030 || ' 00:00:00', 'yyyymmdd hh24:mi:ss') --结算开始时间
             AND a.ake100 <= to_date(v_aae031 || ' 23:59:59', 'yyyymmdd hh24:mi:ss') --结算终止时间

              union all

              SELECT
              --西医抽取数据到kec3
              a.baz506            as baz506,--住院病案首页id
              a.ake554            as ake554,--住院病案首页类型
              a.akc190            as akc190,--就诊登记号
              a.akb020            as akb020,--医疗服务机构编号
              a.aaa027            as aaa027,--统筹区编码
              b.baa001            as baa001,--分中心编码
              a.aae036            as aae036,--病案上传时间
              nvl(b.aae036,a.ake100)            as ake100,--结算时间
              a.username          as akb021,--医疗服务机构名称
              a.ylfkfs            AS ake300,--医疗付款方式
              a.bah               AS ake302,--病案号
              a.xm                AS aac003,--姓名
              a.xb                AS aac004,--性别
              a.csrq              AS aac006,--出生日期
              a.nl                AS akc023,--年龄
              a.bzyzsnl           AS ake304,--(年龄不足1周岁的
              a.xsecstz           AS ake305,--新生儿出生体重(克
              a.xserytz           AS ake306,--新生儿入院体重(克
              a.mz                AS aac005,--民族
              a.sfzh              AS aac002,--身份证号
              a.xzz               AS aae006,--现住址
              a.rytj              AS ake317,--入院途径
              F_STR_TO_DATE_STR(a.rysj)    AS bkc009,--入院时间   转换
              a.rysjs             AS ake318,--入院时间时
              replace(a.rykb,'.','')    AS akf001,--入院科别
              replace(a.zkkb,'.','')    AS ake319,--转院科别
              --(select bkec28 from kaa3 where akf001 = a.rykb and bkf014  = '2') AS akf001,--入院科别(标准)
              --(select bkec28 from kaa3 where akf001 = a.zkkb and bkf014  = '2') AS ake319,--转院科别(标准)
              F_STR_TO_DATE_STR(a.cysj)    AS bkc010,--出院时间  转换
              a.cysjs            AS ake320,--出院时间时
              replace(a.cykb,'.','')    AS bkf002,--入院科别
              --(select bkec28 from kaa3 where akf001 = a.cykb and bkf014  = '2') AS bkf002,--出院科别(标准)
              a.sjzyts            AS bkc041,--实际住院天数
              a.lyfs              AS ake471,--离院方式
              a.yzzy_yljg         AS ake472,--医嘱转院，拟接收医
              a.wsy_yljg          AS ake473,--医嘱转社区卫生服务
              nvl(b.akc264, a.zfy)AS akc264,--住院费用(元)：总
              a.zfje              AS ake482,--自付金额
              a.ylfuf             AS ake483,--综合医疗服务类：(
              NULL                AS ake538,--综合医疗服务类：(
              NULL                AS ake539,--综合医疗服务类：(
              a.zlczf             AS ake484,--综合医疗服务类：(
              a.hlf               AS alc113,--综合医疗服务类：(
              a.qtfy              AS ake485,--综合医疗服务类：(
              a.blzdf             AS ake486,--诊断类：(5)病理
              a.syszdf            AS ake487,--诊断类：(6)实验
              a.yxxzdf            AS ake488,--诊断类：(7)影像
              a.lczdxmf           AS ake489,--诊断类：(8)临床
              a.fsszlxmf          AS ake490,--治疗类：(9)非手
              a.wlzlf             AS ake491,--治疗类：(9)非手
              a.sszlf             AS ake492,--治疗类：(10)手
              a.maf               AS ake493,--治疗类：(10)手
              a.ssf               AS ake045,--治疗类：(10)手
              a.kff               AS ake494,--康复类：(11)康
              NULL                AS ake540,--中医类(中医和名族
              a.zyzlf             AS ake541,--中医类(中医和名族
              NULL                AS ake542,--中医类(中医和名族
              NULL                AS ake543,--中医类(中医和名族
              NULL                AS ake544,--中医类(中医和名族
              NULL                AS ake545,--中医类(中医和名族
              NULL                AS ake546,--中医类(中医和名族
              NULL                AS ake547,--中医类(中医和名族
              NULL                AS ake548,--中医类(中医和名族
              NULL                AS ake549,--中医类(中医和名族
              NULL                AS ake550,--中医类(中医和名族
              a.xyf               AS ake047,--西药类：(15)西
              a.kjywf             AS ake496,--西药类：(15)西
              a.zcyf              AS ake050,--中药类：(16)中
              NULL                AS ake551,--中药类：(16)中
              a.zcyf1             AS ake049,--中药类：(17)中
              a.xf                AS ake046,--血液和血液制品类：
              a.bdblzpf           AS ake497,--血液和血液制品类：
              a.qdblzpf           AS ake498,--血液和血液制品类：
              a.nxyzlzpf          AS ake499,--血液和血液制品类：
              a.xbyzlzpf          AS ake500,--血液和血液制品类：
              a.hcyyclf           AS ake501,--耗材类：(23)检
              a.yyclf             AS ake502,--耗材类：(24)治
              a.ycxyyclf          AS ake503,--耗材类：(25)手
              a.qtf               AS ake044,--其他类：(26)其
              b.bac002            AS bac002,--人群类别
              a.aaa131            AS aaa131, --撤销标志
              a.bke139            AS bke139,--批次号
              '0'                 AS bke899,--DRG结算标志
              a.ake582            AS ake582, --病案修改次数
              replace(a.rykb,'.','')    AS bkec25,--入院科别
              replace(a.zkkb,'.','')    AS bkec26,--转科科别     
              replace(a.cykb,'.','')    AS bkec27 --出院科别 
              from kec2 a
               LEFT JOIN kea5 b
             ON a.akc190 = b.akc190 AND b.aaa131 = '0'
          WHERE a.bke701 = '0'
            AND a.AAA131 = '0'
            --结算时间根据期号判断开始结束时间
            AND a.ake100 >= to_date(v_aae030 || ' 00:00:00', 'yyyymmdd hh24:mi:ss') --结算开始时间
            AND a.ake100 <= to_date(v_aae031 || ' 23:59:59', 'yyyymmdd hh24:mi:ss'); --结算终止时间
         -- kec3数据抽取
          v_insert_kec3_num := SQL%ROWCOUNT;


      /******************KEC3抽取结束****************/

      /*****************开始抽取KEC4表数据***********/

      insert into kec4
      select
          --西医数据抽取
          a.baz506  AS baz506,--住院病案首页id
          a.ake554  AS ake554,--住院病案首页类型
          a.akc190  AS akc190,--就诊登记号
          a.akb020  AS akb020,--医疗服务机构编号
          a.aaa027  AS aaa027,--统筹区编码
          ''        AS baa001,--分中心编码
          a.aae036  AS aae036,--病案上传时间
          nvl(b.aae036,a.ake100) AS ake100,--结算时间
          NULL      AS ake514,--主病诊断
          NULL      AS ake515,--主病诊断疾病编码
          NULL      AS ake516,--主病诊断入院病情
          a.zyzd    AS ake324,--主要诊断
          a.jbdm    AS ake325,--主要诊断疾病编码
          a.rybq    AS ake326,--主要诊断入院病情
          NULL      AS ake517,--主证诊断1
          NULL      AS ake518,--主证诊断1疾病编码
          NULL      AS ake519,--主证诊断1入院病情
          a.qtzd1   AS ake327,--其他诊断1
          a.jbdm1   AS ake328,--其他诊断1疾病编码
          a.rybq1   AS ake329,--其他诊断1入院病情
          NULL      AS ake520,--主证诊断2
          NULL      AS ake521,--主证诊断2疾病编码
          NULL      AS ake522,--主证诊断2入院病情
          a.qtzd2   AS ake330,--其他诊断2
          a.jbdm2   AS ake331,--其他诊断2疾病编码
          a.rybq2   AS ake332,--其他诊断2入院病情
          NULL      AS ake523,--主证诊断3
          NULL      AS ake524,--主证诊断3疾病编码
          NULL      AS ake525,--主证诊断3入院病情
          a.qtzd3   AS ake333,--其他诊断3
          a.jbdm3   AS ake334,--其他诊断3疾病编码
          a.rybq3   AS ake335,--其他诊断3入院病情
          NULL      AS ake526,--主证诊断4
          NULL      AS ake527,--主证诊断4疾病编码
          NULL      AS ake528,--主证诊断4入院病情
          a.qtzd4   AS ake336,--其他诊断4
          a.jbdm4   AS ake337,--其他诊断4疾病编码
          a.rybq4   AS ake338,--其他诊断4入院病情
          NULL      AS ake529,--主证诊断5
          NULL      AS ake530,--主证诊断5疾病编码
          NULL      AS ake531,--主证诊断5入院病情
          a.qtzd5   AS ake339,--其他诊断5
          a.jbdm5   AS ake340,--其他诊断5疾病编码
          a.rybq5   AS ake341,--其他诊断5入院病情
          NULL      AS ake532,--主证诊断6
          NULL      AS ake533,--主证诊断6疾病编码
          NULL      AS ake534,--主证诊断6入院病情
          a.qtzd6   AS ake342,--其他诊断6
          a.jbdm6   AS ake343,--其他诊断6疾病编码
          a.rybq6   AS ake344,--其他诊断6入院病情
          NULL      AS ake535,--主证诊断7
          NULL      AS ake536,--主证诊断7疾病编码
          NULL      AS ake537,--主证诊断7入院病情
          a.qtzd7   AS ake345,--其他诊断7
          a.jbdm7   AS ake346,--其他诊断7疾病编码
          a.rybq7   AS ake347,--其他诊断7入院病情
          a.qtzd8   AS ake348,--其他诊断8
          a.jbdm8   AS ake349,--其他诊断8疾病编码
          a.rybq8   AS ake350,--其他诊断8入院病情
          a.qtzd9   AS ake351,--其他诊断9
          a.jbdm9   AS ake352,--其他诊断9疾病编码
          a.rybq9   AS ake353,--其他诊断9入院病情
          a.qtzd10  AS ake354,--其他诊断10
          a.jbdm10  AS ake355,--其他诊断10疾病编码
          a.rybq10  AS ake356,--其他诊断10入院病情
          a.qtzd11  AS ake357,--其他诊断11
          a.jbdm11  AS ake358,--其他诊断11疾病编码
          a.rybq11  AS ake359,--其他诊断11入院病情
          a.qtzd12  AS ake360,--其他诊断12
          a.jbdm12  AS ake361,--其他诊断12疾病编码
          a.rybq12  AS ake362,--其他诊断12入院病情
          a.qtzd13  AS ake363,--其他诊断13
          a.jbdm13  AS ake364,--其他诊断13疾病编码
          a.rybq13  AS ake365,--其他诊断13入院病情
          a.qtzd14  AS ake366,--其他诊断14
          a.jbdm14  AS ake367,--其他诊断14疾病编码
          a.rybq14  AS ake368,--其他诊断14入院病情
          a.qtzd15  AS ake369,--其他诊断15
          a.jbdm15  AS ake370,--其他诊断15疾病编码
          a.rybq15  AS ake371,--其他诊断15入院病情
          a.ssjczbm1    AS ake394,--手术及操作编码1
          a.ssjczrq1    AS ake395,--手术及操作日期1
          a.ssjb1       AS ake396,--手术级别1
          a.ssjczmc1    AS ake397,--手术及操作名称1
          a.sz1         AS ake398,--术者1
          a.yz1         AS ake399,--i助1
          a.ez1         AS ake400,--ii助1
          a.qkdj1       AS ake401,--切口等级1
          a.qkyhlb1     AS ake402,--切口愈合类别1
          a.mzfs1       AS ake403,--麻醉方式1
          a.mzys1       AS ake404,--麻醉医师1
          a.ssjczbm2    AS ake405,--手术及操作编码2
          a.ssjczrq2    AS ake406,--手术及操作日期2
          a.ssjb2       AS ake407,--手术级别2
          a.ssjczmc2    AS ake408,--手术及操作名称2
          a.sz2         AS ake409,--术者2
          a.yz2         AS ake410,--i助2
          a.ez2         AS ake411,--ii助2
          a.qkdj2       AS ake412,--切口等级2
          a.qkyhlb2     AS ake413,--切口愈合类别2
          a.mzfs2       AS ake414,--麻醉方式2
          a.mzys2       AS ake415,--麻醉医师2
          a.ssjczbm3    AS ake416,--手术及操作编码3
          a.ssjczrq3    AS ake417,--手术及操作日期3
          a.ssjb3       AS ake418,--手术级别3
          a.ssjczmc3    AS ake419,--手术及操作名称3
          a.sz3         AS ake420,--术者3
          a.yz3         AS ake421,--i助3
          a.ez3         AS ake422,--ii助3
          a.qkdj3       AS ake423,--切口等级3
          a.qkyhlb3     AS ake424,--切口愈合类别3
          a.mzfs3       AS ake425,--麻醉方式3
          a.mzys3       AS ake426,--麻醉医师3
          a.ssjczbm4    AS ake427,--手术及操作编码4
          a.ssjczrq4    AS ake428,--手术及操作日期4
          a.ssjb4       AS ake429,--手术级别4
          a.ssjczmc4    AS ake430,--手术及操作名称4
          a.sz4         AS ake431,--术者4
          a.yz4         AS ake432,--i助4
          a.ez4         AS ake433,--ii助4
          a.qkdj4       AS ake434,--切口等级4
          a.qkyhlb4     AS ake435,--切口愈合类别4
          a.mzfs4       AS ake436,--麻醉方式4
          a.mzys4       AS ake437,--情况麻醉医师4
          a.ssjczbm5    AS ake438,--手术及操作编码5
          a.ssjczrq5    AS ake439,--手术及操作日期5
          a.ssjb5       AS ake440,--手术级别5
          a.ssjczmc5    AS ake441,--手术及操作名称5
          a.sz5         AS ake442,--术者5
          a.yz5         AS ake443,--i助5
          a.ez5         AS ake444,--ii助5
          a.qkdj5       AS ake445,--切口等级5
          a.qkyhlb5     AS ake446,--切口愈合类别5
          a.mzfs5       AS ake447,--麻醉方式5
          a.mzys5       AS ake448,--麻醉医师5
          a.ssjczbm6    AS ake449,--手术及操作编码6
          a.ssjczrq6    AS ake450,--手术及操作日期6
          a.ssjb6       AS ake451,--手术级别6
          a.ssjczmc6    AS ake452,--手术及操作名称6
          a.sz6         AS ake453,--术者6
          a.yz6         AS ake454,--i助6
          a.ez6         AS ake455,--ii助6
          a.qkdj6       AS ake456,--切口等级6
          a.qkyhlb6     AS ake457,--切口愈合类别6
          a.mzfs6       AS ake458,--麻醉方式6
          a.mzys6       AS ake459,--麻醉医师6
          a.ssjczbm7  AS ake460,--手术及操作编码7
          a.ssjczrq7  AS ake461,--手术及操作日期7
          a.ssjb7     AS ake462,--手术级别7
          a.ssjczmc7  AS ake463,--手术及操作名称7
          a.sz7       AS ake464,--术者7
          a.yz7       AS ake465,--i助7
          a.ez7       AS ake466,--ii助7
          a.qkdj7     AS ake467,--切口等级7
          a.qkyhlb7   AS ake468,--切口愈合类别7
          a.mzfs7     AS ake469,--麻醉方式7
          a.mzys7     AS ake470,--麻醉医师7
          NULL        AS ake580,--实施临床路径管理标志
          NULL        AS ake581,--执行临床路径状态
          a.kzr       AS ake382,--科主任
          a.zrys      AS ake383,--主任（副主任）医师
          a.zzys      AS ake384,--主治医师
          a.zyys      AS ake385,--住院医师
          a.zrhs      AS ake386,--责任护士
          a.jxys      AS ake387,--进修医师
          a.sxys      AS ake388,--实习医师
          a.bmy       AS ake389,--编码员
          a.bazl      AS ake390,--病案质量
          a.zkys      AS ake391,--质控医师
          a.zkhs      AS ake392,--质控护士
          a.zkrq      AS ake393,--质控日期
          a.rybf      AS ake020,--入院病房
          a.cybf      AS ake321,--出院病房
          a.aaa131    AS aaa131, --撤销标志
          null        AS akeb71,--重点疾病编号
          null        AS akeb72,--重点疾病名称
          null        AS akeb73,--重点手术编号
          null        AS akeb74, --重点手术名称
          a.bke139    AS bke139 --数据批次号
          from kec2 a
          LEFT JOIN kea5 b
             ON a.akc190 = b.akc190 AND b.aaa131 = '0'
             --结算时间根据期号判断开始结束时间
          WHERE a.bke701 = '0'
            AND a.AAA131 = '0'
            --结算时间根据期号判断开始结束时间
            AND a.ake100 >= to_date(v_aae030 || ' 00:00:00', 'yyyymmdd hh24:mi:ss') --结算开始时间
            AND a.ake100 <= to_date(v_aae031 || ' 23:59:59', 'yyyymmdd hh24:mi:ss') --结算终止时间
          union all

          SELECT
          --中医数据抽取
          a.baz506      AS baz506,--住院病案首页id
          a.ake554      AS ake554,--住院病案首页类型
          a.akc190      AS akc190,--就诊登记号
          a.akb020      AS akb020,--医疗服务机构编号
          a.aaa027      AS aaa027,--统筹区编码
          ''            AS baa001,--分中心编码
          a.aae036      AS aae036,--病案上传时间
          nvl(b.aae036,a.ake100)  AS ake100,--结算时间
          a.zb          AS ake514,--主病诊断
          a.zb_jbbm     AS ake515,--主病诊断疾病编码
          a.zb_rybq     AS ake516,--主病诊断入院病情
          a.zyzd        AS ake324,--主要诊断
          a.zyzd_jbbm   AS ake325,--主要诊断疾病编码
          a.xy_rybq     AS ake326,--主要诊断入院病情
          a.zz1         AS ake517,--主证诊断1
          a.zz_jbbm1    AS ake518,--主证诊断1疾病编码
          a.zz_rybq1    AS ake519,--主证诊断1入院病情
          a.qtzd1       AS ake327,--其他诊断1
          a.zyzd_jbbm1  AS ake328,--其他诊断1疾病编码
          a.rybq1       AS ake329,--其他诊断1入院病情
          a.zz2         AS ake520,--主证诊断2
          a.zz_jbbm2    AS ake521,--主证诊断2疾病编码
          a.zz_rybq2    AS ake522,--主证诊断2入院病情
          a.qtzd1       AS ake330,--其他诊断2
          a.zyzd_jbbm2  AS ake331,--其他诊断2疾病编码
          a.rybq2       AS ake332,--其他诊断2入院病情
          a.zz3         AS ake523,--主证诊断3
          a.zz_jbbm3    AS ake524,--主证诊断3疾病编码
          a.zz_rybq3    AS ake525,--主证诊断3入院病情
          a.qtzd3       AS ake333,--其他诊断3
          a.zyzd_jbbm3  AS ake334,--其他诊断3疾病编码
          a.rybq3       AS ake335,--其他诊断3入院病情
          a.zz4         AS ake526,--主证诊断4
          a.zz_jbbm4    AS ake527,--主证诊断4疾病编码
          a.zz_rybq4    AS ake528,--主证诊断4入院病情
          a.qtzd4       AS ake336,--其他诊断4
          a.zyzd_jbbm4  AS ake337,--其他诊断4疾病编码
          a.rybq4       AS ake338,--其他诊断4入院病情
          a.zz5         AS ake529,--主证诊断5
          a.zz_jbbm5    AS ake530,--主证诊断5疾病编码
          a.zz_rybq5    AS ake531,--主证诊断5入院病情
          a.qtzd5       AS ake339,--其他诊断5
          a.zyzd_jbbm5  AS ake340,--其他诊断5疾病编码
          a.rybq5       AS ake341,--其他诊断5入院病情
          a.zz6         AS ake532,--主证诊断6
          a.zz_jbbm6    AS ake533,--主证诊断6疾病编码
          a.zz_rybq6    AS ake534,--主证诊断6入院病情
          a.qtzd6       AS ake342,--其他诊断6
          a.zyzd_jbbm6  AS ake343,--其他诊断6疾病编码
          a.rybq6       AS ake344,--其他诊断6入院病情
          a.zz7         AS ake535,--主证诊断7
          a.zz_jbbm7    AS ake536,--主证诊断7疾病编码
          a.zz_rybq7    AS ake537,--主证诊断7入院病情
          a.qtzd7       AS ake345,--其他诊断7
          a.zyzd_jbbm7  AS ake346,--其他诊断7疾病编码
          a.rybq7       AS ake347,--其他诊断7入院病情
          NULL          AS ake348,--其他诊断8
          NULL          AS ake349,--其他诊断8疾病编码
          NULL          AS ake350,--其他诊断8入院病情
          NULL          AS ake351,--其他诊断9
          NULL          AS ake352,--其他诊断9疾病编码
          NULL          AS ake353,--其他诊断9入院病情
          NULL          AS ake354,--其他诊断10
          NULL          AS ake355,--其他诊断10疾病编码
          NULL          AS ake356,--其他诊断10入院病情
          NULL          AS ake357,--其他诊断11
          NULL          AS ake358,--其他诊断11疾病编码
          NULL          AS ake359,--其他诊断11入院病情
          NULL          AS ake360,--其他诊断12
          NULL          AS ake361,--其他诊断12疾病编码
          NULL          AS ake362,--其他诊断12入院病情
          NULL          AS ake363,--其他诊断13
          NULL          AS ake364,--其他诊断13疾病编码
          NULL          AS ake365,--其他诊断13入院病情
          NULL          AS ake366,--其他诊断14
          NULL          AS ake367,--其他诊断14疾病编码
          NULL          AS ake368,--其他诊断14入院病情
          NULL          AS ake369,--其他诊断15
          NULL          AS ake370,--其他诊断15疾病编码
          NULL          AS ake371,--其他诊断15入院病情
          a.ssjczbm1    AS ake394,--手术及操作编码1
          a.ssjczrq1    AS ake395,--手术及操作日期1
          a.shjb1       AS ake396,--手术级别1
          a.ssjczmc1    AS ake397,--手术及操作名称1
          a.sz1         AS ake398,--术者1
          a.yz1         AS ake399,--i助1
          a.ez1         AS ake400,--ii助1
          a.qkdj1       AS ake401,--切口等级1
          a.qkylb1      AS ake402,--切口愈合类别1
          a.mzfs1       AS ake403,--麻醉方式1
          a.mzys1       AS ake404,--麻醉医师1
          a.ssjczbm2    AS ake405,--手术及操作编码2
          a.ssjczrq2    AS ake406,--手术及操作日期2
          a.shjb2       AS ake407,--手术级别2
          a.ssjczmc2    AS ake408,--手术及操作名称2
          a.sz2         AS ake409,--术者2
          a.yz2         AS ake410,--i助2
          a.ez2         AS ake411,--ii助2
          a.qkdj2       AS ake412,--切口等级2
          a.qkylb2      AS ake413,--切口愈合类别2
          a.mzfs2       AS ake414,--麻醉方式2
          a.mzys2       AS ake415,--麻醉医师2
          a.ssjczbm3    AS ake416,--手术及操作编码3
          a.ssjczrq3    AS ake417,--手术及操作日期3
          a.shjb3       AS ake418,--手术级别3
          a.ssjczmc3    AS ake419,--手术及操作名称3
          a.sz3         AS ake420,--术者3
          a.yz3         AS ake421,--i助3
          a.ez3         AS ake422,--ii助3
          a.qkdj3       AS ake423,--切口等级3
          a.qkylb3      AS ake424,--切口愈合类别3
          a.mzfs3       AS ake425,--麻醉方式3
          a.mzys3       AS ake426,--麻醉医师3
          a.ssjczbm4    AS ake427,--手术及操作编码4
          a.ssjczrq4    AS ake428,--手术及操作日期4
          a.shjb4       AS ake429,--手术级别4
          a.ssjczmc4    AS ake430,--手术及操作名称4
          a.sz4         AS ake431,--术者4
          a.yz4         AS ake432,--i助4
          a.ez4         AS ake433,--ii助4
          a.qkdj4       AS ake434,--切口等级4
          a.qkylb4      AS ake435,--切口愈合类别4
          a.mzfs4       AS ake436,--麻醉方式4
          a.mzys4       AS ake437,--情况麻醉医师4
          a.ssjczbm5    AS ake438,--手术及操作编码5
          a.ssjczrq5    AS ake439,--手术及操作日期5
          a.shjb5       AS ake440,--手术级别5
          a.ssjczmc5    AS ake441,--手术及操作名称5
          a.sz5         AS ake442,--术者5
          a.yz5         AS ake443,--i助5
          a.ez5         AS ake444,--ii助5
          a.qkdj5       AS ake445,--切口等级5
          a.qkylb5      AS ake446,--切口愈合类别5
          a.mzfs5       AS ake447,--麻醉方式5
          a.mzys5       AS ake448,--麻醉医师5
          a.ssjczbm6    AS ake449,--手术及操作编码6
          a.ssjczrq6    AS ake450,--手术及操作日期6
          a.shjb6       AS ake451,--手术级别6
          a.ssjczmc6    AS ake452,--手术及操作名称6
          a.sz6         AS ake453,--术者6
          a.yz6         AS ake454,--i助6
          a.ez6         AS ake455,--ii助6
          a.qkdj6       AS ake456,--切口等级6
          a.qkylb6      AS ake457,--切口愈合类别6
          a.mzfs6       AS ake458,--麻醉方式6
          a.mzys6       AS ake459,--麻醉医师6
          NULL          AS ake460,--手术及操作编码7
          NULL          AS ake461,--手术及操作日期7
          NULL          AS ake462,--手术级别7
          NULL          AS ake463,--手术及操作名称7
          NULL          AS ake464,--术者7
          NULL          AS ake465,--i助7
          NULL          AS ake466,--ii助7
          NULL          AS ake467,--切口等级7
          NULL          AS ake468,--切口愈合类别7
          NULL          AS ake469,--麻醉方式7
          NULL          AS ake470,--麻醉医师7
          a.sslclj      AS ake580,--实施临床路径管理标志
          NULL          AS ake581,--执行临床路径状态
          a.kzr         AS ake382,--科主任
          a.zrys        AS ake383,--主任（副主任）医师
          a.zzys        AS ake384,--主治医师
          a.zyys        AS ake385,--住院医师
          a.zrhs        AS ake386,--责任护士
          a.jxys        AS ake387,--进修医师
          a.sxys        AS ake388,--实习医师
          a.bmy         AS ake389,--编码员
          a.bazl        AS ake390,--病案质量
          a.zkys        AS ake391,--质控医师
          a.zkhs        AS ake392,--质控护士
          a.zkrq        AS ake393,--质控日期
          a.rybf        AS ake020,--入院病房
          a.cybf        AS ake321,--出院病房
          a.aaa131      AS aaa131, --撤销标志
          null        AS akeb71,--重点疾病编号
          null        AS akeb72,--重点疾病名称
          null        AS akeb73,--重点手术编号
          null        AS akeb74, --重点手术名称
          a.bke139    AS bke139 --数据批次号
            from kec1 a
          LEFT JOIN kea5 b
             ON a.akc190 = b.akc190 AND b.aaa131 = '0'
          WHERE a.bke701 = '0'
            AND a.AAA131 = '0'--结算时间根据期号判断开始结束时间
            AND a.ake100 >= to_date(v_aae030 || ' 00:00:00', 'yyyymmdd hh24:mi:ss') --结算开始时间
            AND a.ake100 <= to_date(v_aae031 || ' 23:59:59', 'yyyymmdd hh24:mi:ss'); --结算终止时间

         -- kec4数据抽取
          v_insert_kec4_num := SQL%ROWCOUNT;
           --更新kec1
      UPDATE KEC1
         SET bke701 = '1'
       WHERE bke701 = '0'
        AND ake100 >= to_date(v_aae030 || ' 00:00:00', 'yyyymmdd hh24:mi:ss') --结算开始时间
        AND ake100 <= to_date(v_aae031 || ' 23:59:59', 'yyyymmdd hh24:mi:ss') --结算终止时间
        AND AAA131 = '0'; -- 更新抽取标志
      v_update_kec1_num := SQL%ROWCOUNT;
      --更新kec2
      UPDATE KEC2
         SET bke701 = '1'
       WHERE bke701 = '0'
         AND ake100 >= to_date(v_aae030 || ' 00:00:00', 'yyyymmdd hh24:mi:ss') --结算开始时间
         AND ake100 <= to_date(v_aae031 || ' 23:59:59', 'yyyymmdd hh24:mi:ss') --结算终止时间
         AND AAA131 = '0'; -- 更新抽取标志
      v_update_kec2_num := SQL%ROWCOUNT;
      IF v_insert_kec3_num = (v_update_kec1_num + v_update_kec2_num) AND v_insert_kec3_num = v_insert_kec4_num  THEN
         v_extract_num := v_insert_kec3_num;
         prm_appcode   := pkg_comm.def_ok;
         prm_errormsg  := '';
         rec_KEM5.AAE013 :='抽取数据【'||v_extract_num||'】';
         COMMIT;
      ELSE
         prm_appcode    := pkg_comm.def_err;
         prm_errormsg := '抽取数据与更新数据不统一！';
         rec_KEM5.BKE807 := pkg_comm.def_bke807_err; --制表标志
         rec_KEM5.BAE191 := prm_appcode; --错误代码
         rec_KEM5.BAE188 := prm_errormsg; -- 错误信息
         rec_KEM5.AAE013 :='抽取数据【'||v_extract_num||'】';
         ROLLBACK;
      END IF;

   EXCEPTION
      WHEN OTHERS THEN
         prm_appcode  := pkg_comm.def_err;
         prm_errormsg := '关键字段表【KEC3/KEC4】生成出错：' || SQLERRM;
         rec_KEM5.BKE807 := pkg_comm.def_bke807_err; --制表标志
         rec_KEM5.BAE191 := prm_appcode; --错误代码
         rec_KEM5.BAE188 := prm_errormsg; -- 错误信息
   END;
    --更新KEM5 日志表
      rec_KEM5.BAE109 := to_char(SYSDATE,pkg_comm.datetime_format); --执行结束时间
      UPDATE KEM5
         SET BKE807 = rec_KEM5.BKE807, --制表标志
             BAE108 = rec_KEM5.BAE108, --执行开始时间
             BAE109 = rec_KEM5.BAE109, --执行结束时间
             BAE191 = rec_KEM5.BAE191, --错误代码
             BAE188 = rec_KEM5.BAE188, --错误信息
             AAE013 = rec_KEM5.AAE013 --备注
       WHERE bke800 = prm_bke800 --统计期号
         AND aae001 = v_aae001 --年度
         AND bke805 = n_tablename --表名
         AND bke807 IS NULL; --制表标志

   EXCEPTION
      WHEN OTHERS THEN
         prm_appcode  := pkg_comm.def_err;
         prm_errormsg := '关键字段表【KEC3/KEC4】生成出错：' || SQLERRM;

   END PRC_KEC3ANDKEC4_ISSUE;
   /******************************************************************************/
  /*  程序包名 ：DRGs_PKG                                                */
  /*  业务环节 ：DRGs数据分析                                            */
  /*  功能描述 ：为DRGs分析提供存储过程                                 */
  /*                                                                            */
  /*  作    者 ： hzq                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：                                                               */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  //      数据抽取（中西医同时）
  //      参数
  //      ERROR_TYPE OUT VARCHAR(2) 错误类型（0 成功）
  //      ERROR_MESSAGE OUT VARCHAR(50) 错误日志
  //      EXTRACTION_NUM OUT NUMBER(12) 抽数数据量
  */
     PROCEDURE PRC_KEB7ANDKEB8(
           prm_bke139 IN VARCHAR2,
           prm_appcode OUT NUMBER,
           prm_errormsg OUT VARCHAR2
                         ) IS
        v_sql     varchar2(4000); --sql语句
        num       number;  --临时表数据量
        /*定义考核指标配置游标*/
        CURSOR CUR_KAB1 IS
           select bke780,bke035 from kab1;
   BEGIN
       /* 变量初始化 */
       prm_appcode  := pkg_comm.def_ok;
       v_sql :='insert into KEM4 select a.BAZ506,a.AKE554,a.AKC190,';
        /*遍历考核指标配置游标*/
        FOR rec_KAB1 IN CUR_KAB1 LOOP
           v_sql := v_sql || 'case when ' || rec_KAB1.bke780 || ' IS NULL THEN '|| rec_KAB1.bke035 || ' else 0 end as '||rec_KAB1.bke780 ||',';
        end loop;
        v_sql := v_sql || '100';
        FOR rec_KAB1 IN CUR_KAB1 LOOP
           v_sql := v_sql || ' - case when ' || rec_KAB1.bke780 || ' IS NULL THEN '|| rec_KAB1.bke035 || ' else 0 end';
        end loop;
        v_sql := v_sql || ' as BKE886 from kec4 a,kec3 b where a.BAZ506 = b.BAZ506 and b.bke139 =' || prm_bke139;
       execute immediate v_sql ;
       insert into keb8(
            aaz721  ,-- 病案首页考核评分id
            baz506  ,-- 住院病案首页id
            ake554  ,-- 住院病案首页类型
            akc190  ,-- 就诊登记号
            bke781  ,-- 考核主体
            bke782  ,-- 病案总分
            aae011  ,-- 经办人
            aae036  ,-- 经办时间
            aaa131  ,-- 撤销标志
            aae013  --  备注
        ) select se_aaz721.nextVal as aaz721,
                 a.baz506,
                 a.ake554,
                 a.akc190,
                 '1',
                 a.BKE886,
                 'SystemAuto',
                 sysdate,
                 '0',
                 ''
        from KEM4 a;
       /* FOR rec_KAB1 IN CUR_KAB1 LOOP
          insert into keb7(aaz720,aaz721,baz506,ake554,akc190,bke780,bke035,aae011,aae036,aaa131,aae013,bke781) select se_aaz720.nextVal as aaz720,b.aaz721,a.baz506,a.ake554,a.akc190,rec_KAB1.bke780, rec_KAB1.bke035,'SystemAuto',sysdate,'0','','' from KEM4 a,keb8 b where a.baz506 = b.baz506 ;
        end loop;*/
       --v_keb7_sql := substr(v_keb7_sql,1,instr(v_keb7_sql,'union all',-1)-1);
       -- dbms_output.put_line(v_keb7_sql);
       -- execute immediate v_keb7_sql ;
       COMMIT;
       EXCEPTION
         WHEN OTHERS THEN
            prm_appcode     := pkg_comm.def_err;
            prm_errormsg    := '【KEB7/KEB8】病案质量得分计算有误：' || SQLERRM;
         ROLLBACK;
   end PRC_KEB7ANDKEB8;

     /******************************************************************************/
  /*  程序包名 ：DRGs_PKG                                                */
  /*  业务环节 ：DRGs数据分析    根据批次号bke139抽取                        */
  /*  功能描述 ：为DRGs分析提供存储过程                                  */
  /*                                                                            */
  /*  作    者 ： all                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：                                                               */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  //      数据抽取（中西医同时）
  //      参数
  //      prm_bke139 IN VARCHAR(2)   批次号
  //      prm_appcode OUT VARCHAR(2) 调用存储过程 prm_appcode 成功状态
  //      prm_errormsg OUT VARCHAR(50) 错误日志
  //      EXTRACTION_NUM OUT NUMBER(12) 抽数数据量
  */
       PROCEDURE PRC_KEB7ANDKEB8_ALL(
                         prm_appcode  OUT NUMBER, --执行代码
                         prm_errormsg OUT VARCHAR2--错误信息
                         )
                  IS
            v_sql     varchar2(4000); --sql语句
            num       number;  --临时表数据量
            /*定义考核指标配置游标*/
            CURSOR CUR_KAB1 IS
               select bke780,bke035 from kab1;
             BEGIN
                   /* 变量初始化 */
       prm_appcode  := pkg_comm.def_ok;
       v_sql :='insert into KEM4 select a.BAZ506,a.AKE554,a.AKC190,';
        /*遍历考核指标配置游标*/
        FOR rec_KAB1 IN CUR_KAB1 LOOP
           v_sql := v_sql || 'case when ' || rec_KAB1.bke780 || ' IS NULL THEN '|| rec_KAB1.bke035 || ' else 0 end as '||rec_KAB1.bke780 ||',';
        end loop;
        v_sql := v_sql || '100';
        FOR rec_KAB1 IN CUR_KAB1 LOOP
           v_sql := v_sql || ' - case when ' || rec_KAB1.bke780 || ' IS NULL THEN '|| rec_KAB1.bke035 || ' else 0 end';
        end loop;
        v_sql := v_sql || ' as BKE886 from kec4 a,kec3 b where a.BAZ506 = b.BAZ506 ';
       execute immediate v_sql ;
       insert into keb8(
            aaz721  ,-- 病案首页考核评分id
            baz506  ,-- 住院病案首页id
            ake554  ,-- 住院病案首页类型
            akc190  ,-- 就诊登记号
            bke781  ,-- 考核主体
            bke782  ,-- 病案总分
            aae011  ,-- 经办人
            aae036  ,-- 经办时间
            aaa131  ,-- 撤销标志
            aae013  --  备注
        ) select se_aaz721.nextVal as aaz721,
                 a.baz506,
                 a.ake554,
                 a.akc190,
                 '1',
                 a.BKE886,
                 'SystemAuto',
                 sysdate,
                 '0',
                 ''
        from KEM4 a;
      /*  FOR rec_KAB1 IN CUR_KAB1 LOOP
          insert into keb7(aaz720,aaz721,baz506,ake554,akc190,bke780,bke035,aae011,aae036,aaa131,aae013,bke781) select se_aaz720.nextVal as aaz720,b.aaz721,a.baz506,a.ake554,a.akc190,rec_KAB1.bke780, rec_KAB1.bke035,'SystemAuto',sysdate,'0','','' from KEM4 a,keb8 b where a.baz506 = b.baz506 ;
        end loop;*/

        COMMIT;
        EXCEPTION
        WHEN OTHERS THEN
            prm_appcode     := pkg_comm.def_err;
            prm_errormsg    := '【KEB7/KEB8】病案质量得分计算有误：' || SQLERRM;
         ROLLBACK;
   END PRC_KEB7ANDKEB8_ALL;

  /******************************************************************************/
  /*  程序包名 ：DRGs_PKG                                                */
  /*  业务环节 ：DRGs数据分析  根据ISSUE 抽取                                          */
  /*  功能描述 ：为DRGs分析提供存储过程                                 */
  /*                                                                            */
  /*  作    者 ： all                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：                                                               */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  //      数据抽取（中西医同时）
  //      参数
  //      prm_bke800 IN VARCHAR(6)   期号
  //      prm_appcode OUT VARCHAR(2) 调用存储过程 prm_appcode 成功状态
  //      prm_errormsg OUT VARCHAR(50) 错误日志
  //      EXTRACTION_NUM OUT NUMBER(12) 抽数数据量
  */
       PROCEDURE PRC_KEB7ANDKEB8_ISSUE(
                         prm_bke800  IN VARCHAR2, --开始期号
                         prm_aae030  IN VARCHAR2, --开始日期
                         prm_aae031  IN VARCHAR2, --终止日期
                         prm_appcode  OUT NUMBER, --执行代码
                         prm_errormsg OUT VARCHAR2--错误信息
                         )
          IS
        v_sql     varchar2(4000); --sql语句
        num       number;  --临时表数据量
        v_insert_keb8_num NUMBER(8);--数据抽取计数
        v_bke800    VARCHAR2(6); --开始期号
        v_aae030    VARCHAR2(8); --开始日期
        v_aae031    VARCHAR2(8); --终止日期
        v_aae001    VARCHAR2(4);--年度
        v_aae030_sql VARCHAR2(60);--开始时间格式
        v_aae031_sql VARCHAR2(60);--结束时间格式
        n_tablename constant VARCHAR2(50) := 'KEB7/KEB8';--数据表名
        rec_KEM5    KEM5%ROWTYPE; --KEM5(统计信息生成日志表)
        d_sysdate  constant DATE :=SYSDATE;--当前时间常量

        /*定义考核指标配置游标*/
        CURSOR CUR_KAB1 IS
           select bke780,bke035 from kab1;
   BEGIN
      v_bke800 := prm_bke800;
      v_aae030 := prm_aae030;
      v_aae031 := prm_aae031;
      prm_appcode := pkg_comm.def_ok;
      prm_errormsg :='';
      v_insert_keb8_num :=0;
      v_aae001 :=substr(v_bke800,0,4);
      v_aae030_sql := v_aae030 || ' 00:00:00';
      v_aae031_sql := v_aae031 || ' 23:59:59';

      rec_KEM5.BKE807 := pkg_comm.def_bke807_ok; --制表标志
      rec_KEM5.BAE108 := to_char(d_sysdate,pkg_comm.datetime_format); --执行开始时间
      rec_KEM5.BAE191 := NULL; --错误代码
      rec_KEM5.BAE188 := NULL; -- 错误信息
      --记录数据操作日志

       DRGs_PKG.PRC_TIMEDTASKEXELOG(v_bke800,v_aae001,n_tablename,v_aae030,v_aae031,prm_appcode,prm_errormsg);
    BEGIN
       /* 变量初始化 */
       prm_appcode  := pkg_comm.def_ok;
       v_sql :='insert into KEM4 select a.BAZ506,a.AKE554,a.AKC190,';
        /*遍历考核指标配置游标*/
        FOR rec_KAB1 IN CUR_KAB1 LOOP
           v_sql := v_sql || 'case when ' || rec_KAB1.bke780 || ' IS NULL THEN '|| rec_KAB1.bke035 || ' else 0 end as '||rec_KAB1.bke780 ||',';
        end loop;
        v_sql := v_sql || '100';
        FOR rec_KAB1 IN CUR_KAB1 LOOP
           v_sql := v_sql || ' - case when ' || rec_KAB1.bke780 || ' IS NULL THEN '|| rec_KAB1.bke035 || ' else 0 end';
        end loop;



        v_sql := v_sql || ' as BKE886 from kec4 a,kec3 b where a.BAZ506 = b.BAZ506 AND b.ake100 >= to_date('''|| v_aae030_sql ||''', ''yyyymmdd hh24:mi:ss'')'
            || ' AND b.ake100 <= to_date('''|| v_aae031_sql ||''', ''yyyymmdd hh24:mi:ss'')';

       dbms_output.put_line(v_sql);
       execute immediate v_sql ;
       insert into keb8(
            aaz721  ,-- 病案首页考核评分id
            baz506  ,-- 住院病案首页id
            ake554  ,-- 住院病案首页类型
            akc190  ,-- 就诊登记号
            bke781  ,-- 考核主体
            bke782  ,-- 病案总分
            aae011  ,-- 经办人
            aae036  ,-- 经办时间
            aaa131  ,-- 撤销标志
            aae013  --  备注
        ) select se_aaz721.nextVal as aaz721,
                 a.baz506,
                 a.ake554,
                 a.akc190,
                 '1',
                 a.BKE886,
                 'SystemAuto',
                 sysdate,
                 '0',
                 ''
        from KEM4 a;
        -- kec4数据抽取
        v_insert_keb8_num := SQL%ROWCOUNT;
       /* FOR rec_KAB1 IN CUR_KAB1 LOOP
          insert into keb7(aaz720,aaz721,baz506,ake554,akc190,bke780,bke035,aae011,aae036,aaa131,aae013,bke781) select se_aaz720.nextVal as aaz720,b.aaz721,a.baz506,a.ake554,a.akc190,rec_KAB1.bke780, rec_KAB1.bke035,'SystemAuto',sysdate,'0','','' from KEM4 a,keb8 b where a.baz506 = b.baz506 ;
        END LOOP;*/
        rec_KEM5.AAE013 :='抽取数据【'||v_insert_keb8_num||'】';
       COMMIT;
       EXCEPTION
         WHEN OTHERS THEN
            prm_appcode     := pkg_comm.def_err;
            prm_errormsg    := '【KEB7/KEB8】病案质量得分计算有误：' || SQLERRM;
            rec_KEM5.BKE807 := pkg_comm.def_bke807_err; --制表标志
            rec_KEM5.BAE191 := prm_appcode; --错误代码
            rec_KEM5.BAE188 := prm_errormsg; -- 错误信息
            rec_KEM5.AAE013 :='抽取数据【'||v_insert_keb8_num||'】';
         ROLLBACK;
       END;
       --更新KEM5 日志表
      rec_KEM5.BAE109 := to_char(SYSDATE,pkg_comm.datetime_format); --执行结束时间
      UPDATE KEM5
         SET BKE807 = rec_KEM5.BKE807, --制表标志
             BAE108 = rec_KEM5.BAE108, --执行开始时间
             BAE109 = rec_KEM5.BAE109, --执行结束时间
             BAE191 = rec_KEM5.BAE191, --错误代码
             BAE188 = rec_KEM5.BAE188, --错误信息
             AAE013 = rec_KEM5.AAE013 --备注
       WHERE bke800 = prm_bke800 --统计期号
         AND aae001 = v_aae001 --年度
         AND bke805 = n_tablename --表名
         AND bke807 IS NULL; --制表标志

  EXCEPTION
     WHEN OTHERS THEN
        prm_appcode  := pkg_comm.def_err;
        prm_errormsg := '关键字段表【KEB7/KEB8】生成出错：' || SQLERRM;

     END PRC_KEB7ANDKEB8_ISSUE;

  /******************************************************************************/
  /*  程序包名 ：DRG支付                                                             */
  /*  业务环节 ：DRG支付运算支付存储过程                                             */
  /*  功能描述 ：根据批次号进行测试开发                            */
  /*                                                                              */
  /*  作    者 ： all                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：                                                               */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  */
   PROCEDURE PRC_DRGPAYMENTAUTO(
          prm_bke139            IN  VARCHAR2,--执行批次号
          prm_drgPaymentCount   OUT NUMBER,  --累计DRG结算人次
          prm_appcode           OUT NUMBER,  --执行代码
          prm_errormsg          OUT VARCHAR2 --错误信息
        ) IS

        v_baz506 VARCHAR2(20);--病案首页ID
        v_ake471 VARCHAR2(3);--离院方式
        v_bkc041 NUMBER(4);  --实际住院天数
        v_akc264 NUMBER(12,2);--医疗总费用
        v_ake039 NUMBER(12,2);--医保基金支付费用
        v_bka033 VARCHAR2(30);--单病种编码
        v_aka130 VARCHAR2(10);--医疗类型 52生育，光明工程211
        v_bac002 VARCHAR2(3);--人群类别
        v_bke716 VARCHAR2(20);--DRG病种编码
        v_aka101 VARCHAR2(6);--医院等级
        v_bke139 VARCHAR2(20);--批次号
        v_bke901 VARCHAR2(3);--支付类型
        v_aae013 VARCHAR2(100);--备注
        v_bke904 VARCHAR2(6);--原项目支付类型 P01
        v_bke778_count NUMBER(6);--支付标准总数

        bke901_0 CONSTANT VARCHAR2(3) := '0';--支付类型 0 自费 1 基金按原项目支付 2 基金按DRG支付
        bke901_1 CONSTANT VARCHAR2(3) := '1';--支付类型 0 自费 1 基金按原项目支付 2 基金按DRG支付
        bke901_2 CONSTANT VARCHAR2(3) := '2';--支付类型 0 自费 1 基金按原项目支付 2 基金按DRG支付
        ake471_5 CONSTANT VARCHAR2(3) := '5';--离院方式 5|05 死亡
        ake471_05 CONSTANT VARCHAR2(3) := '05';--离院方式 5|05 死亡
        bkc041_3 CONSTANT NUMBER := 3;--实际住院天数 3
        bkc041_60 CONSTANT NUMBER := 60;--实际住院天数 60
        aka130_52 CONSTANT VARCHAR2(4) :='52';--生育住院
        aka130_211 CONSTANT VARCHAR2(4) :='211';--光明工程
        bac002_1 CONSTANT VARCHAR2(2) :='1';--人群类别 1|01 城镇
        bac002_01 CONSTANT VARCHAR2(2) :='01';--人群类别 1|01  城镇
        bac002_2 CONSTANT VARCHAR2(2) :='2';--人群类别 2|02 城乡
        bac002_02 CONSTANT VARCHAR2(2) :='02';--人群类别 2|02 城乡
        bac002_3 CONSTANT VARCHAR2(2) :='3';--人群类别 3 离退休
        bac002_03 CONSTANT VARCHAR2(2) :='03';--人群类别 03 离退休

        n_p01 CONSTANT VARCHAR2(6) := 'P01';-- P01 医保联网结算支付金额为0或空
        n_p02 CONSTANT VARCHAR2(6) := 'P02';-- P02 离院方式为死亡离院
        n_p03 CONSTANT VARCHAR2(6) := 'P03';-- P03 住院天数大于60天或小于3天
        n_p04 CONSTANT VARCHAR2(6) := 'P04';-- P04 病案具有单病种编码
        n_p05 CONSTANT VARCHAR2(6) := 'P05';-- P05 病案是生育住院
        n_p06 CONSTANT VARCHAR2(6) := 'P06';-- P06 病案是光明工程
        n_p07 CONSTANT VARCHAR2(6) := 'P07';-- P07 病案人群类别属于离退休人员
        n_p08 CONSTANT VARCHAR2(6) := 'P08';-- P08 总费用是否超出支付标准的限制
        n_p09 CONSTANT VARCHAR2(6) := 'P09';-- P09 病案未入组或DRG组没有支付标准
        n_p10 CONSTANT VARCHAR2(6) := 'P10';-- P10 城乡大病支付大于0
        n_p11 CONSTANT VARCHAR2(6) := 'P11';-- P09 病案未入组或DRG组没有支付标准

        n_drg_9999 CONSTANT VARCHAR2(4) := '9999';--入组错误情况
        n_bke742_1 CONSTANT VARCHAR2(2) :='1';--入组成功
        bke777_0 CONSTANT VARCHAR2(2) :='0';--未启用 0 未启用，1 启用
        bke777_1 CONSTANT VARCHAR2(2) :='1';--启用 0 未启用，1 启用

        --原项目支付类别开启状态
        v_p01 VARCHAR2(2); -- P01 医保联网结算支付金额为0或空
        v_p02 VARCHAR2(2); -- P02 离院方式为死亡离院
        v_p03 VARCHAR2(2); -- P03 住院天数大于60天或小于3天
        v_p04 VARCHAR2(2); -- P04 病案具有单病种编码
        v_p05 VARCHAR2(2); -- P05 病案是生育住院
        v_p06 VARCHAR2(2); -- P06 病案是光明工程
        v_p07 VARCHAR2(2); -- P07 病案人群类别属于离退休人员
        v_p08 VARCHAR2(2); -- P08 总费用是否超出支付标准的限制
        v_p09 VARCHAR2(2); -- P09 病案未入组或DRG组没有支付标准
        v_p10 VARCHAR2(2); -- P10 城乡大病支付大于0
        v_p11 VARCHAR2(2); -- P11 城镇18种重大疾病

        v_bke902 VARCHAR2(6);--按项目支付类别
        bke777 VARCHAR2(2);--开启状态
        --城镇18种重大疾病ICD-10
        v_icd10 NUMBER;



        --定义病案游标
         CURSOR CUR_KEC3(p_bke139 VARCHAR2) IS
           SELECT
               a.baz506,--病案首页ID
               a.ake471,--离院方式
               a.bkc041,--实际住院天数
               c.akc264,--住院总费用
               c.ake039,--医保基金支付费用
               c.ake029,--大额基金支付费用
               c.bka033,--单病种编码
               c.aka130,--医疗类型 52生育，光明工程211
               c.bac002,--人群类别 ，
               b.bke716,--drg组
               b.bke742,--入组标志 1入组成功
               d.aka101,--医院等级
               e.ake325 --主要诊断
        FROM KEC3 a

        inner join kec4 e on a.baz506 = e.baz506
        inner join kea4 b on a.baz506 = b.baz506
        left  join kea5 c on a.akc190 = c.akc190 and c.aaa131 = '0' --撤销标志
        inner join kb01 d on a.akb020 = d.akb020

        where
            a.aaa131 = '0' --撤销标志
        and b.aaa131 = '0' --撤销标志
        and a.bke899 = '0' --结算标志
        and a.bke139 = p_bke139; --批次号

        --定义支付标准游标
        CURSOR CUR_KAC1(p_aka101 VARCHAR2,p_bke716 VARCHAR2) IS
        SELECT
         a.bke756*b.bke778 as lower_sum,
         a.bke756 as lower,
         a.bke755*b.bke778 as upper_sum,
         a.bke755 as upper,
         b.bke778 as bke778,
         b.aaz735 as aaz735
          FROM KAC1 a , KAC2 b  WHERE
         a.aaz734 = b.aaz734
         AND a.aaa131 = '0'
         AND a.bke777 = '1'
         AND a.aka101 = p_aka101
         AND b.bke716 = p_bke716;

         --定义过滤条件游标
         CURSOR CUR_KAC3 IS
         select bke902,bke777 from  kac3 where aaa131 = '0' and bke777 = '1' order by bke902;


    BEGIN
      prm_drgPaymentCount :=0;--初始化为0条
      v_bke904 :='';
      IF prm_bke139 IS NULL THEN
        prm_appcode := PKG_COMM.def_err;
        prm_errormsg := '批次号不能为空';
        RETURN;

      END IF;

      --循环kac3的数据获取开关状态
      FOR CUR_KAC3_RECORD IN CUR_KAC3 LOOP
          IF CUR_KAC3_RECORD.BKE902 = n_p01 THEN
            v_p01 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p02 THEN
            v_p02 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p03 THEN
            v_p03 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p04 THEN
            v_p04 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p05 THEN
            v_p05 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p06 THEN
            v_p06 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p07 THEN
            v_p07 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p08 THEN
            v_p08 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p09 THEN
            v_p09 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p10 THEN
            v_p10 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p11 THEN
            v_p11 := CUR_KAC3_RECORD.BKE777;
          END IF;
        END LOOP;

      --循环kec3制定批次的数据进行数据drg测算
      FOR curr_kec3_record in CUR_KEC3(prm_bke139) LOOP

        prm_drgPaymentCount := prm_drgPaymentCount+1;

        v_aae013 :='按基金DRG支付';--默认按DRG
        v_bke901 := bke901_2;--默认按DRG支付
        v_baz506 := curr_kec3_record.baz506;

        /*第1、层判断是否为医保支付病案 */
        v_ake039 :=nvl(curr_kec3_record.ake039,0)+nvl(curr_kec3_record.ake029,0);
        if v_p01 = bke777_1 then --开关
          if v_ake039 <=0 or v_ake039 is null then
             --P01
             v_aae013 :='医保联网结算支付金额为0或空，全自费';
             v_bke901 := bke901_0;
             v_bke904 := 'P01';

             DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
             IF prm_appcode = pkg_comm.def_ok then
               continue;
             ELSE
               return;
             END IF;

           end if;
         end if;

        /*第2、层判断是否为死亡离院病案 */
         if v_p02 = bke777_1 then --开关
            v_ake471 :=curr_kec3_record.ake471;
            if v_ake471=ake471_5 or v_ake471=ake471_05 then
               --P02
               v_aae013 :='离院方式为死亡离院，按基金原项目支付';
               v_bke901 := bke901_1;
               v_bke904 := 'P02';

               DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
               IF prm_appcode = pkg_comm.def_ok then
                 continue;
               ELSE
                 return;
               END IF;

             end if;
          end if;

         /*第3、层判断是否为住院天数不满足DRG支付范围病案 */
         if v_p03 = bke777_1 then --开关
            v_bkc041 :=curr_kec3_record.bkc041;
            if v_bkc041 > bkc041_60 or v_bkc041 < bkc041_3 then
              --P03
               v_aae013 :='住院天数大于60天或小于3天，按基金原项目支付';
               v_bke901 := bke901_1;
               v_bke904 := 'P03';

               DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
               IF prm_appcode = pkg_comm.def_ok then
                 continue;
               ELSE
                 return;
               END IF;

             end if;
         end if;

        /*第4、层城镇单病种，或城乡22种重大疾病判断 */

            v_bka033 :=curr_kec3_record.bka033;--单病种
            if v_bka033 is not null then
                if v_p04 = bke777_1 then --开关
                 --P04
                 v_aae013 :='病案具有单病种编码，按基金原项目支付';
                 v_bke901 := bke901_1;
                 v_bke904 := 'P04';

                 DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                 IF prm_appcode = pkg_comm.def_ok then
                   continue;
                 ELSE
                   return;
                 END IF;
               end if;
              ELSE
                IF v_p11 = bke777_1 THEN --开关
                    SELECT COUNT(1) INTO v_icd10 FROM KAB9 WHERE AAE100 = '1' AND AKA120 = curr_kec3_record.ake325 and bac002 = curr_kec3_record.bac002;
                    IF v_icd10 > 0 THEN
                       --P11
                       v_aae013 :='病案属于城镇18种重大疾病，按基金原项目支付';
                       v_bke901 := bke901_1;
                       v_bke904 := 'P11';

                       DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                       IF prm_appcode = pkg_comm.def_ok THEN
                         continue;
                       ELSE
                         return;
                       END IF;
                     END IF;
                END IF;
              END IF;


        /*第5、层城生育住院，和光明工程判断 */
         v_aka130 := curr_kec3_record.aka130;
         if v_aka130 = aka130_52 then
            --P05
             if v_p05 = bke777_1 then --开关
                v_aae013 :='病案是生育住院，按基金原项目支付';
                v_bke901 := bke901_1;
                v_bke904 := 'P05';

                 DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                 IF prm_appcode = pkg_comm.def_ok then
                   continue;
                 ELSE
                   return;
                 END IF;
             end if;

           elsif v_aka130=aka130_211 then
            --P06
              if v_p06 = bke777_1 then --开关
                   v_aae013 :='病案是光明工程，按基金原项目支付';
                   v_bke901 := bke901_1;
                   v_bke904 := 'P06';

                   DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                   IF prm_appcode = pkg_comm.def_ok then
                     continue;
                   ELSE
                     return;
                   END IF;
               end if;

             end if;

        /*第6、层人群类别为离退休人员判断 */
        if v_p07 = bke777_1 then --开关
          v_bac002 :=  curr_kec3_record.bac002;--人群类别
            if  v_bac002 = bac002_03 or v_bac002 = bac002_3 then
              --P07
              v_aae013 :='病案人群类别属于离退休人员，按基金原项目支付';
              v_bke901 := bke901_1;
              v_bke904 := 'P07';

              DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
             IF prm_appcode = pkg_comm.def_ok then
               continue;
             ELSE
               return;
             END IF;

            end if;
         end if;

         /*第7、层判断城乡大病支付是否大于0*/
          if v_p10 = bke777_1 then --开关
                v_bac002 :=  curr_kec3_record.bac002;--人群类别
            if ( v_bac002 = bac002_2 or v_bac002 = bac002_02) and curr_kec3_record.ake029 >0 then
              --P10
              v_aae013 :='城乡居民大病支付大于0，按基金原项目支付';
              v_bke901 := bke901_1;
              v_bke904 := 'P10';
              DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
             IF prm_appcode = pkg_comm.def_ok then
               continue;
             ELSE
               return;
             END IF;

            end if;
          end if;

        /*第8、层判断总费用是否超出支付标准的剔除上限或低于支付标准的剔除下限 P08*/
        v_akc264 :=curr_kec3_record.akc264;
        v_aka101 :=curr_kec3_record.aka101;
        v_bke716 :=curr_kec3_record.bke716;
       --查询是否有支付标准
        SELECT
         count(b.aaz735)
        INTO
         v_bke778_count
        FROM KAC1 a , KAC2 b  WHERE
         a.aaz734 = b.aaz734
         AND a.aaa131 = '0'
         AND a.bke777 = '1'
         AND a.aka101 = v_aka101
         AND b.bke716 = v_bke716;

       IF v_bke778_count>0 THEN
          FOR curr_drg_standard in CUR_KAC1(v_aka101,v_bke716) LOOP
           if curr_drg_standard.bke778>0 then
              if v_p08 = bke777_1 then --开关
                  if v_akc264 > curr_drg_standard.upper_sum or v_akc264 < curr_drg_standard.lower_sum then
                     --P08
                     v_aae013 :='医疗总费用大于支付标准'|| curr_drg_standard.upper||'倍或小于'||curr_drg_standard.lower||'倍，按基金原项目支付';
                     v_bke901 := bke901_1;
                     v_bke904 := 'P08';

                     DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                     IF prm_appcode = pkg_comm.def_ok then
                       continue;
                     ELSE
                       return;
                     END IF;

                     ELSE
                     --按DRG支付插入数据
                     v_aae013 :='DRG支付';
                     v_bke901 := bke901_2;
                     DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,curr_drg_standard.bke778,curr_drg_standard.upper_sum,curr_drg_standard.lower_sum,null,curr_drg_standard.aaz735,prm_appcode,prm_errormsg);
                     IF prm_appcode = pkg_comm.def_ok then
                       continue;
                     ELSE
                       return;
                     END IF;

                  END IF;
                else

                 --按DRG支付插入数据  不开启支付标准范围
                 v_aae013 :='DRG支付';
                 v_bke901 := bke901_2;
                 DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,curr_drg_standard.bke778,curr_drg_standard.upper_sum,curr_drg_standard.lower_sum,null,curr_drg_standard.aaz735,prm_appcode,prm_errormsg);
                 IF prm_appcode = pkg_comm.def_ok then
                   continue;
                 ELSE
                   return;
                 END IF;

               end if;
          else
                 --P09
                 v_aae013 :='病案未入组或DRG组没有支付标准，按基金原项目支付';
                 v_bke901 := bke901_1;
                 v_bke904 := 'P09';

                 DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                 IF prm_appcode = pkg_comm.def_ok then
                   continue;
                 ELSE
                   return;
                 END IF;

           END IF;
          END LOOP;
         ELSE

             --第8、入组失败的或者病组的二、三级对应的支付标准为null 数据走原项目支付
             --P09
             v_aae013 :='病案未入组或DRG组没有支付标准，按基金原项目支付';
             v_bke901 := bke901_1;
             v_bke904 := 'P09';

             DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
             IF prm_appcode = pkg_comm.def_ok then
               continue;
             ELSE
               return;
             END IF;

       END IF;




        END LOOP;
    --提交
    COMMIT;
    EXCEPTION
    WHEN OTHERS THEN
      prm_appcode := pkg_comm.def_err;
      prm_errormsg := '执行失败: '||SQLERRM;
      --回滚
      ROLLBACK;
    END PRC_DRGPAYMENTAUTO;

    /******************************************************************************/
  /*  程序包名 ：DRG支付                                                             */
  /*  业务环节 ：DRG支付运算支付存储过程     根据ISSUE进行抽取                                                 */
  /*  功能描述 ：根据批次号进行DRG支付计算                            */
  /*                                                                              */
  /*  作    者 ： all                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：                                                               */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  */
       PROCEDURE PRC_DRGPAYMENTAUTO_ISSUE(
          prm_bke800            IN VARCHAR2, --开始期号
          prm_aae030            IN VARCHAR2, --开始日期
          prm_aae031            IN VARCHAR2, --终止日期
          prm_appcode           OUT NUMBER,  --执行代码
          prm_errormsg          OUT VARCHAR2 --错误信息
        ) IS

        v_baz506 VARCHAR2(20);--病案首页ID
        v_ake471 VARCHAR2(3);--离院方式
        v_bkc041 NUMBER(4);  --实际住院天数
        v_akc264 NUMBER(12,2);--医疗总费用
        v_ake039 NUMBER(12,2);--医保基金支付费用
        v_bka033 VARCHAR2(30);--单病种编码
        v_aka130 VARCHAR2(10);--医疗类型 52生育，光明工程211
        v_bac002 VARCHAR2(3);--人群类别
        v_bke716 VARCHAR2(20);--DRG病种编码
        v_aka101 VARCHAR2(6);--医院等级
        v_bke139 VARCHAR2(20);--批次号
        v_bke901 VARCHAR2(3);--支付类型
        v_aae013 VARCHAR2(100);--备注
        v_bke904 VARCHAR2(6);--原项目支付类型 P01
        v_bke778_count NUMBER(6);--支付标准总数

        bke901_0 CONSTANT VARCHAR2(3) := '0';--支付类型 0 自费 1 基金按原项目支付 2 基金按DRG支付
        bke901_1 CONSTANT VARCHAR2(3) := '1';--支付类型 0 自费 1 基金按原项目支付 2 基金按DRG支付
        bke901_2 CONSTANT VARCHAR2(3) := '2';--支付类型 0 自费 1 基金按原项目支付 2 基金按DRG支付
        ake471_5 CONSTANT VARCHAR2(3) := '5';--离院方式 5|05 死亡
        ake471_05 CONSTANT VARCHAR2(3) := '05';--离院方式 5|05 死亡
        bkc041_3 CONSTANT NUMBER := 3;--实际住院天数 3
        bkc041_60 CONSTANT NUMBER := 60;--实际住院天数 60
        aka130_52 CONSTANT VARCHAR2(4) :='52';--生育住院
        aka130_211 CONSTANT VARCHAR2(4) :='211';--光明工程
        bac002_1 CONSTANT VARCHAR2(2) :='1';--人群类别 1|01 城镇
        bac002_01 CONSTANT VARCHAR2(2) :='01';--人群类别 1|01  城镇
        bac002_2 CONSTANT VARCHAR2(2) :='2';--人群类别 2|02 城乡
        bac002_02 CONSTANT VARCHAR2(2) :='02';--人群类别 2|02 城乡
        bac002_3 CONSTANT VARCHAR2(2) :='3';--人群类别 3 离退休
        bac002_03 CONSTANT VARCHAR2(2) :='03';--人群类别 03 离退休

        n_p01 CONSTANT VARCHAR2(6) := 'P01';-- P01 医保联网结算支付金额为0或空
        n_p02 CONSTANT VARCHAR2(6) := 'P02';-- P02 离院方式为死亡离院
        n_p03 CONSTANT VARCHAR2(6) := 'P03';-- P03 住院天数大于60天或小于3天
        n_p04 CONSTANT VARCHAR2(6) := 'P04';-- P04 病案具有单病种编码
        n_p05 CONSTANT VARCHAR2(6) := 'P05';-- P05 病案是生育住院
        n_p06 CONSTANT VARCHAR2(6) := 'P06';-- P06 病案是光明工程
        n_p07 CONSTANT VARCHAR2(6) := 'P07';-- P07 病案人群类别属于离退休人员
        n_p08 CONSTANT VARCHAR2(6) := 'P08';-- P08 总费用是否超出支付标准的限制
        n_p09 CONSTANT VARCHAR2(6) := 'P09';-- P09 病案未入组或DRG组没有支付标准
        n_p10 CONSTANT VARCHAR2(6) := 'P10';-- P10 城乡大病支付大于0
        n_p11 CONSTANT VARCHAR2(6) := 'P11';-- P11 城镇18种重大疾病

        n_drg_9999 CONSTANT VARCHAR2(4) := '9999';--入组错误情况
        n_bke742_1 CONSTANT VARCHAR2(2) :='1';--入组成功
        bke777_0 CONSTANT VARCHAR2(2) :='0';--未启用 0 未启用，1 启用
        bke777_1 CONSTANT VARCHAR2(2) :='1';--启用 0 未启用，1 启用
        d_sysdate CONSTANT DATE :=SYSDATE;--当前日期
        n_tablename CONSTANT VARCHAR2(20) :='KEC7';--执行表

        --原项目支付类别开启状态
        v_p01 VARCHAR2(2); -- P01 医保联网结算支付金额为0或空
        v_p02 VARCHAR2(2); -- P02 离院方式为死亡离院
        v_p03 VARCHAR2(2); -- P03 住院天数大于60天或小于3天
        v_p04 VARCHAR2(2); -- P04 病案具有单病种编码
        v_p05 VARCHAR2(2); -- P05 病案是生育住院
        v_p06 VARCHAR2(2); -- P06 病案是光明工程
        v_p07 VARCHAR2(2); -- P07 病案人群类别属于离退休人员
        v_p08 VARCHAR2(2); -- P08 总费用是否超出支付标准的限制
        v_p09 VARCHAR2(2); -- P09 病案未入组或DRG组没有支付标准
        v_p10 VARCHAR2(2); -- P10 城乡大病支付大于0
        v_p11 VARCHAR2(2); -- P11 城镇18种重大疾病

        v_bke902 VARCHAR2(6);--按项目支付类别
        bke777 VARCHAR2(2);--开启状态

        v_icd10 NUMBER;--城镇18种重大疾病ICD-10
        v_bke800  VARCHAR2(6);--执行期号
        v_aae030  VARCHAR2(8);--执行开始时间
        v_aae031  VARCHAR2(8);--执行结算时间
        v_aae001  VARCHAR2(4);--执行年度
        v_insert_count NUMBER(8);--执行总数
        rec_KEM5 KEM5%ROWTYPE;--KEM5 日志记录表

        --定义病案游标
         CURSOR CUR_KEC3(p_aae030 VARCHAR2 ,p_aae031 VARCHAR2) IS
           SELECT
               a.baz506,--病案首页ID
               a.ake471,--离院方式
               a.bkc041,--实际住院天数
               c.akc264,--住院总费用
               c.ake039,--医保基金支付费用
               c.ake029,--大额基金支付费用
               c.bka033,--单病种编码
               c.aka130,--医疗类型 52生育，光明工程211
               c.bac002,--人群类别 ，
               b.bke716,--drg组
               b.bke742,--入组标志 1入组成功
               d.aka101,--医院等级
               e.ake325 --主要诊断
        FROM KEC3 a

        inner join kec4 e on a.baz506 = e.baz506
        inner join kea4 b on a.baz506 = b.baz506
        left  join kea5 c on a.akc190 = c.akc190 and c.aaa131 = '0' --撤销标志
        inner join kb01 d on a.akb020 = d.akb020

        where
            a.aaa131 = '0' --撤销标志
        and b.aaa131 = '0' --撤销标志
        and a.bke899 = '0' --结算标志
        -- 结算时间范围
        and a.ake100 >= to_date(p_aae030 || ' 00:00:00', 'yyyymmdd hh24:mi:ss') --结算开始时间
        and a.ake100 <= to_date(p_aae031 || ' 23:59:59', 'yyyymmdd hh24:mi:ss'); --结算终止时间

        --定义支付标准游标
        CURSOR CUR_KAC1(p_aka101 VARCHAR2,p_bke716 VARCHAR2) IS
        SELECT
         a.bke756*b.bke778 as lower_sum,
         a.bke756 as lower,
         a.bke755*b.bke778 as upper_sum,
         a.bke755 as upper,
         b.bke778 as bke778,
         b.aaz735 as aaz735
          FROM KAC1 a , KAC2 b  WHERE
         a.aaz734 = b.aaz734
         AND a.aaa131 = '0'
         AND a.bke777 = '1'
         AND a.aka101 = p_aka101
         AND b.bke716 = p_bke716;

         --定义过滤条件游标
         CURSOR CUR_KAC3 IS
         select bke902,bke777 from  kac3 where aaa131 = '0' and bke777 = '1' order by bke902;

    BEGIN
        v_insert_count := 0;--初始化为0条
        v_bke904 := '';
        v_bke800 := prm_bke800;
        v_aae030 := prm_aae030;
        v_aae031 := prm_aae031;
        prm_appcode  := pkg_comm.def_ok;
        prm_errormsg := '';
        v_aae001 :=substr(v_bke800,0,4);

        rec_KEM5.BKE807 := pkg_comm.def_bke807_ok; --制表标志
        rec_KEM5.BAE108 := to_char(d_sysdate,pkg_comm.datetime_format); --执行开始时间
        rec_KEM5.BAE191 := NULL; --错误代码
        rec_KEM5.BAE188 := NULL; -- 错误信息
        --记录数据操作日志

         DRGs_PKG.PRC_TIMEDTASKEXELOG(v_bke800,v_aae001,n_tablename,v_aae030,v_aae031,prm_appcode,prm_errormsg);
      BEGIN
      --循环kac3的数据获取开关状态
      FOR CUR_KAC3_RECORD IN CUR_KAC3 LOOP
          IF CUR_KAC3_RECORD.BKE902 = n_p01 THEN
            v_p01 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p02 THEN
            v_p02 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p03 THEN
            v_p03 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p04 THEN
            v_p04 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p05 THEN
            v_p05 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p06 THEN
            v_p06 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p07 THEN
            v_p07 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p08 THEN
            v_p08 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p09 THEN
            v_p09 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p10 THEN
            v_p10 := CUR_KAC3_RECORD.BKE777;
          ELSIF CUR_KAC3_RECORD.BKE902 = n_p11 THEN
            v_p11 := CUR_KAC3_RECORD.BKE777;
          END IF;
        END LOOP;

      --循环kec3制定批次的数据进行数据drg测算
      FOR curr_kec3_record in CUR_KEC3(v_aae030,v_aae031) LOOP

        v_insert_count := v_insert_count+1;

        v_aae013 :='按基金DRG支付';--默认按DRG
        v_bke901 := bke901_2;--默认按DRG支付
        v_baz506 := curr_kec3_record.baz506;

        /*第1、层判断是否为医保支付病案 */
        v_ake039 :=nvl(curr_kec3_record.ake039,0)+nvl(curr_kec3_record.ake029,0);
        if v_p01 = bke777_1 then --开关
          if v_ake039 <=0 or v_ake039 is null then
             --P01
             v_aae013 :='医保联网结算支付金额为0或空，全自费';
             v_bke901 := bke901_0;
             v_bke904 := 'P01';

             DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
             IF prm_appcode = pkg_comm.def_ok then
               continue;
             ELSE
               return;
             END IF;

           end if;
         end if;

        /*第2、层判断是否为死亡离院病案 */
         if v_p02 = bke777_1 then --开关
            v_ake471 :=curr_kec3_record.ake471;
            if v_ake471=ake471_5 or v_ake471=ake471_05 then
               --P02
               v_aae013 :='离院方式为死亡离院，按基金原项目支付';
               v_bke901 := bke901_1;
               v_bke904 := 'P02';

               DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
               IF prm_appcode = pkg_comm.def_ok then
                 continue;
               ELSE
                 return;
               END IF;

             end if;
          end if;

         /*第3、层判断是否为住院天数不满足DRG支付范围病案 */
         if v_p03 = bke777_1 then --开关
            v_bkc041 :=curr_kec3_record.bkc041;
            if v_bkc041 > bkc041_60 or v_bkc041 < bkc041_3 then
              --P03
               v_aae013 :='住院天数大于60天或小于3天，按基金原项目支付';
               v_bke901 := bke901_1;
               v_bke904 := 'P03';

               DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
               IF prm_appcode = pkg_comm.def_ok then
                 continue;
               ELSE
                 return;
               END IF;

             end if;
         end if;

        /*第4、层城镇单病种，或城乡22种重大疾病判断 */

            v_bka033 :=curr_kec3_record.bka033;--单病种
            if v_bka033 is not null then
                if v_p04 = bke777_1 then --开关
                 --P04
                 v_aae013 :='病案具有单病种编码，按基金原项目支付';
                 v_bke901 := bke901_1;
                 v_bke904 := 'P04';

                 DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                 IF prm_appcode = pkg_comm.def_ok then
                   continue;
                 ELSE
                   return;
                 END IF;
               end if;
              ELSE
                IF v_p11 = bke777_1 THEN --开关
                    SELECT COUNT(1) INTO v_icd10 FROM KAB9 WHERE AAE100 = '1' AND AKA120 = curr_kec3_record.ake325 and bac002 = curr_kec3_record.bac002;
                    IF v_icd10 > 0 THEN
                       --P11
                       v_aae013 :='病案属于城镇18种重大疾病，按基金原项目支付';
                       v_bke901 := bke901_1;
                       v_bke904 := 'P11';

                       DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                       IF prm_appcode = pkg_comm.def_ok THEN
                         continue;
                       ELSE
                         return;
                       END IF;
                     END IF;
                END IF;
              END IF;


        /*第5、层城生育住院，和光明工程判断 */
         v_aka130 := curr_kec3_record.aka130;
         if v_aka130 = aka130_52 then
            --P05
             if v_p05 = bke777_1 then --开关
                v_aae013 :='病案是生育住院，按基金原项目支付';
                v_bke901 := bke901_1;
                v_bke904 := 'P05';

                 DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                 IF prm_appcode = pkg_comm.def_ok then
                   continue;
                 ELSE
                   return;
                 END IF;
             end if;

           elsif v_aka130=aka130_211 then
            --P06
              if v_p06 = bke777_1 then --开关
                   v_aae013 :='病案是光明工程，按基金原项目支付';
                   v_bke901 := bke901_1;
                   v_bke904 := 'P06';

                   DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                   IF prm_appcode = pkg_comm.def_ok then
                     continue;
                   ELSE
                     return;
                   END IF;
               end if;

             end if;

        /*第6、层人群类别为离退休人员判断 */
        if v_p07 = bke777_1 then --开关
          v_bac002 :=  curr_kec3_record.bac002;--离院方式
            if  v_bac002 = bac002_03 or v_bac002 = bac002_3 then
              --P07
              v_aae013 :='病案人群类别属于离退休人员，按基金原项目支付';
              v_bke901 := bke901_1;
              v_bke904 := 'P07';

              DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
             IF prm_appcode = pkg_comm.def_ok then
               continue;
             ELSE
               return;
             END IF;

            end if;
         end if;

          /*第7、层判断城乡大病支付是否大于0*/
          if v_p10 = bke777_1 then --开关
                v_bac002 :=  curr_kec3_record.bac002;--人群类别
            if ( v_bac002 = bac002_2 or v_bac002 = bac002_02) and curr_kec3_record.ake029 >0 then
              --P10
              v_aae013 :='城乡居民大病支付大于0，按基金原项目支付';
              v_bke901 := bke901_1;
              v_bke904 := 'P10';
              DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
             IF prm_appcode = pkg_comm.def_ok then
               continue;
             ELSE
               return;
             END IF;

            end if;
          end if;

        /*第8、层判断总费用是否超出支付标准的剔除上限或低于支付标准的剔除下限 P08*/
        v_akc264 :=curr_kec3_record.akc264;
        v_aka101 :=curr_kec3_record.aka101;
        v_bke716 :=curr_kec3_record.bke716;
       --查询是否有支付标准
        SELECT
         count(b.aaz735)
        INTO
         v_bke778_count
        FROM KAC1 a , KAC2 b  WHERE
         a.aaz734 = b.aaz734
         AND a.aaa131 = '0'
         AND a.bke777 = '1'
         AND a.aka101 = v_aka101
         AND b.bke716 = v_bke716;

       IF v_bke778_count>0 THEN
          FOR curr_drg_standard in CUR_KAC1(v_aka101,v_bke716) LOOP
           if curr_drg_standard.bke778>0 then
              if v_p08 = bke777_1 then --开关
                  if v_akc264 > curr_drg_standard.upper_sum or v_akc264 < curr_drg_standard.lower_sum then
                     --P08
                     v_aae013 :='医疗总费用大于支付标准'|| curr_drg_standard.upper||'倍或小于'||curr_drg_standard.lower||'倍，按基金原项目支付';
                     v_bke901 := bke901_1;
                     v_bke904 := 'P08';

                     DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                     IF prm_appcode = pkg_comm.def_ok then
                       continue;
                     ELSE
                       return;
                     END IF;

                     ELSE
                     --按DRG支付插入数据
                     v_aae013 :='DRG支付';
                     v_bke901 := bke901_2;
                     DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,curr_drg_standard.bke778,curr_drg_standard.upper_sum,curr_drg_standard.lower_sum,null,curr_drg_standard.aaz735,prm_appcode,prm_errormsg);
                     IF prm_appcode = pkg_comm.def_ok then
                       continue;
                     ELSE
                       return;
                     END IF;

                  END IF;
                else

                 --按DRG支付插入数据  不开启支付标准范围
                 v_aae013 :='DRG支付';
                 v_bke901 := bke901_2;
                 DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,curr_drg_standard.bke778,curr_drg_standard.upper_sum,curr_drg_standard.lower_sum,null,curr_drg_standard.aaz735,prm_appcode,prm_errormsg);
                 IF prm_appcode = pkg_comm.def_ok then
                   continue;
                 ELSE
                   return;
                 END IF;

               end if;
          else
                 --P09
                 v_aae013 :='病案未入组或DRG组没有支付标准，按基金原项目支付';
                 v_bke901 := bke901_1;
                 v_bke904 := 'P09';

                 DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
                 IF prm_appcode = pkg_comm.def_ok then
                   continue;
                 ELSE
                   return;
                 END IF;

           END IF;
          END LOOP;
         ELSE

             --第8、入组失败的或者病组的二、三级对应的支付标准为null 数据走原项目支付
             --P09
             v_aae013 :='病案未入组或DRG组没有支付标准，按基金原项目支付';
             v_bke901 := bke901_1;
             v_bke904 := 'P09';

             DRGs_PKG.PRC_INSERTKEC7AUTO(v_baz506,v_bke901,v_aae013,null,null,null,v_bke904,null,prm_appcode,prm_errormsg);
             IF prm_appcode = pkg_comm.def_ok then
               continue;
             ELSE
               return;
             END IF;

       END IF;

        END LOOP;
        --提交
        COMMIT;
         rec_KEM5.AAE013 :='抽取数据【'||v_insert_count||'】';
        --执行数据处理异常
        EXCEPTION
        WHEN OTHERS THEN
          prm_appcode := pkg_comm.def_err;
          prm_errormsg := '【KEC7】数据抽取执行失败: '||SQLERRM;
          --回滚
          ROLLBACK;
          rec_KEM5.BKE807 := pkg_comm.def_bke807_err; --制表标志
          rec_KEM5.BAE191 := prm_appcode; --错误代码
          rec_KEM5.BAE188 := prm_errormsg; -- 错误信息
          rec_KEM5.AAE013 :='抽取数据【'||v_insert_count||'】';
        END;
        --更新KEM5 日志表
      rec_KEM5.BAE109 := to_char(SYSDATE,pkg_comm.datetime_format); --执行结束时间
      UPDATE KEM5
         SET BKE807 = rec_KEM5.BKE807, --制表标志
             BAE108 = rec_KEM5.BAE108, --执行开始时间
             BAE109 = rec_KEM5.BAE109, --执行结束时间
             BAE191 = rec_KEM5.BAE191, --错误代码
             BAE188 = rec_KEM5.BAE188, --错误信息
             AAE013 = rec_KEM5.AAE013 --备注
       WHERE bke800 = prm_bke800 --统计期号
         AND aae001 = v_aae001 --年度
         AND bke805 = n_tablename --表名
         AND bke807 IS NULL; --制表标志
       --更新日志表异常
       EXCEPTION
      WHEN OTHERS THEN
        prm_appcode := pkg_comm.def_err;
        prm_errormsg := '【KEC7】数据抽取执行失败: '||SQLERRM;
        END PRC_DRGPAYMENTAUTO_ISSUE;

    /******************************************************************************/
  /*  程序包名 ：DRG支付                                                            */
  /*  业务环节 ：DRG支付数据插入                                          */
  /*  功能描述 ：根据病案首页号进行数据插入                            */
  /*                                                                              */
  /*  作    者 ： all                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：                                                               */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  */
     PROCEDURE PRC_INSERTKEC7AUTO(
        prm_baz506            IN  VARCHAR2,--病案首页ID
        prm_bke901            IN  VARCHAR2,--支付类型
        prm_aae013            IN  VARCHAR2,--备注
        prm_bke778            IN  NUMBER ,--支付标准
        prm_upper_limit       IN  NUMBER ,--支付金额上限
        prm_lower_limit       IN  NUMBER ,--支付金额下限
        prm_bke904            IN  VARCHAR2,--原项目支付类别
        prm_aaz735            IN  NUMBER,--权重及支付标准ID
        prm_appcode           OUT NUMBER,  --执行代码
        prm_errormsg          OUT VARCHAR2 --错误信息
      ) IS

       bke901_0 CONSTANT VARCHAR2(3) := '0';--支付类型 0 自费 1 基金按原项目支付 2 基金按DRG支付
       bke901_1 CONSTANT VARCHAR2(3) := '1';--支付类型 0 自费 1 基金按原项目支付 2 基金按DRG支付
       bke901_2 CONSTANT VARCHAR2(3) := '2';--支付类型 0 自费 1 基金按原项目支付 2 基金按DRG支付
       aae100_1 CONSTANT VARCHAR2(3) := '1';--有效标志 1 有效 0 无效
       bke898_0 CONSTANT VARCHAR2(3) := '0';--支付对账标志 0 待对账 1 已对账 9 已撤销
       bke899_1 CONSTANT VARCHAR2(3) := '1';--支付结算标志 0 待结算 1 已结算 9 已撤销
       n_p12    CONSTANT VARCHAR2(6) := 'P12';-- P12  异常病案DRG支付金额<=0
      BEGIN
        prm_appcode := pkg_comm.def_ok;
        IF(prm_baz506 IS NULL OR prm_aae013 IS NULL  OR prm_bke901 IS NULL) THEN
             prm_appcode := pkg_comm.def_err;
             prm_errormsg := '入参不能为空！';
             RETURN;
        END IF;

        IF prm_bke901 = bke901_0 OR prm_bke901 = bke901_1 THEN --自费支付或按项目支付
          INSERT INTO KEC7
          (
              aaz727  ,--drgs支付明细id
              baz506  ,--住院病案首页id
              ake554  ,--住院病案首页类型
              akc190  ,--就诊登记号
              akb020  ,--医疗服务机构编码
              akb021  ,--医疗服务机构名称
              bac002  ,--人群类别
              ake302  ,--病案号
              bac001  ,--个人编号
              aac003  ,--姓名
              aac004  ,--性别
              akc023  ,--年龄
              bkc009  ,--入院时间
              bkc010  ,--出院时间
              akc264  ,--住院费用(元)：总费用
              ake482  ,--自付金额
              bke716  ,--drg编码
              bke717  ,--drg名称
              bke778  ,--drg支付标准
              bke854  ,--drg支付金额
              ake039  ,--项目支付金额
              aae036  ,--经办时间
              aae100  ,--有效标志
              aaa027  ,--统筹区编码
              baa001  ,--分中心编码
              aae013  ,--备注
              aaz706  ,--分组器信息id
              ake100  ,--结算时间
              bke898  ,--drg支付对账标志
              bke901  ,--支付类别
              bke904  ,--原项目支付类别
              bke905  ,--权重及支付标准ID
              bke930   --结算期号
          )
          select
            SE_AAZ727.NEXTVAL AS aaz727,--drgs支付明细
            a.baz506,--住院病案首页
            a.ake554,--住院病案首页类型
            b.akc190,--就诊登记号
            a.akb020,--医疗服务机构编码
            c.akb021,--医疗服务机构名称
            b.bac002,--人群类别
            d.ake302,--病案号
            b.bac001,--医保人员编号
            d.aac003,--姓名
            d.aac004,--性别
            d.akc023,--年龄
            d.bkc009,--入院时间
            d.bkc010,--出院时间
            b.akc264,--住院费用元：总费用
            case
              when b.bac002 = '1' then (nvl(b.akc264,0)-nvl(b.ake039,0)-nvl(b.ake029,0)-nvl(b.bkc135,0))
              when b.bac002 = '2' then (nvl(b.akc264,0)-nvl(b.ake039,0)-nvl(b.bkc135,0)) else null end as ake482,--自付金额
            a.bke716,--drg编码
            a.bke717,--drg名称
            NULL as bke778,--自费、按项目病案drg支付标准为NULL
            NULL as bke854,--自费、按项目病案drgdrg支付金额为NULL
           case
              when b.bac002 = '1' then  nvl(b.ake039,0)+nvl(b.ake029,0)
              when b.bac002 = '2' then  b.ake039 else null end as ake039,--项目支付金额
            sysdate as  aae036,--经办时间
            aae100_1 as aae100,--有效标志
            c.aaa027,--统筹区编码
            c.baa001,--分中心编码
            prm_aae013 as aae013,--备注
            a.aaz706, -- 分组器信息
            b.aae036 as ake100, --结算时间
            bke898_0 as bke898,--drg支付对账标志
            prm_bke901 as bke901,  --支付类别
            prm_bke904 as bke904,  --原项目支付类别
            prm_aaz735 as bke905,   --权重及支付标准ID
            case when b.aae036 is not null then to_char(b.aae036,'yyyymm') else null end as bke930 --结算期号
            from kea4 a
               left  join KEA5 b on a.akc190 = b.akc190 and b.aaa131 = '0'
               inner join kb01 c on a.akb020 = c.akb020
               inner join kec3 d  on a.baz506 = d.baz506
               where a.aaz706 = '1'
                     and a.aaa131 = '0'
                     and c.aaa131 = '0'
                     and d.aaa131 = '0'
                     and a.baz506  = prm_baz506;

        ELSIF prm_bke901 = bke901_2 THEN  --基金按DRG支付

        INSERT INTO KEC7
          (
              aaz727  ,--drgs支付明细id
              baz506  ,--住院病案首页id
              ake554  ,--住院病案首页类型
              akc190  ,--就诊登记号
              akb020  ,--医疗服务机构编码
              akb021  ,--医疗服务机构名称
              bac002  ,--人群类别
              ake302  ,--病案号
              bac001  ,--个人编号
              aac003  ,--姓名
              aac004  ,--性别
              akc023  ,--年龄
              bkc009  ,--入院时间
              bkc010  ,--出院时间
              akc264  ,--住院费用(元)：总费用
              ake482  ,--自付金额
              bke716  ,--drg编码
              bke717  ,--drg名称
              bke778  ,--drg支付标准
              bke854  ,--drg支付金额
              ake039  ,--项目支付金额
              aae036  ,--经办时间
              aae100  ,--有效标志
              aaa027  ,--统筹区编码
              baa001  ,--分中心编码
              aae013  ,--备注
              aaz706  ,--分组器信息id
              ake100  ,--结算时间
              bke898  ,--drg支付对账标志
              bke901  ,--支付类别
              bke904  ,--原项目支付类别
              bke905  ,--权重及支付标准ID
              bke930   --结算期号
          )
          select
            SE_AAZ727.NEXTVAL AS aaz727,--drgs支付明细
            a.baz506,--住院病案首页
            a.ake554,--住院病案首页类型
            b.akc190,--就诊登记号
            a.akb020,--医疗服务机构编码
            c.akb021,--医疗服务机构名称
            b.bac002,--人群类别
            d.ake302,--病案号
            b.bac001,--医保人员编号
            d.aac003,--姓名
            d.aac004,--性别
            d.akc023,--年龄
            d.bkc009,--入院时间
            d.bkc010,--出院时间
            b.akc264,--住院费用元：总费用
             (nvl(b.akc264,0)-nvl(b.ake039,0)-nvl(b.ake029,0)-nvl(b.bkc135,0)) as ake482,--自付金额
            a.bke716,--drg编码
            a.bke717,--drg名称
            prm_bke778 as bke778,--drg支付标准为
            round(case
              when     prm_bke778>0 and b.akc264 >=prm_lower_limit
                       and b.akc264<=prm_upper_limit  and b.bac002 = '1' then
                       case when  (b.ake029+b.bkc033+b.ake039+b.bkc031) >0
                                  and  (prm_bke778-b.ake051 - b.akc228 - b.bkc029)*((b.ake029+b.ake039)/ (b.ake029+b.bkc033+b.ake039+b.bkc031))>0 then
                                       (prm_bke778-b.ake051 - b.akc228 - b.bkc029)*((b.ake029+b.ake039)/ (b.ake029+b.bkc033+b.ake039+b.bkc031))  else null end
              when     b.ake029 = 0 and prm_bke778>0 and b.akc264 >=prm_lower_limit
                       and b.akc264<=prm_upper_limit  and b.bac002 = '2' then
                       case when  (b.ake039+b.bkc031) >0
                                  and (prm_bke778-b.ake051 - b.akc228 - b.bkc029)*(b.ake039/(b.ake039+b.bkc031)) >0 then
                                      (prm_bke778-b.ake051 - b.akc228 - b.bkc029)*(b.ake039/(b.ake039+b.bkc031)) else null end
              else null end,2) as bke854,--drg支付金额
           case
              when b.bac002 = '1' then  nvl(b.ake039,0)+nvl(b.ake029,0)
              when b.bac002 = '2' then  b.ake039 else null end as ake039,--项目支付金额
            sysdate as  aae036,--经办时间
            aae100_1 as aae100,--有效标志
            c.aaa027,--统筹区编码
            c.baa001,--分中心编码
           ( case when   b.bac002 = '1' then  --城镇
                         case when (b.ake029+b.bkc033+b.ake039+b.bkc031) >0 and (prm_bke778-b.ake051 - b.akc228 - b.bkc029)*((b.ake029+b.ake039)/ (b.ake029+b.bkc033+b.ake039+b.bkc031))>0 then
                         prm_aae013
                         else '城镇异常病案DRG支付金额<=0，按原项目'end
                  when   b.bac002 = '2' then --城乡
                         case when (b.ake039+b.bkc031)>0 and (prm_bke778-b.ake051 - b.akc228 - b.bkc029)*(b.ake039/(b.ake039+b.bkc031)) >0 then
                         prm_aae013
                         else '城乡异常病案DRG支付金额<=0，按原项目'end
                   else prm_aae013 end) as aae013,--备注
            a.aaz706, -- 分组器信息
            b.aae036 as ake100, --结算时间
            bke898_0 as bke898,--drg支付对账标志
            ( case when   b.bac002 = '1' then  --城镇
                         case when (b.ake029+b.bkc033+b.ake039+b.bkc031) >0 and (prm_bke778-b.ake051 - b.akc228 - b.bkc029)*((b.ake029+b.ake039)/ (b.ake029+b.bkc033+b.ake039+b.bkc031))>0 then
                         prm_bke901
                         else bke901_1 end
                  when   b.bac002 = '2' then --城乡
                         case when (b.ake039+b.bkc031)>0 and (prm_bke778-b.ake051 - b.akc228 - b.bkc029)*(b.ake039/(b.ake039+b.bkc031)) >0 then
                         prm_bke901
                         else bke901_1 end
                   else prm_bke901 end) as bke901,  --支付类别
            ( case when   b.bac002 = '1' then  --城镇
                         case when (b.ake029+b.bkc033+b.ake039+b.bkc031) >0 and (prm_bke778-b.ake051 - b.akc228 - b.bkc029)*((b.ake029+b.ake039)/ (b.ake029+b.bkc033+b.ake039+b.bkc031))>0 then
                         prm_bke904
                         else n_p12 end
                  when   b.bac002 = '2' then --城乡
                         case when (b.ake039+b.bkc031)>0 and (prm_bke778-b.ake051 - b.akc228 - b.bkc029)*(b.ake039/(b.ake039+b.bkc031)) >0 then
                         prm_bke904
                         else n_p12 end
                   else prm_bke904 end)  as bke904,  --原项目支付类别
            prm_aaz735 as bke905,   --权重及支付标准ID
            case when b.aae036 is not null then to_char(b.aae036,'yyyymm') else null end as bke930 --结算期号
            from kea4 a
               left  join KEA5 b on a.akc190 = b.akc190 and b.aaa131 = '0'
               inner join kb01 c on a.akb020 = c.akb020
               inner join kec3 d  on a.baz506 = d.baz506
               where a.aaz706 = '1'
                     and a.aaa131 = '0'
                     and c.aaa131 = '0'
                     and d.aaa131 = '0'
                     and a.baz506  = prm_baz506;
        ELSE
           prm_appcode := pkg_comm.def_err;
           prm_errormsg := '支付类型有误！！';
           RETURN;
        END IF;
      --更新指定baz506的数据为已结算

      UPDATE KEC3 SET bke899 = bke899_1 where baz506 = prm_baz506;


      EXCEPTION
      WHEN OTHERS THEN
        prm_appcode := pkg_comm.def_err;
        prm_errormsg := '执行失败: '||SQLERRM;
        ROLLBACK;
      END PRC_INSERTKEC7AUTO;

 
  
  /******************************************************************************/
   /*  程序包名 ：DRGs_PKG                                                */
   /*  业务环节 ：DRGs数据分析                                            */
   /*  功能描述 ：为DRGs分析提供存储过程                                 */
   /*                                                                            */
   /*  作    者 ： hzq                作成日期 ：2018/8/27 15:10:24     版本编号 ：Ver 2.0.0  */
   /*----------------------------------------------------------------------------*/
   /*  修改记录 ：                                                               */
   /******************************************************************************/
   /*-------------------------------------------------------------------------*/
   /* 公用全局常量声明                                                        */
   /*-------------------------------------------------------------------------*/
   /*-------------------------------------------------------------------------*/
   /*
   //      数据抽取
   //      参数
   //      prm_bke139 IN VARCHAR(2)   批次号
   //      prm_appcode OUT VARCHAR(2) 调用存储过程 prm_appcode 成功状态
   //      prm_errormsg OUT VARCHAR(50) 错误日志
   //      ExtractNum OUT NUMBER(12) 抽数数据量
   */
   PROCEDURE PRC_KEK7( prm_bke139 IN VARCHAR2,
                              ExtractNum OUT NUMBER,
                              AppCode    OUT VARCHAR2,
                              ErrorMsg   OUT VARCHAR2

                             ) IS
      v_insert_num NUMBER;

   BEGIN  
    INSERT INTO KEK7
    SELECT
          a.baz506 AS baz506,   -- 住院病案首页ID -->
          a.ake554 AS ake554,   -- 住院病案首页类型 -->
          a.akc190 AS akc190,   -- 就诊登记号   -->
          a.akb020 AS akb020,   -- 医疗服务机构编号 -->
          g.aaa027 AS aaa027,   -- 统筹区编码   -->
          g.baa001 AS baa001,   -- 分中心编码   -->
          a.aae036 AS aae036,   -- 病案上传时间 -->
          a.ake100 AS ake100,   -- 结算时间     -->
          TO_CHAR(a.ake100,'yyyyMM') AS bke930,  -- 结算期号 -->
          g.akb021 AS akb021,   -- 医疗服务机构名称 -->
          g.aka101 as aka101,   -- 医疗机构等级 -->
          a.ake300 AS ake300,   -- 医疗付款方式 -->
          a.ake302 AS ake302,   -- 病案号       -->

          a.aac003 AS aac003,   -- 姓名         -->
          a.aac004 AS aac004,   -- 性别         -->
          a.aac006 AS aac006,   -- 出生日期     -->
          a.akc023 AS akc023,   -- 年龄         -->
          a.ake304 AS ake304,   -- (年龄不足1周岁的)年龄(月) -->
          a.ake305 AS ake305,   -- 新生儿出生体重(克) -->
          a.ake306 AS ake306,   -- 新生儿入院体重(克） -->
          a.aac005 AS aac005,   -- 民族         -->
          a.aac002 AS aac002,   -- 身份证号     -->
          a.aae006 AS aae006,   -- 现住址       -->

          a.ake317 AS ake317,   -- 入院途径     -->
          a.bkc009 AS bkc009,   -- 入院时间     -->
          a.akf001 AS akf001,   -- 入院科别     -->
          a.ake319 AS ake319,   -- 转科科别     -->
          a.bkc010 AS bkc010,   -- 出院时间     -->
          a.bkf002 AS bkf002,   -- 出院科别     -->
          e.bkf033 as bkf033,
          null     as bkf035,   -- 转出科别一级科别 -->
          null     as bkf036,   -- 转出科别一级科别名称 -->

          a.bkc041 AS bkc041,   -- 实际住院天数 -->
          a.ake471 AS ake471,   -- 离院方式     -->

          a.akc264 AS akc264,   -- 住院费用(元)：总费用 -->
          a.ake482 AS ake482,   -- 自付金额     -->



    

    --综合医疗服务费-->
          NVL(a.ake483,0)+  --综合医疗服务类：(1)一般医疗服务费
        --  NVL(a.ake538,0)+  --综合医疗服务类：(1)一般医疗服务费-中医辨证论治费
        --  NVL(a.ake539,0)+  --综合医疗服务类：(1)一般医疗服务费-中医辨证论治会诊费
          NVL(a.ake484,0)+  --综合医疗服务类：(2)一般治疗操作费
          NVL(a.alc113,0)+  --综合医疗服务类：(3)护理费
          NVL(a.ake485,0) as bke962,  --综合医疗服务类：(4)其他费用
     --西药费-->
          NVL(a.AKE047,0) as bke963 ,  --西药类：(15)西药费
    --康复费-->
          NVL(a.AKE494,0) as ake494 ,  --康复类：(11)康复费
    --诊断费-->
          NVL(a.AKE486,0)+  --诊断类：(5)病理诊断费
          NVL(a.AKE487,0)+  --诊断类：(6)实验室诊断费
          NVL(a.AKE488,0)+  --诊断类：(7)影像学诊断费
          NVL(a.AKE489,0)   --诊断类：(8)临床诊断项目费
          as bke964 ,  
    --治疗费-->
          NVL(a.ake490,0)+  --治疗类：(9)非手术治疗项目费-->
       --   NVL(a.ake491,0)+  --治疗类：(9)非手术治疗项目费-临床物理治疗费-->
          NVL(a.ake492,0)  --治疗类：(10)手术治疗费-->
          as bke965,
       --   NVL(a.ake493,0)+  --治疗类：(10)手术治疗费-麻醉费-->
       --   NVL(a.ake045,0)+  --治疗类：(10)手术治疗费-手术费-->
       --   NVL(a.ake541,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-->
       --   NVL(a.ake542,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-中医外治-->
       --   NVL(a.ake543,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-中医骨伤-->
       --   NVL(a.ake544,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-针刺与灸法-->
       --   NVL(a.ake545,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-中医推拿治疗-->
       --   NVL(a.ake546,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-中医肛肠治疗-->
       --   NVL(a.ake547,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-中医特殊治疗-->
       --   NVL(a.ake548,0)  --中医类(中医和名族医医疗服务)：(14)中医其他-->
       --   NVL(a.ake549,0)+  --中医类(中医和名族医医疗服务)：(14)中医其他-中医特殊调配加工-->
        --  NVL(a.ake550,0) --中医类(中医和名族医医疗服务)：(14)中医其他-辨证施膳-->
     --中药费-->
          NVL(a.AKE050,0)+  --中药类：(16)中成药费
          NVL(a.AKE049,0)  --中药类：(17)中草药费
           as bke966 ,  
    --血费-->
          NVL(a.ake046,0)+  --血液和血液制品类：(18)血费
          NVL(a.ake497,0)+  --血液和血液制品类：(19)白蛋白类制品费
          NVL(a.ake498,0)+  --血液和血液制品类：(20)球蛋白类制品费-->
          NVL(a.ake499,0)+  --血液和血液制品类：(21)凝血因子类制品费-->
          NVL(a.ake500,0) as bke967 ,  --血液和血液制品类：(22)细胞因子类制品费-->
    --耗材费-->
          NVL(a.ake501,0)+  --耗材类：(23)检查用一次性医用材料费-->
          NVL(a.ake502,0)+  --耗材类：(24)治疗用一次性医用材料费-->
          NVL(a.ake503,0) as bke968 ,  --耗材类：(25)手术用一次性医用材料费-->
    --其他费-->
          a.ake044 as ake044,  --其他类：(26)其他费-->


          c.bke720 as bke720,   -- ADRG      -->
          c.bke721 as bke721,   -- ADRG名称      -->
          c.bke716 as bke716,   -- DRG编码      -->
          c.bke717 as bke717,   -- DRG名称      -->
          c.bke718 as bke718,   -- MDC编码      -->
          c.bke719 as bke719,   -- MDC名称      -->



          d.aae001 as aae001,   -- 年度         -->

          d.bke724 as bke724,   -- DRG权重      -->
          d.bke723 as bke723,   -- 标杆平均住院日 -->
          d.bke722 as bke722,   -- 标杆例均费用 -->
          d.bke729 as bke729,   -- 平均年龄     -->
          d.bke725 as bke725,   -- 风险级别     -->

          d.bke888 as bke888,   -- MDC标杆平均住院日 -->
          d.bke887 as bke887,   -- MDC标杆例均费用 -->

          d.bke811 as bke811,   -- 例均药品费用 -->
          d.bke813 as bke813,   -- 例均耗材费用 -->
          d.bke815 as bke815,   -- 例均抗生素费用 -->
          d.bke889 as bke889,   -- 检验费标杆值 -->

          b.ake325 AS ake325, --主要诊断疾病编码-->
          b.ake394 AS ake394, --手术及操作编码1-->
          b.ake396 AS ake396, --手术级别1-->
          b.ake405 AS ake405, --手术及操作编码2-->
          b.ake407 AS ake407, --手术级别2-->
          b.ake416 AS ake416, --手术及操作编码3-->
          b.ake418 AS ake418, --手术级别3-->
          b.ake427 AS ake427, --手术及操作编码4-->
          b.ake429 AS ake429, --手术级别4-->
          b.ake438 AS ake438, --手术及操作编码5-->
          b.ake440 AS ake440, --手术级别5-->
          b.ake449 AS ake449, --手术及操作编码6-->
          b.ake451 AS ake451, --手术级别6-->
          b.ake460 AS ake460, --手术及操作编码7-->
          b.ake462 AS ake462, --手术级别7-->
          b.ake382 AS ake382, --科主任-->
          b.ake383 AS ake383, --主任（副主任）医师-->
          b.ake384 AS ake384, --主治医师-->
          b.ake385 AS ake385, --住院医师-->
          b.ake386 AS ake386, --责任护士-->
          b.ake387 AS ake387, --进修医师-->
          b.ake388 AS ake388, --实习医师-->
          b.ake389 AS ake389, --编码员-->
          b.ake391 AS ake391, --质控医师-->
          b.ake392 AS ake392, --质控护士-->
          b.ake393 AS ake393, --质控日期-->
          b.ake020 AS ake020, --入院病房-->
          b.ake321 AS ake321, --出院病房-->
          f.bke782 AS bke782,  --病案总分-->
          c.bke742 as bke742,    --分组状态
          a.bac002 AS bac002,    -- 人群类别     -->
          a.ake496 as bke972,   --抗生素
          c.bke715 as bke715,   -- 分组器类型   -->
          d.bke970 as bke970,   -- adrg标杆住院天数 -->
          d.bke971 as bke971,   -- adrg标杆例均费用
          a.bke139 as bke139,   --批次号
          b.ake397 as ake397,   --手术名称
          b.ake324 as ake324,   --主要诊断名称
          c.bke709 as bke709,    --校验标志
          a.ake487 AS ake487,     --实验室诊断费（检验费）
          a.ake488 AS ake488,     --影像学诊断费（检查费）
          a.bkec25 AS bkec25,    --入院科别(院内)
          a.bkec26 AS bkec26,   --转院科别(院内)
          a.bkec27 AS bkec27,    --出院科别(院内)   
          NVL(a.ake540,0) AS bkec67,       --中医费
          null as bkee31,    	--诊疗组编号
          null as bkec69      --医保类型 
    FROM kec3 a   
    INNER JOIN kec4 b ON  b.aaa131 = '0' AND a.baz506 = b.baz506
    INNER JOIN kea4 c ON  c.aaa131= '0' AND a.baz506 = c.baz506
    LEFT JOIN kaa8 d ON c.bke716 = d.bke716 AND TO_CHAR(a.ake100,'yyyy')= d.aae001 AND aae100 = '1'
    LEFT JOIN (
    SELECT t.akf001 as bkf014,
           t.bkf033 as bkf033
      FROM kaa3 t
      where  t.bkf014 = 1
    ) e ON a.bkf002 = e.bkf014
    INNER JOIN keb8 f ON a.baz506 = f.baz506
    INNER JOIN kb01 g ON a.akb020 = g.akb020

    where  a.bke139 = prm_bke139;
    commit;
     EXCEPTION
         WHEN OTHERS THEN
            AppCode     := pkg_comm.def_err;
            ErrorMsg    := '医院端中间表抽取有误：' || SQLERRM;
      rollback;
   end PRC_KEK7;
   
    /******************************************************************************/
  /*  程序包名 ：DRGs_PKG                                                */
  /*  业务环节 ：DRGs数据分析  根据ISSUE进行抽取                                       */
  /*  功能描述 ：为DRGs分析提供存储过程                                 */
  /*                                                                            */
  /*  作    者 ： all                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：                                                               */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  //      数据抽取（中西医同时）
  //      参数
  //      PRM_BKE800 IN VARCHAR2(6) 抽取期号
  //      ExtractNum OUT NUMBER 错误类型（0 成功）
  //      ERROR_MESSAGE OUT VARCHAR(50) 错误日志
  //      EXTRACTION_NUM OUT NUMBER(12) 抽数数据量
  */
       PROCEDURE PRC_KEK7_ISSUE(
                              prm_bke800  IN VARCHAR2, --开始期号
                              prm_aae030  IN VARCHAR2, --开始日期
                              prm_aae031  IN VARCHAR2, --终止日期
                              prm_appcode           OUT NUMBER,  --执行代码
                              prm_errormsg          OUT VARCHAR2 --错误信息
                              ) IS
      v_insert_num      NUMBER;
  BEGIN
    INSERT INTO KEK7
    SELECT
          a.baz506 AS baz506,   -- 住院病案首页ID -->
          a.ake554 AS ake554,   -- 住院病案首页类型 -->
          a.akc190 AS akc190,   -- 就诊登记号   -->
          a.akb020 AS akb020,   -- 医疗服务机构编号 -->
          g.aaa027 AS aaa027,   -- 统筹区编码   -->
          g.baa001 AS baa001,   -- 分中心编码   -->
          a.aae036 AS aae036,   -- 病案上传时间 -->
          a.ake100 AS ake100,   -- 结算时间     -->
          TO_CHAR(a.ake100,'yyyyMM') AS bke930,  -- 结算期号 -->
          g.akb021 AS akb021,   -- 医疗服务机构名称 -->
          g.aka101 as aka101,   -- 医疗机构等级 -->
          a.ake300 AS ake300,   -- 医疗付款方式 -->
          a.ake302 AS ake302,   -- 病案号       -->

          a.aac003 AS aac003,   -- 姓名         -->
          a.aac004 AS aac004,   -- 性别         -->
          a.aac006 AS aac006,   -- 出生日期     -->
          a.akc023 AS akc023,   -- 年龄         -->
          a.ake304 AS ake304,   -- (年龄不足1周岁的)年龄(月) -->
          a.ake305 AS ake305,   -- 新生儿出生体重(克) -->
          a.ake306 AS ake306,   -- 新生儿入院体重(克） -->
          a.aac005 AS aac005,   -- 民族         -->
          a.aac002 AS aac002,   -- 身份证号     -->
          a.aae006 AS aae006,   -- 现住址       -->

          a.ake317 AS ake317,   -- 入院途径     -->
          a.bkc009 AS bkc009,   -- 入院时间     -->
          a.akf001 AS akf001,   -- 入院科别     -->
          a.ake319 AS ake319,   -- 转科科别     -->
          a.bkc010 AS bkc010,   -- 出院时间     -->
          a.bkf002 AS bkf002,   -- 出院科别     -->
          e.bkf033 as bkf033,
          null     as bkf035,   -- 转出科别一级科别 -->
          null     as bkf036,   -- 转出科别一级科别名称 -->

          a.bkc041 AS bkc041,   -- 实际住院天数 -->
          a.ake471 AS ake471,   -- 离院方式     -->

          a.akc264 AS akc264,   -- 住院费用(元)：总费用 -->
          a.ake482 AS ake482,   -- 自付金额     -->



    

    --综合医疗服务费-->
          NVL(a.ake483,0)+  --综合医疗服务类：(1)一般医疗服务费
        --  NVL(a.ake538,0)+  --综合医疗服务类：(1)一般医疗服务费-中医辨证论治费
        --  NVL(a.ake539,0)+  --综合医疗服务类：(1)一般医疗服务费-中医辨证论治会诊费
          NVL(a.ake484,0)+  --综合医疗服务类：(2)一般治疗操作费
          NVL(a.alc113,0)+  --综合医疗服务类：(3)护理费
          NVL(a.ake485,0) as bke962,  --综合医疗服务类：(4)其他费用
     --西药费-->
          NVL(a.AKE047,0) as bke963 ,  --西药类：(15)西药费
    --康复费-->
          NVL(a.AKE494,0) as ake494 ,  --康复类：(11)康复费
    --诊断费-->
          NVL(a.AKE486,0)+  --诊断类：(5)病理诊断费
          NVL(a.AKE487,0)+  --诊断类：(6)实验室诊断费
          NVL(a.AKE488,0)+  --诊断类：(7)影像学诊断费
          NVL(a.AKE489,0)   --诊断类：(8)临床诊断项目费
          as bke964 ,  
    --治疗费-->
          NVL(a.ake490,0)+  --治疗类：(9)非手术治疗项目费-->
       --   NVL(a.ake491,0)+  --治疗类：(9)非手术治疗项目费-临床物理治疗费-->
          NVL(a.ake492,0)  --治疗类：(10)手术治疗费-->
          as bke965,
       --   NVL(a.ake493,0)+  --治疗类：(10)手术治疗费-麻醉费-->
       --   NVL(a.ake045,0)+  --治疗类：(10)手术治疗费-手术费-->
       --   NVL(a.ake541,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-->
       --   NVL(a.ake542,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-中医外治-->
       --   NVL(a.ake543,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-中医骨伤-->
       --   NVL(a.ake544,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-针刺与灸法-->
       --   NVL(a.ake545,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-中医推拿治疗-->
       --   NVL(a.ake546,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-中医肛肠治疗-->
       --   NVL(a.ake547,0)+  --中医类(中医和名族医医疗服务)：(13)中医治疗-中医特殊治疗-->
       --   NVL(a.ake548,0)  --中医类(中医和名族医医疗服务)：(14)中医其他-->
       --   NVL(a.ake549,0)+  --中医类(中医和名族医医疗服务)：(14)中医其他-中医特殊调配加工-->
        --  NVL(a.ake550,0) --中医类(中医和名族医医疗服务)：(14)中医其他-辨证施膳-->
     --中药费-->
          NVL(a.AKE050,0)+  --中药类：(16)中成药费
          NVL(a.AKE049,0)  --中药类：(17)中草药费
           as bke966 ,  
    --血费-->
          NVL(a.ake046,0)+  --血液和血液制品类：(18)血费
          NVL(a.ake497,0)+  --血液和血液制品类：(19)白蛋白类制品费
          NVL(a.ake498,0)+  --血液和血液制品类：(20)球蛋白类制品费-->
          NVL(a.ake499,0)+  --血液和血液制品类：(21)凝血因子类制品费-->
          NVL(a.ake500,0) as bke967 ,  --血液和血液制品类：(22)细胞因子类制品费-->
    --耗材费-->
          NVL(a.ake501,0)+  --耗材类：(23)检查用一次性医用材料费-->
          NVL(a.ake502,0)+  --耗材类：(24)治疗用一次性医用材料费-->
          NVL(a.ake503,0) as bke968 ,  --耗材类：(25)手术用一次性医用材料费-->
    --其他费-->
          a.ake044 as ake044,  --其他类：(26)其他费-->


          c.bke720 as bke720,   -- ADRG      -->
          c.bke721 as bke721,   -- ADRG名称      -->
          c.bke716 as bke716,   -- DRG编码      -->
          c.bke717 as bke717,   -- DRG名称      -->
          c.bke718 as bke718,   -- MDC编码      -->
          c.bke719 as bke719,   -- MDC名称      -->



          d.aae001 as aae001,   -- 年度         -->

          d.bke724 as bke724,   -- DRG权重      -->
          d.bke723 as bke723,   -- 标杆平均住院日 -->
          d.bke722 as bke722,   -- 标杆例均费用 -->
          d.bke729 as bke729,   -- 平均年龄     -->
          d.bke725 as bke725,   -- 风险级别     -->

          d.bke888 as bke888,   -- MDC标杆平均住院日 -->
          d.bke887 as bke887,   -- MDC标杆例均费用 -->

          d.bke811 as bke811,   -- 例均药品费用 -->
          d.bke813 as bke813,   -- 例均耗材费用 -->
          d.bke815 as bke815,   -- 例均抗生素费用 -->
          d.bke889 as bke889,   -- 检验费标杆值 -->

          b.ake325 AS ake325, --主要诊断疾病编码-->
          b.ake394 AS ake394, --手术及操作编码1-->
          b.ake396 AS ake396, --手术级别1-->
          b.ake405 AS ake405, --手术及操作编码2-->
          b.ake407 AS ake407, --手术级别2-->
          b.ake416 AS ake416, --手术及操作编码3-->
          b.ake418 AS ake418, --手术级别3-->
          b.ake427 AS ake427, --手术及操作编码4-->
          b.ake429 AS ake429, --手术级别4-->
          b.ake438 AS ake438, --手术及操作编码5-->
          b.ake440 AS ake440, --手术级别5-->
          b.ake449 AS ake449, --手术及操作编码6-->
          b.ake451 AS ake451, --手术级别6-->
          b.ake460 AS ake460, --手术及操作编码7-->
          b.ake462 AS ake462, --手术级别7-->
          b.ake382 AS ake382, --科主任-->
          b.ake383 AS ake383, --主任（副主任）医师-->
          b.ake384 AS ake384, --主治医师-->
          b.ake385 AS ake385, --住院医师-->
          b.ake386 AS ake386, --责任护士-->
          b.ake387 AS ake387, --进修医师-->
          b.ake388 AS ake388, --实习医师-->
          b.ake389 AS ake389, --编码员-->
          b.ake391 AS ake391, --质控医师-->
          b.ake392 AS ake392, --质控护士-->
          b.ake393 AS ake393, --质控日期-->
          b.ake020 AS ake020, --入院病房-->
          b.ake321 AS ake321, --出院病房-->
          f.bke782 AS bke782,  --病案总分-->
          c.bke742 as bke742,    --分组状态
          a.bac002 AS bac002,    -- 人群类别     -->
          a.ake496 as bke972,   --抗生素
          c.bke715 as bke715,   -- 分组器类型   -->
          d.bke970 as bke970,   -- adrg标杆住院天数 -->
          d.bke971 as bke971,   -- adrg标杆例均费用
          a.bke139 as bke139,   --批次号
          b.ake397 as ake397,   --手术名称
          b.ake324 as ake324,   --主要诊断名称
          c.bke709 as bke709,    --校验标志
          a.ake487 AS ake487,     --实验室诊断费（检验费）
          a.ake488 AS ake488,     --影像学诊断费（检查费）
          a.bkec25 AS bkec25,    --入院科别(院内)
          a.bkec26 AS bkec26,   --转院科别(院内)
          a.bkec27 AS bkec27,    --出院科别(院内)  
          NVL(a.ake540,0) AS bkec67,       --中医费
          null as bkee31,    	--诊疗组编号
          null as bkec69      --医保类型 
    FROM kec3 a 
    INNER JOIN kec4 b ON  b.aaa131 = '0' AND a.baz506 = b.baz506
    INNER JOIN kea4 c ON  c.aaa131= '0' AND a.baz506 = c.baz506
    LEFT JOIN kaa8 d ON c.bke716 = d.bke716 AND TO_CHAR(a.ake100,'yyyy')= d.aae001 AND aae100 = '1'
    LEFT JOIN (
    SELECT t.akf001 as bkf014,
           t.bkf033 as bkf033
      FROM kaa3 t
      where  t.bkf014 = 1
    ) e ON a.bkf002 = e.bkf014
    INNER JOIN keb8 f ON a.baz506 = f.baz506
    INNER JOIN kb01 g ON a.akb020 = g.akb020

    where    a.ake100 >= to_date(prm_aae030 || ' 00:00:00', 'yyyymmdd hh24:mi:ss') --结算开始时间
             AND a.ake100 <= to_date(prm_aae031 || ' 23:59:59', 'yyyymmdd hh24:mi:ss'); --结算终止时间 
    commit;
     EXCEPTION
         WHEN OTHERS THEN
            prm_appcode     := pkg_comm.def_err;
            prm_errormsg    := '医院端中间表抽取有误：' || SQLERRM;
      rollback;
  end PRC_KEK7_ISSUE;
  /******************************************************************************/
  /*  程序包名 ：DRGs_PKG                                                */
  /*  业务环节 ：DRGs数据关键字段抽取                                            */
  /*  功能描述 ：1、定时任务抽取KEC3和KEC4的关键字段                         */
  /*             2、定时执行月度结算数据                                                                                                      */
  /*                                                                            */
  /*  作    者 ： all                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：
      开始期号必传                                                     */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  */
       PROCEDURE PRC_EXCUTE_TASK(
                           prm_bke800   IN VARCHAR2, --执行期号
                           prm_appcode  OUT NUMBER, --执行代码
                           prm_errormsg OUT VARCHAR2--错误信息
                         )
         IS

         v_bke800    VARCHAR2(6); --执行期号
         v_aae030    VARCHAR2(8); --开始日期
         v_aae031    VARCHAR2(8); --终止日期
         d_sysdate CONSTANT DATE := SYSDATE; --当前系统时间

         BEGIN
         v_bke800 :=prm_bke800;

          -- 1、判断入参是否满足要求，如果没有入参则默认取上一个月的数据
         IF prm_bke800 IS NULL THEN
             v_bke800 := TO_CHAR(add_months(d_sysdate, -1), 'yyyymm');
         END IF;


          --2、获取当前报表类型的数据开始时间和结束时间
          pkg_comm.prc_getDate(pkg_comm.bke803_month, --报表类型
                           v_bke800, --统计期号
                           v_aae030, --开始日期
                           v_aae031); --终止日期
         --3、执行抽取KEC3和KEC4
          DRGS_PKG.PRC_KEC3ANDKEC4_ISSUE(v_bke800,v_aae030,v_aae031,prm_appcode,prm_errormsg);
          IF prm_appcode = pkg_comm.def_ok THEN
            --4、执行抽取KEB7和KEB8
             DRGS_PKG.PRC_KEB7ANDKEB8_ISSUE(v_bke800,v_aae030,v_aae031,prm_appcode,prm_errormsg);
             IF prm_appcode = pkg_comm.def_ok THEN
               --5、执行抽取KEC7
                DRGS_PKG.PRC_DRGPAYMENTAUTO_ISSUE(v_bke800,v_aae030,v_aae031,prm_appcode,prm_errormsg);
                IF prm_appcode = pkg_comm.def_ok THEN
                   prm_errormsg := '定时任务执行完成';
                   COMMIT;
                ELSE
                   ROLLBACK;
                   RETURN;
                END IF;
             ELSE
                ROLLBACK;
                RETURN;
             END IF;
          ELSE
                ROLLBACK;
                RETURN;
          END IF;

          END PRC_EXCUTE_TASK;

    /*--------------------------------------------------------------------------
   || 业务环节 : 统计日志信息表
   || 函数名称 : prc_timedtaskexelog
   || 功能描述 :定时任务抽取数据日志信息表
   || 使用场合 :
   || 参数描述 : 标识                  名称             输入输出   数据类型
   ||            ---------------------------------------------------------------
   ||           prm_bke800            统计期号               IN     VARCHAR2
   ||           prm_aae001            年度                   IN     VARCHAR2
   ||           prm_aae030            开始日期               IN     VARCHAR2
   ||           prm_aae031            终止日期               IN     VARCHAR2
   ||           prm_appcode           执行代码               OUT     NUMBER
   ||           prm_errormsg           错误信息              OUT     VARCHAR2
   ||            ---------------------------------------------------------------
   ||
   || 其它说明 :暂不考虑自治事务
   || 作    者 :
   || 完成日期 :
   ||---------------------------------------------------------------------------
   ||                                 修改记录
   ||---------------------------------------------------------------------------
   || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
   || 修改描述 :
   ||-------------------------------------------------------------------------*/
   PROCEDURE PRC_TIMEDTASKEXELOG(
                                prm_bke800   IN VARCHAR2, --统计期号
                                prm_aae001   IN VARCHAR2, --年度
                                prm_bke805   IN VARCHAR2, --数据表名
                                prm_aae030   IN VARCHAR2, --数据开始日期
                                prm_aae031   IN VARCHAR2, --数据终止日期
                                prm_appcode  OUT NUMBER, --执行代码
                                prm_errormsg OUT VARCHAR2) --错误信息
        IS
        BEGIN
           /* 变量初始化 */
      prm_appcode  := pkg_comm.def_ok;
      prm_errormsg := NULL;
      INSERT INTO KEM5
         (AAE001, --年度
          BKE800, --统计期号
          AAE030, --开始日期
          AAE031, --终止日期
          BKE805, --数据表名
          BKE807, --制表标志
          BAE108, --执行开始时间
          BAE109, --执行结束时间
          BAE191, --错误代码
          BAE188, --错误信息
          AAE013  --备注
          )
      VALUES
         (
          prm_aae001, --年度
          prm_bke800, --统计期号
          prm_aae030, --开始日期
          prm_aae031, --终止日期
          prm_bke805, --数据表名
          NULL, --制表标志
          to_char(SYSDATE,pkg_comm.datetime_format), --执行开始时间
          NULL, --执行结束时间
          '0',  --错误代码
          NULL, --错误信息
          NULL  --备注
          );
   EXCEPTION
      WHEN OTHERS THEN
         prm_appcode  := pkg_comm.def_err;
         prm_errormsg := '统计日志信息【KEM5】生成出错：' || SQLERRM;
        RETURN;
   END PRC_TIMEDTASKEXELOG;

   /******************************************************************************/
  /*  程序包名 ：DRGs_PKG                                                */
  /*  业务环节 ：DRGs数据分析抽取数据                                            */
  /*  功能描述 ：循环调用数据分析存储过程的历史分析数据                                 */
  /*                                                                            */
  /*  作    者 ： all                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：                                                               */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  */
    PROCEDURE PRC_CALL_STATISTICS_HISTORY(
                         prm_bke800   IN VARCHAR2, --执行期号
                         prm_bke801   IN VARCHAR2, --执行结束期号
                         prm_appcode  OUT NUMBER, --执行代码
                         prm_errormsg OUT VARCHAR2 --错误信息
                         )
      IS
      d_start_bke800 DATE;--开始执行期号
      d_end_bke800 DATE; --结束执行期号
      d_curr_bke800 DATE;--当前执行期号
      d_sysdate DATE;--抽取时间

   BEGIN
     d_sysdate := sysdate;
     prm_appcode  := pkg_comm.def_ok;
     prm_errormsg := '统计成功';

    if prm_bke800 is null then
      prm_appcode := pkg_comm.def_err;
      prm_errormsg := 'prm_bke800执行开始期号不能为空！';
      return ;
    end if;

    if prm_bke801 is null then
         d_end_bke800 := to_date(prm_bke800,pkg_comm.issue_format);
         else
         d_end_bke800 := to_date(prm_bke801,pkg_comm.issue_format);
    end if;

     d_start_bke800 := to_date(prm_bke800,pkg_comm.issue_format);
     d_curr_bke800 := d_start_bke800;

     while d_curr_bke800 <= d_end_bke800 loop

      pkg_a_statistics.prc_execute(to_char(d_curr_bke800,pkg_comm.issue_format),prm_appcode,prm_errormsg);

      dbms_output.put_line(to_char(d_curr_bke800,pkg_comm.issue_format));

      d_curr_bke800:=add_months(d_curr_bke800, 1);

      end loop;
      prm_appcode  := pkg_comm.def_ok;
      prm_errormsg := '统计成功';
      EXCEPTION
      WHEN OTHERS THEN
         prm_appcode  := pkg_comm.def_err;
         prm_errormsg := '【PKG_COMM.PRC_CALL_STATISTICS_HISTORY】执行出错：' || SQLERRM;

      END PRC_CALL_STATISTICS_HISTORY;
      
 

  /******************************************************************************/
  /*  程序包名 ：DRGs_PKG                                                */
  /*  业务环节 ：DRGs数据分析清理                                            */
  /*  功能描述 ：根据开始期号结束期号进行DRGs数据清理                                 */
  /*                                                                            */
  /*  作    者 ： all                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：                                                               */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  */
     PROCEDURE PRC_CLEANDATA_BY_ISSUE(
        prm_bke800   IN VARCHAR2, --执行期号
        prm_bke801   IN VARCHAR2, --结束期号
        prm_appcode  OUT NUMBER,  --执行代码
        prm_errormsg OUT VARCHAR2 --错误信息
      ) IS

      d_start_bke800 DATE;--开始执行期号
      d_end_bke800 DATE; --结束执行期号
      d_curr_bke800 DATE;--当前执行期号
      v_curr_bke800 VARCHAR2(6);--当前期号
    begin
      if prm_bke800 is null then
        prm_appcode := pkg_comm.def_err;
        prm_errormsg := 'prm_bke800执行开始期号不能为空！';
        return ;
      end if;

      if prm_bke801 is null then
         d_end_bke800 := to_date(prm_bke800,pkg_comm.issue_format);
         else
         d_end_bke800 := to_date(prm_bke801,pkg_comm.issue_format);
      end if;

      d_start_bke800 := to_date(prm_bke800,pkg_comm.issue_format);
      d_curr_bke800  := d_start_bke800;

      while d_curr_bke800 <= d_end_bke800 loop
          v_curr_bke800 :=to_char(d_curr_bke800,pkg_comm.issue_format);
          delete from  kem1 where BKE800=v_curr_bke800 ;
          delete from  kem2_his where BKE800=v_curr_bke800 ;
          delete from  kej1 where BKE800=v_curr_bke800 ;
          delete from  kej3 where BKE800=v_curr_bke800 ;
          delete from  kej4 where BKE800=v_curr_bke800 ;
          delete from  kej5 where BKE800=v_curr_bke800 ;
          delete from  kej7 where BKE800=v_curr_bke800 ;
          delete from  kej8 where BKE800=v_curr_bke800 ;
          delete from  kej9 where BKE800=v_curr_bke800 ;
          delete from  kek1 where BKE800=v_curr_bke800 ;
          delete from  kek2 where BKE800=v_curr_bke800 ;
          delete from  kek3 where BKE800=v_curr_bke800 ;
          delete from  kek4 where BKE800=v_curr_bke800 ;
          delete from  kek6 where BKE800=v_curr_bke800 ;
          delete from  kek8 where BKE800=v_curr_bke800 ;
          delete from  kek9 where BKE800=v_curr_bke800 ;
          commit;
          d_curr_bke800 :=add_months(d_curr_bke800,1);
      end loop;
       prm_appcode := pkg_comm.def_ok;
       return;
  exception
      when others then
        prm_appcode := pkg_comm.def_err;
        prm_errormsg := '执行失败: '||SQLERRM;
      return;
    END PRC_CLEANDATA_BY_ISSUE;

      /******************************************************************************/
  /*  程序包名 ：DRGs_PKG                                                */
  /*  业务环节 ：DRGs数据抽取                                            */
  /*  功能描述 ：根据开始期号结束期号进行DRGs数据清理                                 */
  /*                                                                            */
  /*  作    者 ： all                作成日期 ：2014/4/22 15:10:24     版本编号 ：Ver 2.0.0  */
  /*----------------------------------------------------------------------------*/
  /*  修改记录 ：                                                               */
  /******************************************************************************/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /*
  */
       PROCEDURE PRC_CALL_DATA(
          prm_appcode  OUT NUMBER,  --执行代码
          prm_errormsg OUT VARCHAR2 --错误信息
        ) IS

         v_bke139 VARCHAR2(20);--基础bke139
         n_count NUMBER(8);--累计数据
         --游标定义
         CURSOR CUR_BKE139 IS
           -- SELECT BKE139 FROM KEC3 GROUP BY BKE139;
           SELECT BKE139 FROM KEC2 GROUP BY BKE139
           union all
           SELECT BKE139 FROM KEC1 GROUP BY BKE139;
         BEGIN

              FOR CUR_KAC2_BKE139 IN CUR_BKE139 LOOP
                v_bke139 :=CUR_KAC2_BKE139.BKE139;
                --抽取kec3和kec4
                DRGS_PKG.PRC_KEC3ANDKEC4(v_bke139,n_count,prm_appcode,prm_errormsg);
                --抽取keb7和keb8
                --DRGS_PKG.PRC_KEB7ANDKEB8(v_bke139,prm_appcode,prm_errormsg);
                --抽取kec7数据
                --DRGS_PKG.PRC_DRGPAYMENTAUTO(v_bke139,n_count,prm_appcode,prm_errormsg);
              END LOOP;
          EXCEPTION
          WHEN OTHERS THEN
            prm_appcode := pkg_comm.def_err;
            prm_errormsg := '执行失败: '||SQLERRM;
          RETURN;
        END PRC_CALL_DATA;

END DRGs_PKG;
/

