create procedure delemp as
       TYPE t_kha0 IS TABLE OF kha0%ROWTYPE INDEX BY BINARY_INTEGER;
       l_kha0 t_kha0;-- 声明 bainfo 表结构一致变量

begin

  SELECT akb020 BULK COLLECT INTO l_kha0 FROM kh43 where bkf217 = '3' group by akb020;
  FOR i IN 1 .. l_kha0.COUNT LOOP
        --select 1 from dual;
        delete from kh43 where bkf217 = '3' and akb020 = l_kha0(i).akb020;
  end loop;


end;


/

