create procedure PRC_EXTRACT_KHA5(prm_bke930 IN VARCHAR2,
                                             ExtractNum OUT NUMBER,
                                             AppCode    OUT VARCHAR2,
                                             ErrorMsg   OUT VARCHAR2) is
  v_insert_num NUMBER;

BEGIN
  INSERT INTO KBA6
    (akb020, --医疗机构编号
     akc190, --住院流水号(门诊流水号)
     aac001, --个人编号
     aae040, --结算时间
     akc221, --处方日期
     akc222, --医保中心对应收费项目编码
     akc223, --医保中心对应收费项目名称
     aka063, --收费类别
     aka065, --项目等级
     akc224, --收费项目种类（药品、诊疗、服务设施）
     akc225, --单价
     akc226, --数量
     akc227 --金额
     )
    SELECT FIXMEDINS_CODE,
           MDTRT_ID,
           SUBSTR(PSN_NO, -10),
           OPT_TIME,
           FEE_OCUR_TIME,
           HILIST_CODE,
           HILIST_NAME,
           MED_CHRGITM_TYPE,
           CHRGITM_LV,
           substr(LIST_TYPE, 0, 1),
           PRIC,
           CNT,
           DET_ITEM_FEE_SUMAMT
      FROM data_sync.fee_list_d_hosp 
     WHERE to_char(OPT_TIME, 'yyyymm') = prm_bke930
       AND substr(LIST_TYPE, 0, 1) = 2
       AND (HILIST_CODE LIKE '003402%' OR HILIST_CODE LIKE '323402%');
  COMMIT;
  INSERT INTO kha5
    SELECT se_AAZ925.nextval, a.*
      FROM (select akc190,
                   akb020,
                   aae040,
                   NULL AS bkeh81,
                   count(1) as bkek46
              from (select akb020, akc190, akc221, aae040
                      from (select b.akb020,
                                   a.akc190,
                                   a.aae040,
                                   to_char(a.akc221, 'yyyy-MM-dd') as akc221
                              from kba6 a inner join kb01 b on a.akb020=b.bkf498
                             where to_char(a.AAE040, 'yyyymm') = prm_bke930)
                     group by akb020, akc190, akc221, aae040)
             group by akb020, akc190,aae040
            having count(1) >= 15) a;
  v_insert_num := SQL%ROWCOUNT;
  ExtractNum   := v_insert_num;
  AppCode    := '1';

EXCEPTION
  WHEN OTHERS THEN
    AppCode  := pkg_comm.def_err;
    ErrorMsg := '抽取表KHA5有误：' || SQLERRM;
    commit;
end PRC_EXTRACT_KHA5;
/

