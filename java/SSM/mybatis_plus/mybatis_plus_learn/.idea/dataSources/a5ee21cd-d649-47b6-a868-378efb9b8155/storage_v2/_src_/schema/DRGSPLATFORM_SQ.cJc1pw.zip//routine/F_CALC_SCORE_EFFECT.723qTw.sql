create FUNCTION                 f_calc_score_effect(prm_time IN NUMBER,
                                               prm_fee IN NUMBER,
                                               ld_score OUT NUMBER
                                               ) RETURN NUMBER AS
BEGIN
  --效率得分  =（（1/时间消耗指数） *(1/费用消耗指数)）开方
  -- 输入值校验
  if prm_time ='' or prm_time=0 or prm_time is null then    -- 时间消耗指数
   return 0;
  end if;
  IF prm_fee ='' OR prm_fee=0 OR prm_fee IS NULL THEN       -- 费用消耗指数
   RETURN 0;
  END IF;
   ld_score := round(sqrt((1/prm_time)*(1/prm_fee)),4); -- 得分
   return ld_score;
END;


/

