create PACKAGE BODY pkg_a_statistics_dip
/******************************************************************************/
/*  程序包名 : pkg_a_statistics_dip                                              */
/*  业务环节 : dip统计分析报表                                                 */
/*  对象列表 : 私有过程函数                                                   */
/*             ---------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*             公用过程函数                                                   */
/*             ---------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/******************************************************************************/
/*  其它说明 :                                                                */
/*  完成日期 :                                                                */
/*  版本编号 : Ver 1.0                                                        */
/*  审 查 人 : ×××                      审查日期 : YYYY-MM-DD                 */
/******************************************************************************/
 IS

  /*-------------------------------------------------------------------------*/
  /* 公用全局数据类型声明                                                    */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /* 公用全局常量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /* 公用全局变量声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*-------------------------------------------------------------------------*/
  /* 公用过程函数声明                                                        */
  /*-------------------------------------------------------------------------*/
  /*--------------------------------------------------------------------------
  || 业务环节 : 统计报表执行入口
  || 函数名称 : prc_execute
  || 功能描述 :调用各过程，生成统计信息表
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :执行期号为空，默认统计上期数据
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_execute(prm_bke800   IN VARCHAR2, --执行期号
                        prm_appcode  OUT NUMBER, --执行代码
                        prm_errormsg OUT VARCHAR2 --错误信息
                        ) IS
    n_bke800    NUMBER(6); --统计期号
    n_aae001    NUMBER(4); --统计年度
    n_aae030    NUMBER(8); --开始日期
    n_aae031    NUMBER(8); --终止日期
    n_aaz706    NUMBER(16); --分组器ID
    n_sta_month NUMBER(2); --统计月份
    s_bke805    VARCHAR2(6); --报表表名
    s_bke803    VARCHAR2(3); --报表类型 1月报， 2季报，3半年报，4年报，5累计
    d_sysdate   DATE; --系统时间
    n_count     NUMBER(8) := 0; --计数器
    --定义报表类型数组
    TYPE array_bke803 IS TABLE OF VARCHAR2(3) INDEX BY BINARY_INTEGER;
    arr_bke803 array_bke803;
    /*定义参数游标用户动态获取统计表*/
    CURSOR CUR_KEK5 IS
      SELECT bke805 FROM kek5 WHERE AAE100 = '1' GROUP BY bke805;
    /*定义分组器类别游标*/
    CURSOR CUR_KAA5 IS
      SELECT aaz706 FROM kaa5 WHERE aae100 = '1';
  BEGIN
    /* 变量初始化 */
    prm_appcode  := pkg_comm.def_ok;
    prm_errormsg := NULL;
    n_bke800     := prm_bke800;
    d_sysdate    := SYSDATE;
    --统计期号:默认统计上期数据
    IF prm_bke800 IS NULL THEN
      n_bke800 := TO_CHAR(add_months(d_sysdate, -1), 'yyyymm');
    END IF;
    --统计年度
    n_aae001 := TO_CHAR(to_date(n_bke800, 'yyyymm'), 'yyyy');
    --统计月份
    n_sta_month := TO_CHAR(to_date(n_bke800, 'yyyymm'), 'mm');
    --报表数组赋值
    --月报
    IF MOD(n_sta_month, 1) = 0 THEN
      n_count := n_count + 1;
      arr_bke803(n_count) := pkg_comm.bke803_month;
    END IF;
    --季报
    IF MOD(n_sta_month, 3) = 0 THEN
      n_count := n_count + 1;
      arr_bke803(n_count) := pkg_comm.bke803_quarter;
    END IF;
    --半年报
    IF MOD(n_sta_month, 6) = 0 THEN
      n_count := n_count + 1;
      arr_bke803(n_count) := pkg_comm.bke803_semester;
    END IF;
    --年报
    IF MOD(n_sta_month, 12) = 0 THEN
      n_count := n_count + 1;
      arr_bke803(n_count) := pkg_comm.bke803_year;
    END IF;
    --累计
    n_count := n_count + 1;
    arr_bke803(n_count) := pkg_comm.bke803_total;
    --1、循环分组器配置
   -- FOR rec_KAA5 IN CUR_KAA5 LOOP
    -- n_aaz706 := rec_KAA5.aaz706;
      --2、循环当前月的报表类型
      FOR i IN 1 .. arr_bke803.count LOOP
        s_bke803 := arr_bke803(i);
        --2.1、获取当前报表类型的数据开始时间和结束时间
        pkg_comm.prc_getDate(s_bke803, --报表类型
                             n_bke800, --统计期号
                             n_aae030, --开始日期
                             n_aae031); --终止日期
        --2.2、生成对应的时间范围的临时表数据
        prc_generatestadata(n_bke800, --统计期号
                            n_aae001, --年度
                            s_bke803, --报表类型
                            n_aae030, --开始日期
                            n_aae031, --终止日期
                            --n_aaz706, --分组器ID
                            prm_appcode, --错误代码
                            prm_errormsg); --错误标志
        IF prm_appcode != pkg_comm.def_ok THEN
          RETURN;
        END IF;
        --3、循环需要统计的报表
        FOR rec_kek5 IN CUR_KEK5 LOOP
          --3.1、获取统计表名
          s_bke805 := rec_kek5.bke805;
          --3.2、写入操作日志
          prc_generateexelog(n_bke800,
                             n_aae001,
                             s_bke803,
                             s_bke805,
                             n_aae030,
                             n_aae031,
                             n_aaz706,
                             prm_appcode,
                             prm_errormsg);
          IF prm_appcode != pkg_comm.def_ok THEN
            RETURN;
          END IF;
          --4、case when 调用对应子过程
          CASE
          --KEJ1(病案首页统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEJ1 THEN
              prc_kej1(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
              --KEJ3(服务能力情况统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEJ3 THEN
              prc_kej3(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
              --KEJ4(服务效率情况统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEJ4 THEN
              prc_kej4(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
              --KEJ5(服务安全情况统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEJ5 THEN
              prc_kej5(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
              --KEJ6(费用占比情况统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEJ6 THEN
              prc_kej6(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
              --KEJ7(MDC情况统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEJ7 THEN
              prc_kej7(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
              --KEJ8(ADRGs情况统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEJ8 THEN
              prc_kej8(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
              --KEJ9(DRGs情况统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEJ9 THEN
              prc_kej9(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
              --KEK1(手术能力情况统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEK1 THEN
              prc_kek1(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
              --KEK2(医疗机构盈亏分析统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEK2 THEN
              prc_kek2(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
              --KEK3(DRGs盈亏分析统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEK3 THEN
              prc_kek3(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
              --KEK4(考核情况统计表)
            WHEN s_bke805 = pkg_comm.bke805_KEK4 THEN
              prc_kek4(n_bke800,
                       n_aae001,
                       s_bke803,
                       n_aae030,
                       n_aae031,
                       n_aaz706,
                       prm_appcode,
                       prm_errormsg);
              IF prm_appcode != pkg_comm.def_ok THEN
                NULL;
              END IF;
            ELSE
              NULL;
          END CASE;
        END LOOP;
        --5、提交commit,清全局临时表数据;
        COMMIT;
      END LOOP;
  --  END LOOP;
    --基于统计结果的信息统计
    --KEK6(服务评分统计表)
    prc_kek6(n_bke800, --统计期号
             prm_appcode, --执行代码
             prm_errormsg); --错误信息
    IF prm_appcode != pkg_comm.def_ok THEN
      RETURN;
    END IF;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '【PKG_A_Statistics.prc_execute】执行出错：' || SQLERRM;
  END prc_execute;

  /*--------------------------------------------------------------------------
  || 业务环节 : 统计日志信息表
  || 函数名称 : prc_generateexelog
  || 功能描述 :生成统计日志信息表
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :暂不考虑自治事务
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_generateexelog(prm_bke800   IN VARCHAR2, --统计期号
                               prm_aae001   IN VARCHAR2, --年度
                               prm_bke803   IN VARCHAR2, --报表类型
                               prm_bke805   IN VARCHAR2, --报表表名
                               prm_aae030   IN VARCHAR2, --开始日期
                               prm_aae031   IN VARCHAR2, --终止日期
                               prm_aaz706   IN NUMBER, --分组器信息ID
                               prm_appcode  OUT NUMBER, --执行代码
                               prm_errormsg OUT VARCHAR2) --错误信息
   IS
  BEGIN
    /* 变量初始化 */
    prm_appcode  := pkg_comm.def_ok;
    prm_errormsg := NULL;
    INSERT INTO KEM1
      (AAE001, --年度
       BKE803, --报表类型
       BKE800, --统计期号
       AAE030, --开始日期
       AAE031, --终止日期
       BKE805, --报表表名
       BKE807, --制表标志
       BAE108, --执行开始时间
       BAE109, --执行结束时间
       BAE191, --错误代码
       BAE188, --错误信息
       AAA027, --统筹区编码
       AAE013, --备注
       AAZ706 --分组器信息ID
       )
    VALUES
      (prm_aae001, --年度
       prm_bke803, --报表类型
       prm_bke800, --统计期号
       prm_aae030, --开始日期
       prm_aae031, --终止日期
       prm_bke805, --报表表名
       NULL, --制表标志
       SYSDATE, --执行开始时间
       NULL, --执行结束时间
       '0', --错误代码
       NULL, --错误信息
       pkg_comm.def_AAA027, --统筹区编码
       NULL, --备注
       prm_aaz706 --分组器信息ID
       );
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '统计日志信息【KEM1】生成出错：' || SQLERRM;
  END prc_generateexelog;

  /*--------------------------------------------------------------------------
  || 业务环节 : 统计分析使用临时数据
  || 函数名称 : prc_generatestadata
  || 功能描述 :生成统计分析使用临时数据
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :raogm
  || 完成日期 :2018-08-29
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_generatestadata(prm_bke800   IN VARCHAR2, --统计期号
                                prm_aae001   IN VARCHAR2, --年度
                                prm_bke803   IN VARCHAR2, --报表类型
                                prm_aae030   IN VARCHAR2, --开始日期
                                prm_aae031   IN VARCHAR2, --终止日期
                                --prm_aaz706   IN NUMBER, --分组器信息ID
                                prm_appcode  OUT NUMBER, --执行代码
                                prm_errormsg OUT VARCHAR2) --错误信息
   IS
    d_sysdate DATE; --系统时间
  BEGIN
    /* 变量初始化 */
    prm_appcode  := pkg_comm.def_ok;
    prm_errormsg := NULL;
    d_sysdate    := SYSDATE;
    --写全局临时表
    INSERT INTO　KHB7
      (BAZ506, --住院病案首页ID
       AKE554, --住院病案首页类型
       AKB020, --医疗服务机构编号
       AAE036, --病案上传时间
       AKB021, --医疗服务机构名称
       AKE300, --医疗付款方式
       AKE302, --病案号
       AAC003, --姓名
       AAC004, --性别
       AAC006, --出生日期
       AKC023, --年龄
       AKE304, --(年龄不足1周岁的)年龄(月)
       AKE305, --新生儿出生体重(克)
       AKE306, --新生儿入院体重(克）
       AAC005, --民族
       AAC002, --身份证号
       AAE006, --现住址
       BKF002, --出院科别
       BKC041, --实际住院天数
       BKC009, --入院时间
       AKE318, --入院时间时
       AKF001, --入院科别
       AKE319, --转科科别
       BKC010, --出院时间
       AKE320, --出院时间时
       AKE471, --离院方式
       AKE472, --医嘱转院，拟接收医疗机构名称
       AKE473, --医嘱转社区卫生服务机构/乡镇卫生院，拟接收医疗机构名称
       AAE019, --住院费用(元)：总费用
       AKE482, --自付金额
       AKE483, --综合医疗服务类：(1)一般医疗服务费
       AKE484, --综合医疗服务类：(2)一般治疗操作费
       ALC113, --综合医疗服务类：(3)护理费
       AKE485, --综合医疗服务类：(4)其他费用
       AKE486, --诊断类：(5)病理诊断费
       AKE487, --诊断类：(6)实验室诊断费
       AKE488, --诊断类：(7)影像学诊断费
       AKE489, --诊断类：(8)临床诊断项目费
       AKE490, --治疗类：(9)非手术治疗项目费
       AKE491, --治疗类：(9)非手术治疗项目费-临床物理治疗费
       AKE492, --治疗类：(10)手术治疗费
       AKE493, --治疗类：(10)手术治疗费-麻醉费
       AKE045, --治疗类：(10)手术治疗费-手术费
       AKE494, --康复类：(11)康复费
       AKE538, --综合医疗服务类：(1)一般医疗服务费-中医辨证论治费
       AKE539, --综合医疗服务类：(1)一般医疗服务费-中医辨证论治会诊费
       AKE540, --中医类(中医和名族医医疗服务)：(12)中医诊断
       AKE541, --中医类(中医和名族医医疗服务)：(13)中医治疗
       AKE542, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医外治
       AKE543, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医骨伤
       AKE544, --中医类(中医和名族医医疗服务)：(13)中医治疗-针刺与灸法
       AKE545, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医推拿治疗
       AKE546, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医肛肠治疗
       AKE547, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医特殊治疗
       AKE548, --中医类(中医和名族医医疗服务)：(14)中医其他
       AKE549, --中医类(中医和名族医医疗服务)：(14)中医其他-中医特殊调配加工
       AKE550, --中医类(中医和名族医医疗服务)：(14)中医其他-辨证施膳
       AKE047, --西药类：(15)西药费
       AKE496, --西药类：(15)西药费-抗菌药物费
       AKE050, --中药类：(16)中成药费
       AKE551, --中药类：(16)中成药费-医疗机构中药制剂费
       AKE049, --中药类：(17)中草药费
       AKE046, --血液和血液制品类：(18)血费
       AKE497, --血液和血液制品类：(19)白蛋白类制品费
       AKE498, --血液和血液制品类：(20)球蛋白类制品费
       AKE499, --血液和血液制品类：(21)凝血因子类制品费
       AKE500, --血液和血液制品类：(22)细胞因子类制品费
       AKE501, --耗材类：(23)检查用一次性医用材料费
       AKE502, --耗材类：(24)治疗用一次性医用材料费
       AKE503, --耗材类：(25)手术用一次性医用材料费
       AKE044, --其他类：(26)其他费
       AAZ921, --病种分组记录ID
       BKE709, --校验标志
       BKE741, --校验失败信息
       BKE742, --分组状态
       BKE743, --分组失败信息
       BKE715, --分组器类型
       BKF098, --亚目编码
       BKF099, --亚目名称
       BKEH39, --病种编码
       BKEH40, --病种名称
       BAC001, --个人编码
       AKC190, --就诊登记号
       BAC002, --人群类别
       AKA130, --医疗类别
       AKC264, --医疗费总额
       AKE051, --全自费金额
       AKC228, --挂钩自付金额
       BKC074, --特殊挂钩自付金额
       BKC027, --符合报销范围金额
       BKC029, --起付线自付金额
       BKC030, --基本医疗统筹支付比例
       BKC031, --基本医疗统筹自付金额
       AKE039, --基本医疗基金支出
       BKC032, --大额医疗统筹支付比例
       BKC033, --大额医疗统筹自付金额
       AKE029, --大额医疗基金支出
       BKC040, --超限自付金额
       BKA033, --单病种编码
       AAE139, --异地标志
       BAC046, --建档立卡贫困人口标志
       AKE100, --结算时间
       AAA027, --统筹区编码
       BAA001, --分中心编码
       AAB301 --行政区划代码
       )
      SELECT b.BAZ506 AS BAZ506, --住院病案首页ID
             b.AKE554 AS AKE554, --住院病案首页类型
             c.AKB020 AS AKB020, --医疗服务机构编号
             b.AAE036 AS AAE036, --病案上传时间
             b.AKB021 AS AKB021, --医疗服务机构名称
             b.AKE300 AS AKE300, --医疗付款方式
             b.AKE302 AS AKE302, --病案号
             b.AAC003 AS AAC003, --姓名
             b.AAC004 AS AAC004, --性别
             b.AAC006 AS AAC006, --出生日期
             b.AKC023 AS AKC023, --年龄
             b.AKE304 AS AKE304, --(年龄不足1周岁的)年龄(月)
             b.AKE305 AS AKE305, --新生儿出生体重(克)
             b.AKE306 AS AKE306, --新生儿入院体重(克）
             b.AAC005 AS AAC005, --民族
             b.AAC002 AS AAC002, --身份证号
             b.AAE006 AS AAE006, --现住址
             b.BKF002 AS BKF002, --出院科别
             b.BKC041 AS BKC041, --实际住院天数
             b.BKC009 AS BKC009, --入院时间
             b.AKE318 AS AKE318, --入院时间时
             b.AKF001 AS AKF001, --入院科别
             b.AKE319 AS AKE319, --转科科别
             b.BKC010 AS BKC010, --出院时间
             b.AKE320 AS AKE320, --出院时间时
             b.AKE471 AS AKE471, --离院方式
             b.AKE472 AS AKE472, --医嘱转院，拟接收医疗机构名称
             b.AKE473 AS AKE473, --医嘱转社区卫生服务机构/乡镇卫生院，拟接收医疗机构名称
             b.AKC264 AS AAE019, --住院费用(元)：总费用
             b.AKE482 AS AKE482, --自付金额
             b.AKE483 AS AKE483, --综合医疗服务类：(1)一般医疗服务费
             b.AKE484 AS AKE484, --综合医疗服务类：(2)一般治疗操作费
             b.ALC113 AS ALC113, --综合医疗服务类：(3)护理费
             b.AKE485 AS AKE485, --综合医疗服务类：(4)其他费用
             b.AKE486 AS AKE486, --诊断类：(5)病理诊断费
             b.AKE487 AS AKE487, --诊断类：(6)实验室诊断费
             b.AKE488 AS AKE488, --诊断类：(7)影像学诊断费
             b.AKE489 AS AKE489, --诊断类：(8)临床诊断项目费
             b.AKE490 AS AKE490, --治疗类：(9)非手术治疗项目费
             b.AKE491 AS AKE491, --治疗类：(9)非手术治疗项目费-临床物理治疗费
             b.AKE492 AS AKE492, --治疗类：(10)手术治疗费
             b.AKE493 AS AKE493, --治疗类：(10)手术治疗费-麻醉费
             b.AKE045 AS AKE045, --治疗类：(10)手术治疗费-手术费
             b.AKE494 AS AKE494, --康复类：(11)康复费
             b.AKE538 AS AKE538, --综合医疗服务类：(1)一般医疗服务费-中医辨证论治费
             b.AKE539 AS AKE539, --综合医疗服务类：(1)一般医疗服务费-中医辨证论治会诊费
             b.AKE540 AS AKE540, --中医类(中医和名族医医疗服务)：(12)中医诊断
             b.AKE541 AS AKE541, --中医类(中医和名族医医疗服务)：(13)中医治疗
             b.AKE542 AS AKE542, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医外治
             b.AKE543 AS AKE543, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医骨伤
             b.AKE544 AS AKE544, --中医类(中医和名族医医疗服务)：(13)中医治疗-针刺与灸法
             b.AKE545 AS AKE545, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医推拿治疗
             b.AKE546 AS AKE546, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医肛肠治疗
             b.AKE547 AS AKE547, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医特殊治疗
             b.AKE548 AS AKE548, --中医类(中医和名族医医疗服务)：(14)中医其他
             b.AKE549 AS AKE549, --中医类(中医和名族医医疗服务)：(14)中医其他-中医特殊调配加工
             b.AKE550 AS AKE550, --中医类(中医和名族医医疗服务)：(14)中医其他-辨证施膳
             b.AKE047 AS AKE047, --西药类：(15)西药费
             b.AKE496 AS AKE496, --西药类：(15)西药费-抗菌药物费
             b.AKE050 AS AKE050, --中药类：(16)中成药费
             b.AKE551 AS AKE551, --中药类：(16)中成药费-医疗机构中药制剂费
             b.AKE049 AS AKE049, --中药类：(17)中草药费
             b.AKE046 AS AKE046, --血液和血液制品类：(18)血费
             b.AKE497 AS AKE497, --血液和血液制品类：(19)白蛋白类制品费
             b.AKE498 AS AKE498, --血液和血液制品类：(20)球蛋白类制品费
             b.AKE499 AS AKE499, --血液和血液制品类：(21)凝血因子类制品费
             b.AKE500 AS AKE500, --血液和血液制品类：(22)细胞因子类制品费
             b.AKE501 AS AKE501, --耗材类：(23)检查用一次性医用材料费
             b.AKE502 AS AKE502, --耗材类：(24)治疗用一次性医用材料费
             b.AKE503 AS AKE503, --耗材类：(25)手术用一次性医用材料费
             b.AKE044 AS AKE044, --其他类：(26)其他费
             a.AAZ921 AS AAZ921, --病种分组记录ID
             a.BKE709 AS BKE709, --校验标志
             a.BKE741 AS BKE741, --校验失败信息
             a.BKE742 AS BKE742, --分组状态
             a.BKE743 AS BKE743, --分组失败信息
             a.BKE715 AS BKE715, --分组器类型
             a.BKF098 AS BKF098, --亚目编码
             a.BKF099 AS BKF099, --亚目名称
             a.BKEH39 AS BKEH39, --病种编码
             a.BKEH40 AS BKEH40, --病种名称
             c.BAC001 AS BAC001, --个人编码
             b.AKC190 AS AKC190, --就诊登记号
             c.BAC002 AS BAC002, --人群类别
             c.AKA130 AS AKA130, --医疗类别
             c.AKC264 AS AKC264, --医疗费总额
             c.AKE051 AS AKE051, --全自费金额
             c.AKC228 AS AKC228, --挂钩自付金额
             c.BKC074 AS BKC074, --特殊挂钩自付金额
             c.BKC027 AS BKC027, --符合报销范围金额
             c.BKC029 AS BKC029, --起付线自付金额
             c.BKC030 AS BKC030, --基本医疗统筹支付比例
             c.BKC031 AS BKC031, --基本医疗统筹自付金额
             c.AKE039 AS AKE039, --基本医疗基金支出
             c.BKC032 AS BKC032, --大额医疗统筹支付比例
             c.BKC033 AS BKC033, --大额医疗统筹自付金额
             c.AKE029 AS AKE029, --大额医疗基金支出
             c.BKC040 AS BKC040, --超限自付金额
             c.BKA033 AS BKA033, --单病种编码
             c.AAE139 AS AAE139, --异地标志
             c.BAC046 AS BAC046, --建档立卡贫困人口标志
             c.AKE100 AS AAE100, --结算时间
             d.AAA027 AS AAA027, --统筹区编码
             d.BAA001 AS BAA001, --分中心编码
             d.AAB301 AS AAB301 --行政区划代码
        FROM KH57 a, --病案分组信息
             (SELECT AKB021 AS AKB021, -- 医疗服务机构名称
                     AKE300 AS AKE300, -- 医疗付款方式
                     AKE302 AS AKE302, -- 病案号
                     AAC003 AS AAC003, -- 姓名
                     AAC004 AS AAC004, -- 性别
                     AAC006 AS AAC006, -- 出生日期
                     AKC023 AS AKC023, -- 年龄
                     AKE304 AS AKE304, -- (年龄不足1周岁的)年龄(月)
                     AKE305 AS AKE305, -- 新生儿出生体重(克)
                     AKE306 AS AKE306, -- 新生儿入院体重(克）
                     AAC005 AS AAC005, -- 民族
                     AAC002 AS AAC002, -- 身份证号
                     AAE006 AS AAE006, -- 现住址
                     BKC009 AS BKC009, -- 入院时间
                     AKE318 AS AKE318, -- 入院时间时
                     AKF001 AS AKF001, -- 入院科别
                     AKE319 AS AKE319, -- 转科科别
                     BKC010 AS BKC010, -- 出院时间
                     AKE320 AS AKE320, -- 出院时间时
                     BKF002 AS BKF002, -- 出院科别
                     BKC041 AS BKC041, -- 实际住院天数
                     AKE471 AS AKE471, -- 离院方式
                     AKE472 AS AKE472, -- 医嘱转院，拟接收医疗机构名称
                     AKE473 AS AKE473, -- 医嘱转社区卫生服务机构/乡镇卫生院，拟接收医疗机构名称
                     AKC264 AS AKC264, -- 住院费用(元)：总费用
                     AKE482 AS AKE482, -- 自付金额
                     AKE483 AS AKE483, -- 综合医疗服务类：(1)一般医疗服务费
                     AKE538 AS AKE538, -- 综合医疗服务类：(1)一般医疗服务费-中医辨证论治费
                     AKE539 AS AKE539, -- 综合医疗服务类：(1)一般医疗服务费-中医辨证论治会诊费
                     AKE484 AS AKE484, -- 综合医疗服务类：(2)一般治疗操作费
                     ALC113 AS ALC113, -- 综合医疗服务类：(3)护理费
                     AKE485 AS AKE485, -- 综合医疗服务类：(4)其他费用
                     AKE486 AS AKE486, -- 诊断类：(5)病理诊断费
                     AKE487 AS AKE487, -- 诊断类：(6)实验室诊断费
                     AKE488 AS AKE488, -- 诊断类：(7)影像学诊断费
                     AKE489 AS AKE489, -- 诊断类：(8)临床诊断项目费
                     AKE490 AS AKE490, -- 治疗类：(9)非手术治疗项目费
                     AKE491 AS AKE491, -- 治疗类：(9)非手术治疗项目费-临床物理治疗费
                     AKE492 AS AKE492, -- 治疗类：(10)手术治疗费
                     AKE493 AS AKE493, -- 治疗类：(10)手术治疗费-麻醉费
                     AKE045 AS AKE045, -- 治疗类：(10)手术治疗费-手术费
                     AKE494 AS AKE494, -- 康复类：(11)康复费
                     AKE540 AS AKE540, -- 中医类(中医和名族医医疗服务)：(12)中医诊断
                     AKE541 AS AKE541, -- 中医类(中医和名族医医疗服务)：(13)中医治疗
                     AKE542 AS AKE542, -- 中医类(中医和名族医医疗服务)：(13)中医治疗-中医外治
                     AKE543 AS AKE543, -- 中医类(中医和名族医医疗服务)：(13)中医治疗-中医骨伤
                     AKE544 AS AKE544, -- 中医类(中医和名族医医疗服务)：(13)中医治疗-针刺与灸法
                     AKE545 AS AKE545, -- 中医类(中医和名族医医疗服务)：(13)中医治疗-中医推拿治疗
                     AKE546 AS AKE546, -- 中医类(中医和名族医医疗服务)：(13)中医治疗-中医肛肠治疗
                     AKE547 AS AKE547, -- 中医类(中医和名族医医疗服务)：(13)中医治疗-中医特殊治疗
                     AKE548 AS AKE548, -- 中医类(中医和名族医医疗服务)：(14)中医其他
                     AKE549 AS AKE549, -- 中医类(中医和名族医医疗服务)：(14)中医其他-中医特殊调配加工
                     AKE550 AS AKE550, -- 中医类(中医和名族医医疗服务)：(14)中医其他-辨证施膳
                     AKE047 AS AKE047, -- 西药类：(15)西药费
                     AKE496 AS AKE496, -- 西药类：(15)西药费-抗菌药物费
                     AKE050 AS AKE050, -- 中药类：(16)中成药费
                     AKE551 AS AKE551, -- 中药类：(16)中成药费-医疗机构中药制剂费
                     AKE049 AS AKE049, -- 中药类：(17)中草药费
                     AKE046 AS AKE046, -- 血液和血液制品类：(18)血费
                     AKE497 AS AKE497, -- 血液和血液制品类：(19)白蛋白类制品费
                     AKE498 AS AKE498, -- 血液和血液制品类：(20)球蛋白类制品费
                     AKE499 AS AKE499, -- 血液和血液制品类：(21)凝血因子类制品费
                     AKE500 AS AKE500, -- 血液和血液制品类：(22)细胞因子类制品费
                     AKE501 AS AKE501, -- 耗材类：(23)检查用一次性医用材料费
                     AKE502 AS AKE502, -- 耗材类：(24)治疗用一次性医用材料费
                     AKE503 AS AKE503, -- 耗材类：(25)手术用一次性医用材料费
                     AKE044 AS AKE044, -- 其他类：(26)其他费
                     BAZ506 AS BAZ506, -- 住院病案首页ID
                     AKE554 AS AKE554, --住院病案首页类型
                     AKC190 AS AKC190, --就诊登记号
                     AKE100 AS AKE100, --结算时间
                     AAE036 AS AAE036, --病案上传时间
                     AAA027 AS AAA027, --统筹区编码
                     BAA001 AS BAA001, --分中心编码
                     AKB020 AS AKB020
                FROM KEC3 a) b, --病案首页信息
             KEA5 c, --费用结算信息
             KB01 d --医疗机构信息
       WHERE a.akb020 = d.akb020 --医疗机构编码
         AND a.akc190 = b.akc190  --住院病案首页ID
         AND a.akb020 = b.akb020
         AND a.AKC190 = c.AKC190(+) --就诊登记号
         AND a.akb020 = c.akb020(+) --医疗机构编码
         AND nvl(c.AAA131, '0') != '1' --结算撤销标志
         AND nvl(a.AAA131, '0') != '1' --分组撤销标志
         AND c.bac002 IN ('1', '2') --人群类别
         AND c.AkE100 >=
             to_date(prm_aae030 || ' 00:00:00', 'yyyymmdd hh24:mi:ss') --结算开始时间
         AND c.AkE100 <=
             to_date(prm_aae031 || ' 23:59:59', 'yyyymmdd hh24:mi:ss'); --结算终止时间
    --统计源数据备份
    BEGIN
      INSERT INTO KHB7_HIS
        (AAE001, --年度
         BKE803, --报表类型
         BKE800, --统计期号
         BAE108, --执行时间
         BAZ506, --住院病案首页ID
         AKE554, --住院病案首页类型
         AKB020, --医疗服务机构编号
         AAE036, --病案上传时间
         AKB021, --医疗服务机构名称
         AKE300, --医疗付款方式
         AKE302, --病案号
         AAC003, --姓名
         AAC004, --性别
         AAC006, --出生日期
         AKC023, --年龄
         AKE304, --(年龄不足1周岁的)年龄(月)
         AKE305, --新生儿出生体重(克)
         AKE306, --新生儿入院体重(克）
         AAC005, --民族
         AAC002, --身份证号
         AAE006, --现住址
         BKF002, --出院科别
         BKC041, --实际住院天数
         BKC009, --入院时间
         AKE318, --入院时间时
         AKF001, --入院科别
         AKE319, --转科科别
         BKC010, --出院时间
         AKE320, --出院时间时
         AKE471, --离院方式
         AKE472, --医嘱转院，拟接收医疗机构名称
         AKE473, --医嘱转社区卫生服务机构/乡镇卫生院，拟接收医疗机构名称
         AAE019, --住院费用(元)：总费用
         AKE482, --自付金额
         AKE483, --综合医疗服务类：(1)一般医疗服务费
         AKE484, --综合医疗服务类：(2)一般治疗操作费
         ALC113, --综合医疗服务类：(3)护理费
         AKE485, --综合医疗服务类：(4)其他费用
         AKE486, --诊断类：(5)病理诊断费
         AKE487, --诊断类：(6)实验室诊断费
         AKE488, --诊断类：(7)影像学诊断费
         AKE489, --诊断类：(8)临床诊断项目费
         AKE490, --治疗类：(9)非手术治疗项目费
         AKE491, --治疗类：(9)非手术治疗项目费-临床物理治疗费
         AKE492, --治疗类：(10)手术治疗费
         AKE493, --治疗类：(10)手术治疗费-麻醉费
         AKE045, --治疗类：(10)手术治疗费-手术费
         AKE494, --康复类：(11)康复费
         AKE538, --综合医疗服务类：(1)一般医疗服务费-中医辨证论治费
         AKE539, --综合医疗服务类：(1)一般医疗服务费-中医辨证论治会诊费
         AKE540, --中医类(中医和名族医医疗服务)：(12)中医诊断
         AKE541, --中医类(中医和名族医医疗服务)：(13)中医治疗
         AKE542, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医外治
         AKE543, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医骨伤
         AKE544, --中医类(中医和名族医医疗服务)：(13)中医治疗-针刺与灸法
         AKE545, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医推拿治疗
         AKE546, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医肛肠治疗
         AKE547, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医特殊治疗
         AKE548, --中医类(中医和名族医医疗服务)：(14)中医其他
         AKE549, --中医类(中医和名族医医疗服务)：(14)中医其他-中医特殊调配加工
         AKE550, --中医类(中医和名族医医疗服务)：(14)中医其他-辨证施膳
         AKE047, --西药类：(15)西药费
         AKE496, --西药类：(15)西药费-抗菌药物费
         AKE050, --中药类：(16)中成药费
         AKE551, --中药类：(16)中成药费-医疗机构中药制剂费
         AKE049, --中药类：(17)中草药费
         AKE046, --血液和血液制品类：(18)血费
         AKE497, --血液和血液制品类：(19)白蛋白类制品费
         AKE498, --血液和血液制品类：(20)球蛋白类制品费
         AKE499, --血液和血液制品类：(21)凝血因子类制品费
         AKE500, --血液和血液制品类：(22)细胞因子类制品费
         AKE501, --耗材类：(23)检查用一次性医用材料费
         AKE502, --耗材类：(24)治疗用一次性医用材料费
         AKE503, --耗材类：(25)手术用一次性医用材料费
         AKE044, --其他类：(26)其他费
         AAZ921, --病种分组记录ID
         BKE709, --校验标志
         BKE741, --校验失败信息
         BKE742, --分组状态
         BKE743, --分组失败信息
         BKE715, --分组器类型
         BKF098, --亚目编码
         BKF099, --亚目名称
         BKEH39, --病种编码
         BKEH40, --病种名称
         BAC001, --个人编码
         AKC190, --就诊登记号
         BAC002, --人群类别
         AKA130, --医疗类别
         AKC264, --医疗费总额
         AKE051, --全自费金额
         AKC228, --挂钩自付金额
         BKC074, --特殊挂钩自付金额
         BKC027, --符合报销范围金额
         BKC029, --起付线自付金额
         BKC030, --基本医疗统筹支付比例
         BKC031, --基本医疗统筹自付金额
         AKE039, --基本医疗基金支出
         BKC032, --大额医疗统筹支付比例
         BKC033, --大额医疗统筹自付金额
         AKE029, --大额医疗基金支出
         BKC040, --超限自付金额
         BKA033, --单病种编码
         AAE139, --异地标志
         BAC046, --建档立卡贫困人口标志
         AKE100, --结算时间
         AAA027, --统筹区编码
         BAA001, --分中心编码
         AAB301 --行政区划代码
         )
        SELECT prm_aae001, --年度
               prm_bke803, --报表类型
               prm_bke800, --统计期号
               d_sysdate, --执行时间
               BAZ506, --住院病案首页ID
               AKE554, --住院病案首页类型
               AKB020, --医疗服务机构编号
               AAE036, --病案上传时间
               AKB021, --医疗服务机构名称
               AKE300, --医疗付款方式
               AKE302, --病案号
               AAC003, --姓名
               AAC004, --性别
               AAC006, --出生日期
               AKC023, --年龄
               AKE304, --(年龄不足1周岁的)年龄(月)
               AKE305, --新生儿出生体重(克)
               AKE306, --新生儿入院体重(克）
               AAC005, --民族
               AAC002, --身份证号
               AAE006, --现住址
               BKF002, --出院科别
               BKC041, --实际住院天数
               BKC009, --入院时间
               AKE318, --入院时间时
               AKF001, --入院科别
               AKE319, --转科科别
               BKC010, --出院时间
               AKE320, --出院时间时
               AKE471, --离院方式
               AKE472, --医嘱转院，拟接收医疗机构名称
               AKE473, --医嘱转社区卫生服务机构/乡镇卫生院，拟接收医疗机构名称
               AAE019, --住院费用(元)：总费用
               AKE482, --自付金额
               AKE483, --综合医疗服务类：(1)一般医疗服务费
               AKE484, --综合医疗服务类：(2)一般治疗操作费
               ALC113, --综合医疗服务类：(3)护理费
               AKE485, --综合医疗服务类：(4)其他费用
               AKE486, --诊断类：(5)病理诊断费
               AKE487, --诊断类：(6)实验室诊断费
               AKE488, --诊断类：(7)影像学诊断费
               AKE489, --诊断类：(8)临床诊断项目费
               AKE490, --治疗类：(9)非手术治疗项目费
               AKE491, --治疗类：(9)非手术治疗项目费-临床物理治疗费
               AKE492, --治疗类：(10)手术治疗费
               AKE493, --治疗类：(10)手术治疗费-麻醉费
               AKE045, --治疗类：(10)手术治疗费-手术费
               AKE494, --康复类：(11)康复费
               AKE538, --综合医疗服务类：(1)一般医疗服务费-中医辨证论治费
               AKE539, --综合医疗服务类：(1)一般医疗服务费-中医辨证论治会诊费
               AKE540, --中医类(中医和名族医医疗服务)：(12)中医诊断
               AKE541, --中医类(中医和名族医医疗服务)：(13)中医治疗
               AKE542, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医外治
               AKE543, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医骨伤
               AKE544, --中医类(中医和名族医医疗服务)：(13)中医治疗-针刺与灸法
               AKE545, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医推拿治疗
               AKE546, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医肛肠治疗
               AKE547, --中医类(中医和名族医医疗服务)：(13)中医治疗-中医特殊治疗
               AKE548, --中医类(中医和名族医医疗服务)：(14)中医其他
               AKE549, --中医类(中医和名族医医疗服务)：(14)中医其他-中医特殊调配加工
               AKE550, --中医类(中医和名族医医疗服务)：(14)中医其他-辨证施膳
               AKE047, --西药类：(15)西药费
               AKE496, --西药类：(15)西药费-抗菌药物费
               AKE050, --中药类：(16)中成药费
               AKE551, --中药类：(16)中成药费-医疗机构中药制剂费
               AKE049, --中药类：(17)中草药费
               AKE046, --血液和血液制品类：(18)血费
               AKE497, --血液和血液制品类：(19)白蛋白类制品费
               AKE498, --血液和血液制品类：(20)球蛋白类制品费
               AKE499, --血液和血液制品类：(21)凝血因子类制品费
               AKE500, --血液和血液制品类：(22)细胞因子类制品费
               AKE501, --耗材类：(23)检查用一次性医用材料费
               AKE502, --耗材类：(24)治疗用一次性医用材料费
               AKE503, --耗材类：(25)手术用一次性医用材料费
               AKE044, --其他类：(26)其他费
               AAZ921, --病种分组记录ID
               BKE709, --校验标志
               BKE741, --校验失败信息
               BKE742, --分组状态
               BKE743, --分组失败信息
               BKE715, --分组器类型
               BKF098, --亚目编码
               BKF099, --亚目名称
               BKEH39, --病种编码
               BKEH40, --病种名称
               BAC001, --个人编码
               AKC190, --就诊登记号
               BAC002, --人群类别
               AKA130, --医疗类别
               AKC264, --医疗费总额
               AKE051, --全自费金额
               AKC228, --挂钩自付金额
               BKC074, --特殊挂钩自付金额
               BKC027, --符合报销范围金额
               BKC029, --起付线自付金额
               BKC030, --基本医疗统筹支付比例
               BKC031, --基本医疗统筹自付金额
               AKE039, --基本医疗基金支出
               BKC032, --大额医疗统筹支付比例
               BKC033, --大额医疗统筹自付金额
               AKE029, --大额医疗基金支出
               BKC040, --超限自付金额
               BKA033, --单病种编码
               AAE139, --异地标志
               BAC046, --建档立卡贫困人口标志
               AKE100, --结算时间
               AAA027, --统筹区编码
               BAA001, --分中心编码
               AAB301 --行政区划代码
          FROM KHB7;
    EXCEPTION
      WHEN OTHERS THEN
        prm_appcode  := pkg_comm.def_err;
        prm_errormsg := '数据备份失败：【报表类型：' || prm_bke803 || '】' || SQLERRM;
        RETURN;
    END;
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '统计分析数据【KEM2】生成出错：' || SQLERRM;
  END prc_generatestadata;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEJ1(病案首页统计表)
  || 函数名称 : Prc_KEJ1
  || 功能描述 :生成病案首页统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :病案是否有效以校验标志为准，校验通过 1为有效病案，校验未通过0 为无效病案
  || 作    者 :raogm
  || 完成日期 :2018-08-29
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kej1(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
    /*游标声明*/
    --统计级别
    CURSOR cur_level IS
      SELECT BKE804
        FROM KEK5 --KEK5(统计报表开通信息表)
       WHERE BKE805 = s_BKE805
         AND NVL(BKE803, prm_bke803) = prm_bke803
         AND AAE030 <= n_sysdate
         AND (AAE031 >= n_sysdate OR AAE031 IS NULL)
         AND NVL(AAE100, '1') = '1'
       GROUP BY BKE804;
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEJ1;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    --回滚点
    SAVEPOINT point_kej1;
    --统计级别
    BEGIN
      FOR rec_KEJ2 IN cur_level LOOP
        INSERT INTO KEJ1
          (AAE001, --年度
           BKE803, --报表类型
           BKE800, --统计期号
           AAE030, --开始日期
           AAE031, --终止日期
           BKE804, --统计级别
           AAZ722, --医疗机构信息识别ID
           AKE554, --住院病案首页类型
           BKE708, --病案总数
           BKE758, --有效病案数
           BKE785, --无效病案数
           BKE786, --病案合格率
           AKB020, --医疗服务机构编码
           AKB021, --医疗服务机构名称
           AKA101, --医院等级
           BAA001, --分中心
           AAA027, --统筹区
           BKE801, --制表人
           BKE802, --制表日期
           BAC002, --人群类别
           AAA131 --撤销标志
           )
          WITH d AS
           (SELECT c.BKE804, --统计级别
                   C.AAZ722, --医疗机构信息识别ID
                   A.AKE554, --住院病案首页类型
                   COUNT(a.baz506) AS BKE708, --病案总数
                   SUM(decode(nvl(BKE709, '0'), '0', 0, 1)) AS BKE758, --有效病案数
                   SUM(decode(nvl(BKE709, '0'), '0', 1, 0)) AS BKE785, --无效病案数
                   c.AKB020 AS AKB020, --医疗服务机构编码
                   c.AKB021 AS AKB021, --医疗服务机构名称
                   c.AKA101 AS AKA101, --医院等级
                   c.BAA001 AS BAA001, --分中心
                   c.AAA027 AS AAA027, --统筹区
                   NVL(a.BAC002, '9') AS BAC002 --人群类别
              FROM KEM2 a,
                   (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                           a.BKE804 AS BKE804, --统计级别
                           a.AAA027 AS AAA027, --统筹区
                           a.AKA101 AS AKA101, --医院等级
                           a.BAA001 AS BAA001, --分中心
                           a.AAB301 AS AAB301, --行政区划代码
                           a.AKB020 AS AKB020, --医疗服务机构编码
                           a.AKB021 AS AKB021, --医疗服务机构名称
                           a.BKF014 AS BKF014, --科室分类编码
                           a.BKF033 AS BKF033, --科室分类名称
                           a.AKF001 AS AKF001, --科室编码
                           a.BKF001 AS BKF001, --科室名称
                           a.BKF016 AS BKF016, --医疗小组编码
                           a.BKF017 AS BKF017, --医疗小组名称
                           a.AAF009 AS AAF009, --医护人员职务
                           a.BKF006 AS BKF006, --医护人员编码
                           a.AKE022 AS AKE022 --医护人员名称
                      FROM KEJ2 a, --KEJ2(统计粒度信息表)
                           KEK5 b --KEK5(统计报表开通信息表)
                     WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                       AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                       AND b.BKE805 = s_BKE805 --报表表名
                       AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                       AND b.AAE030 <= n_sysdate
                       AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                       AND NVL(b.AAE100, '1') = '1') c
             WHERE 1 = 1
                  ---------------动态拼接级别关联条件-----------
               AND a.AAA027 = CASE
                     WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                      c.AAA027
                     ELSE
                      a.AAA027
                   END --统筹区级
               AND a.BAA001 = CASE
                     WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                      c.BAA001
                     ELSE
                      a.BAA001
                   END --分中心级
               AND a.AAB301 = CASE
                     WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                      c.AAB301
                     ELSE
                      a.AAB301
                   END --区县级
               AND a.AKB020 = CASE
                     WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                      c.AKB020
                     ELSE
                      a.AKB020
                   END --医院级
            ---------------动态拼接级别关联条件-------------
             GROUP BY c.AAZ722, --医疗机构信息识别ID
                      c.BKE804, --统计级别
                      c.AAA027, --统筹区
                      c.AKA101, --医院等级
                      c.BAA001, --分中心
                      c.AAB301, --行政区划代码
                      c.AKB020, --医疗服务机构编码
                      c.AKB021, --医疗服务机构名称
                      c.BKF014, --科室分类编码
                      c.BKF033, --科室分类名称
                      c.AKF001, --科室编码
                      c.BKF001, --科室名称
                      c.BKF016, --医疗小组编码
                      c.BKF017, --医疗小组名称
                      c.AAF009, --医护人员职务
                      c.BKF006, --医护人员编码
                      c.AKE022, --医护人员名称
                      A.AKE554, --病案首页类型
                      A.BAC002 --人群类别
            )
          SELECT prm_aae001 AS AAE001, --年度
                 prm_bke803 AS BKE803, --报表类型
                 prm_bke800 AS BKE800, --统计期号
                 prm_aae030 AS AAE030, --开始日期
                 prm_aae031 AS AAE031, --终止日期
                 d.BKE804, --统计级别
                 d.AAZ722, --医疗机构信息识别ID
                 d.AKE554, --住院病案首页类型
                 SUM(d.BKE708) AS BKE708, --病案总数
                 SUM(d.BKE758) AS BKE758, --有效病案数
                 SUM(d.BKE785) AS BKE785, --无效病案数
                 trunc(SUM(d.BKE758) / SUM(BKE708), 4) BKE786, --病案合格率
                 d.AKB020 AS AKB020, --医疗服务机构编码
                 d.AKB021 AS AKB021, --医疗服务机构名称
                 d.AKA101 AS AKA101, --医院等级
                 d.BAA001 AS BAA001, --分中心
                 d.AAA027 AS AAA027, --统筹区
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 NVL(d.BAC002, '0') AS BAC002, --人群类别
                 '0' AS AAA131 --撤销标志
                 FROM　d GROUP BY d.BKE804, --统计级别
                 d.AAZ722, --医疗机构信息识别ID
                 d.AKE554, --住院病案首页类型
                 d.AKB020, --医疗服务机构编码
                 d.AKB021, --医疗服务机构名称
                 d.AKA101, --医院等级
                 d.BAA001, --分中心
                 d.AAA027, --统筹区
                 ROLLUP(d.BAC002);
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO point_kej1;
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := '病案首页统计信息【KEJ1】生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND aae001 = prm_aae001 --年度
       AND bke803 = prm_bke803 --报表类型
       AND bke805 = s_BKE805 --表名
       AND aaz706 = prm_aaz706 --分组器信息ID
       AND bke807 IS NULL; --制表标志
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '病案首页统计信息【KEJ1】生成出错：' || SQLERRM;
  END prc_kej1;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEJ3(服务能力情况统计表)
  || 函数名称 : Prc_KEJ3
  || 功能描述 :生成服务能力情况统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kej3(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    s_BKE804  VARCHAR2(4); --统计级别
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
    /*游标声明*/
    --统计级别
    CURSOR cur_level IS
      SELECT BKE804
        FROM KEK5 --KEK5(统计报表开通信息表)
       WHERE BKE805 = s_BKE805
         AND NVL(BKE803, prm_bke803) = prm_bke803
         AND AAE030 <= n_sysdate
         AND (AAE031 >= n_sysdate OR AAE031 IS NULL)
         AND NVL(AAE100, '1') = '1'
       GROUP BY BKE804;
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEJ3;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    SAVEPOINT point_kej3;
    BEGIN
      FOR rec_KEJ2 IN cur_level LOOP
        INSERT INTO kej3
          (aae001, --年度
           bke803, --报表类型
           bke800, --统计期号
           aae030, --开始日期
           aae031, --终止日期
           bke804, --统计级别
           aaz722, --医疗机构信息识别id
           bke708, --病案总数
           bke758, --有效病案数
           bke760, --排除病案数
           bke790, --分组病案数
           bke791, -- 入组病案数
           bke762, -- drg组数
           bkb276, -- drg入组率
           bke792, -- 医保支付分析入组病案数
           bke793, -- 未入组病案数
           bke799, -- 未入组权重
           bke801, -- 制表人
           bke802, -- 制表日期
           aaa131, -- 撤销标志
           aae013, -- 备注
           aaz706, -- 分组器信息id
           BAC002 --人群类别
           )
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 b.aaz722 AS aaz722, --医疗机构信息识别id
                 COUNT(1) AS bke708, --病案总数
                 COUNT(CASE
                         WHEN a.bke709 = 1 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke758, -- 有效病案数
                 COUNT(CASE
                         WHEN a.bke709 = 0 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke760, -- 排除病案数
                 COUNT(CASE
                         WHEN a.bke709 = 1 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke790, -- 分组病案数
                 COUNT(CASE
                         WHEN a.BKE742 = 1 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke791, -- 入组病案数
                 COUNT(DISTINCT(CASE
                                  WHEN c.bke901 = 2 THEN
                                   a.bkeh39
                                  ELSE
                                   NULL
                                END)) AS bke762, -- 病种组数
                 COUNT(CASE
                         WHEN a.BKE742 = 1 THEN
                          1
                         ELSE
                          NULL
                       END) / nullif(COUNT(CASE
                                             WHEN a.bke709 = 1 THEN
                                              1
                                             ELSE
                                              NULL
                                           END),
                                     0) AS bkb276, --入组率
                 COUNT(CASE
                         WHEN a.BKE742 = 1 AND a.AKE039 > 0 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke792, --医保支付分析入组病案数
                 COUNT(CASE
                         WHEN a.BKE742 = 0 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke793, -- 未入组病案数
                 SUM(CASE
                       WHEN a.BKE742 = 0 THEN
                        a.AKC264
                       ELSE
                        NULL
                     END) / nullif((SUM(CASE
                                          WHEN a.BKE742 = 1 THEN
                                           a.AKC264
                                          ELSE
                                           NULL
                                        END) / nullif(COUNT(CASE
                                                               WHEN a.BKE742 = 1 THEN
                                                                1
                                                               ELSE
                                                                NULL
                                                             END),
                                                       0)),
                                   0) AS bke799, --未入组权重
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS aaa131, -- 撤销标志
                 '' AS aae013, --  备注
                 prm_aaz706 AS aaz706, --  分组器信息id
                 nvl(a.BAC002, '9') AS BAC002 --人群类别
            FROM KHB7 a LEFT JOIN KEC7 c ON a.akc190 = c.akc190 and a.akb020 = c.akb020,
          --  LEFT JOIN KAA8 c
          --    ON a.bke716 = c.bke716,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') b
           WHERE 1 = 1
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    b.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    b.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    b.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    b.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY b.AAZ722, --医疗机构信息识别ID
                    b.BKE804, --统计级别
                    b.AAA027, --统筹区
                    b.AKA101, --医院等级
                    b.BAA001, --分中心
                    b.AAB301, --行政区划代码
                    b.AKB020, --医疗服务机构编码
                    b.AKB021, --医疗服务机构名称
                    b.BKF014, --科室分类编码
                    b.BKF033, --科室分类名称
                    b.AKF001, --科室编码
                    b.BKF001, --科室名称
                    b.BKF016, --医疗小组编码
                    b.BKF017, --医疗小组名称
                    b.AAF009, --医护人员职务
                    b.BKF006, --医护人员编码
                    b.AKE022, --医护人员名称
                --    A.AKE554, --病案首页类型
                    A.BAC002 --人群类别;
          UNION ALL
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 b.aaz722 AS aaz722, --医疗机构信息识别id
                 COUNT(1) AS bke708, --病案总数
                 COUNT(CASE
                         WHEN a.bke709 = 1 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke758, -- 有效病案数
                 COUNT(CASE
                         WHEN a.bke709 = 0 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke760, -- 排除病案数
                 COUNT(CASE
                         WHEN a.bke709 = 1 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke790, -- 分组病案数
                 COUNT(CASE
                         WHEN a.BKE742 = 1 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke791, -- 入组病案数
                 COUNT(DISTINCT(CASE
                                  WHEN a.BKE742 = 1 THEN
                                   a.bkeh39
                                  ELSE
                                   NULL
                                END)) AS bke762, -- 病种组数
                 COUNT(CASE
                         WHEN a.BKE742 = 1 THEN
                          1
                         ELSE
                          NULL
                       END) / nullif(COUNT(CASE
                                             WHEN a.bke709 = 1 THEN
                                              1
                                             ELSE
                                              NULL
                                           END),
                                     0) AS bkb276, --入组率
                 COUNT(CASE
                         WHEN a.BKE742 = 1 AND a.AKE039 > 0 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke792, --医保支付分析入组病案数
                 COUNT(CASE
                         WHEN a.BKE742 = 0 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke793, -- 未入组病案数
                 SUM(CASE
                       WHEN a.BKE742 = 0 THEN
                        a.AKC264
                       ELSE
                        NULL
                     END) / nullif((SUM(CASE
                                          WHEN a.BKE742 = 1 THEN
                                           a.AKC264
                                          ELSE
                                           NULL
                                        END) / nullif(COUNT(CASE
                                                               WHEN a.BKE742 = 1 THEN
                                                                1
                                                               ELSE
                                                                NULL
                                                             END),
                                                       0)),
                                   0) AS bke799, --未入组权重
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS aaa131, -- 撤销标志
                 '' AS aae013, --  备注
                 prm_aaz706 AS aaz706, --  分组器信息id
                 '0' AS BAC002 --人群类别
            FROM KHB7 a,
          --  LEFT JOIN KAA8 c
           --   ON a.bke716 = c.bke716,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') b
           WHERE 1 = 1
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    b.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    b.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    b.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    b.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY b.AAZ722, --医疗机构信息识别ID
                    b.BKE804, --统计级别
                    b.AAA027, --统筹区
                    b.AKA101, --医院等级
                    b.BAA001, --分中心
                    b.AAB301, --行政区划代码
                    b.AKB020, --医疗服务机构编码
                    b.AKB021, --医疗服务机构名称
                    b.BKF014, --科室分类编码
                    b.BKF033, --科室分类名称
                    b.AKF001, --科室编码
                    b.BKF001, --科室名称
                    b.BKF016, --医疗小组编码
                    b.BKF017, --医疗小组名称
                    b.AAF009, --医护人员职务
                    b.BKF006, --医护人员编码
                    b.AKE022 --医护人员名称
                  --  A.AKE554 --病案首页类型
          ;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO point_kej3;
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := '服务能力情况统计表【KEJ3】生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND aae001 = prm_aae001 --年度
       AND bke803 = prm_bke803 --报表类型
       AND bke805 = s_BKE805 --表名
   --    AND aaz706 = prm_aaz706 --分组器信息ID
       AND bke807 IS NULL; --制表标志
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '服务能力情况统计表【KEJ3】生成出错：' || SQLERRM;
  END prc_kej3;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEJ4(服务效率情况统计表)
  || 函数名称 : Prc_KEJ4
  || 功能描述 :生成服务效率情况统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kej4(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    s_BKE804  VARCHAR2(4); --统计级别
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
    /*游标声明*/
    --统计级别
    CURSOR cur_level IS
      SELECT BKE804
        FROM KEK5 --KEK5(统计报表开通信息表)
       WHERE BKE805 = s_BKE805
         AND NVL(BKE803, prm_bke803) = prm_bke803
         AND AAE030 <= n_sysdate
         AND (AAE031 >= n_sysdate OR AAE031 IS NULL)
         AND NVL(AAE100, '1') = '1'
       GROUP BY BKE804;
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEJ3;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    SAVEPOINT point_kej4;
    BEGIN
      FOR rec_KEJ2 IN cur_level LOOP
        INSERT INTO kej4
          (aae001, --  年度
           bke803, --  报表类型
           bke800, --  统计期号
           aae030, --  开始日期
           aae031, --  终止日期
           bke804, --  统计级别
           aaz722, --  医疗机构信息识别id
           bke723, --  平均住院日
           bke789, --  时间消耗指数
           bke722, --  例均费用
           bke788, --  费用消耗指数
           bke811, --  药品费用
           bke812, --  药品消耗指数
           bke813, --  耗材费用
           bke814, --  耗材消耗指数
           bke815, --  平均抗生素费用
           bke816, --  抗生素消耗指数
           bke801, --  制表人
           bke802, --  制表日期
           aae013, --  备注
           aaz706, --  分组器信息id
           bac002, --  人群类别
           aaa131 -- 撤销标志
           )
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 c.aaz722 AS aaz722, --医疗机构信息识别id
                 SUM(sum_d_bkc041) / SUM(drg_person) AS bke723, --平均住院天数
                 SUM(a.avg_m_bkc041 / DECODE(b.bke723, 0, NULL, b.bke723) *
                     drg_person) / SUM(drg_person) AS bke789, --时间消耗指数
                 SUM(sum_d_akc264) / SUM(drg_person) AS bke722, --例均费用
                 SUM(a.avg_m_akc264 / DECODE(b.bke722, 0, NULL, B.bke722) *
                     drg_person) / SUM(drg_person) AS bke788, --费用消耗指数
                 SUM(sum_d_durgCost) / SUM(drg_person) AS bke811, --药品费用
                 SUM(a.avg_m_durgCost / DECODE(b.bke811, 0, NULL, b.bke811) *
                     drg_person) / SUM(drg_person) AS bke812, --药品费用指数
                 SUM(sum_d_consumCost) / SUM(drg_person) AS bke813, --耗材费用
                 SUM(a.avg_m_consumCost /
                     DECODE(b.bke813, 0, NULL, b.bke813) * drg_person) /
                 SUM(drg_person) AS bke814, --耗材费用指数
                 SUM(sum_d_ake496) / SUM(drg_person) AS bke815, --抗生素费用
                 SUM(a.avg_m_ake496 / DECODE(b.bke815, 0, NULL, b.bke815) *
                     drg_person) / SUM(drg_person) AS bke816, --抗生素费用指数
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '' AS aae013, -- 备注
                 prm_aaz706 AS aaz706, -- 分组器信息id
                 nvl(a.BAC002, '9') AS BAC002, --人群类别
                 '0' AS AAA131 --撤销标志
            FROM (SELECT AAA027,
                         BAA001,
                         AAB301,
                         AKB020,
                         bke716,
                         BAC002,
                         COUNT(1) AS drg_person, --各组分数，
                         SUM(bkc041) AS sum_d_bkc041, --医院各组住院天数总和
                         SUM(akc264) AS sum_d_akc264, --医院各组总费用总和
                         SUM(durgCost) AS sum_d_durgCost, --医院各组药品费用总和
                         SUM(consumCost) AS sum_d_consumCost, --医院各组耗材费用总和
                         SUM(ake496) AS sum_d_ake496, --医院各组西医抗菌类药物总和
                         AVG(bkc041) AS avg_m_bkc041, --医院各组平均住院天数
                         AVG(akc264) AS avg_m_akc264, --医院各组平均住院总费用
                         AVG(durgCost) AS avg_m_durgCost, --医院各组平均药品费用
                         AVG(consumCost) AS avg_m_consumCost, --医院各组平均耗材费用
                         AVG(ake496) AS avg_m_ake496 --医院各组平均抗生素费用
                    FROM (SELECT aaa027,
                                 baa001,
                                 aab301,
                                 akc264,
                                 bkc041,
                                 akb020,
                                 bke716,
                                 bke742,
                                 bac002,
                                 (nvl(ake047, 0) + nvl(ake496, 0) +
                                 nvl(ake050, 0) + +nvl(ake551, 0) +
                                 nvl(ake049, 0)) AS durgCost,
                                 (nvl(ake501, 0) + nvl(ake502, 0) +
                                 nvl(ake503, 0)) AS consumCost,
                                 nvl(ake496, 0) AS ake496
                            FROM kem2)
                   WHERE bke742 = '1'
                   GROUP BY AAA027, BAA001, AAB301, AKB020, bke716, BAC002) a
            LEFT JOIN kaa8 b
              ON a.bke716 = b.bke716,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') c
           WHERE 1 = 1
                /* ---------------动态拼接级别关联条件-----------*/
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    c.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    c.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    c.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    c.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          /*---------------动态拼接级别关联条件-------------*/
           GROUP BY c.AAZ722, --医疗机构信息识别ID
                    c.BKE804, --统计级别
                    c.AAA027, --统筹区
                    c.AKA101, --医院等级
                    c.BAA001, --分中心
                    c.AAB301, --行政区划代码
                    c.AKB020, --医疗服务机构编码
                    c.AKB021, --医疗服务机构名称
                    c.BKF014, --科室分类编码
                    c.BKF033, --科室分类名称
                    c.AKF001, --科室编码
                    c.BKF001, --科室名称
                    c.BKF016, --医疗小组编码
                    c.BKF017, --医疗小组名称
                    c.AAF009, --医护人员职务
                    c.BKF006, --医护人员编码
                    c.AKE022, --医护人员名称
                    /* A.AKE554, --病案首页类型*/
                    A.BAC002 --人群类别
          UNION ALL
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 c.aaz722 AS aaz722, --医疗机构信息识别id
                 SUM(sum_d_bkc041) / SUM(drg_person) AS bke723, --平均住院天数
                 SUM(a.avg_m_bkc041 / DECODE(b.bke723, 0, NULL, b.bke723) *
                     drg_person) / SUM(drg_person) AS bke789, --时间消耗指数
                 SUM(sum_d_akc264) / SUM(drg_person) AS bke722, --例均费用
                 SUM(a.avg_m_akc264 / DECODE(b.bke722, 0, NULL, B.bke722) *
                     drg_person) / SUM(drg_person) AS bke788, --费用消耗指数
                 SUM(sum_d_durgCost) / SUM(drg_person) AS bke811, --药品费用
                 SUM(a.avg_m_durgCost / DECODE(b.bke811, 0, NULL, b.bke811) *
                     drg_person) / SUM(drg_person) AS bke812, --药品费用指数
                 SUM(sum_d_consumCost) / SUM(drg_person) AS bke813, --耗材费用
                 SUM(a.avg_m_consumCost /
                     DECODE(b.bke813, 0, NULL, b.bke813) * drg_person) /
                 SUM(drg_person) AS bke814, --耗材费用指数
                 SUM(sum_d_ake496) / SUM(drg_person) AS bke815, --抗生素费用
                 SUM(a.avg_m_ake496 / DECODE(b.bke815, 0, NULL, b.bke815) *
                     drg_person) / SUM(drg_person) AS bke816, --抗生素费用指数
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '' AS aae013, -- 备注
                 prm_aaz706 AS aaz706, -- 分组器信息id
                 '0' AS BAC002, --人群类别
                 '0' AS AAA131 --撤销标志
            FROM (SELECT AAA027,
                         BAA001,
                         AAB301,
                         AKB020,
                         bke716,
                         BAC002,
                         COUNT(1) AS drg_person, --各组分数，
                         SUM(bkc041) AS sum_d_bkc041, --医院各组住院天数总和
                         SUM(akc264) AS sum_d_akc264, --医院各组总费用总和
                         SUM(durgCost) AS sum_d_durgCost, --医院各组药品费用总和
                         SUM(consumCost) AS sum_d_consumCost, --医院各组耗材费用总和
                         SUM(ake496) AS sum_d_ake496, --医院各组西医抗菌类药物总和
                         AVG(bkc041) AS avg_m_bkc041, --医院各组平均住院天数
                         AVG(akc264) AS avg_m_akc264, --医院各组平均住院总费用
                         AVG(durgCost) AS avg_m_durgCost, --医院各组平均药品费用
                         AVG(consumCost) AS avg_m_consumCost, --医院各组平均耗材费用
                         AVG(ake496) AS avg_m_ake496 --医院各组平均抗生素费用
                    FROM (SELECT aaa027,
                                 baa001,
                                 aab301,
                                 akc264,
                                 bkc041,
                                 akb020,
                                 bke716,
                                 bke742,
                                 bac002,
                                 (nvl(ake047, 0) + nvl(ake496, 0) +
                                 nvl(ake050, 0) + +nvl(ake551, 0) +
                                 nvl(ake049, 0)) AS durgCost,
                                 (nvl(ake501, 0) + nvl(ake502, 0) +
                                 nvl(ake503, 0)) AS consumCost,
                                 nvl(ake496, 0) AS ake496
                            FROM kem2)
                   WHERE bke742 = '1'
                   GROUP BY AAA027, BAA001, AAB301, AKB020, bke716, BAC002) a
            LEFT JOIN kaa8 b
              ON a.bke716 = b.bke716,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') c
           WHERE 1 = 1
                /* ---------------动态拼接级别关联条件-----------*/
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    c.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    c.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    c.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    c.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          /*---------------动态拼接级别关联条件-------------*/
           GROUP BY c.AAZ722, --医疗机构信息识别ID
                    c.BKE804, --统计级别
                    c.AAA027, --统筹区
                    c.AKA101, --医院等级
                    c.BAA001, --分中心
                    c.AAB301, --行政区划代码
                    c.AKB020, --医疗服务机构编码
                    c.AKB021, --医疗服务机构名称
                    c.BKF014, --科室分类编码
                    c.BKF033, --科室分类名称
                    c.AKF001, --科室编码
                    c.BKF001, --科室名称
                    c.BKF016, --医疗小组编码
                    c.BKF017, --医疗小组名称
                    c.AAF009, --医护人员职务
                    c.BKF006, --医护人员编码
                    c.AKE022 --医护人员名称
          /* A.AKE554, --病案首页类型
          A.BAC002 --人群类别;*/
          ;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO point_kej4;
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := '服务效率情况统计表【KEJ4】生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND aae001 = prm_aae001 --年度
       AND bke803 = prm_bke803 --报表类型
       AND aaz706 = prm_aaz706; --分组器信息ID*
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '服务效率情况统计表【KEJ4】生成出错：' || SQLERRM;
  END prc_kej4;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEJ5(服务安全情况统计表)
  || 函数名称 : Prc_KEJ5
  || 功能描述 :生成服务安全情况统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kej5(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    s_BKE804  VARCHAR2(4); --统计级别
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
    /*游标声明*/
    --统计级别
    CURSOR cur_level IS
      SELECT BKE804
        FROM KEK5 --KEK5(统计报表开通信息表)
       WHERE BKE805 = s_BKE805
         AND NVL(BKE803, prm_bke803) = prm_bke803
         AND AAE030 <= n_sysdate
         AND (AAE031 >= n_sysdate OR AAE031 IS NULL)
         AND NVL(AAE100, '1') = '1'
       GROUP BY BKE804;
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEJ5;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    SAVEPOINT point_kej5;
    BEGIN
      FOR rec_KEJ2 IN cur_level LOOP
        INSERT INTO KEJ5
          (aae001, --  年度
           bke803, --  报表类型
           bke800, --  统计期号
           aae030, --  开始日期
           aae031, --  终止日期
           bke804, --  统计级别
           aaz722, --  医疗机构信息识别id
           bke817, --  平均死亡年龄
           bke818, --  死亡病案数
           bke728, --  死亡率
           bke819, --  低风险死亡数
           bke787, --  低风险死亡率
           bke820, --  中低风险死亡数
           bke821, --  中低风险死亡率
           bke822, --  中高风险死亡数
           bke823, --  中高风险死亡率
           bke824, --  高风险死亡数
           bke825, --  高风险死亡率
           bke801, --  制表人
           bke802, --  制表日期
           aaa131, --  撤销标志
           aae013, --  备注
           aaz706, --  分组器信息id
           bac002 --  人群类别
           )
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 b.aaz722 AS aaz722, --医疗机构信息识别id
                 round(SUM(CASE
                             WHEN a.ake471 = '5' THEN
                              a.akc023
                             ELSE
                              0
                           END) / nullif(COUNT(CASE
                                                 WHEN a.ake471 = '5' THEN
                                                  1
                                                 ELSE
                                                  NULL
                                               END),
                                         0),
                       4) AS bke817, --平均死亡年龄
                 COUNT(CASE
                         WHEN a.ake471 = '5' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke818, --死亡病案数
                 round(COUNT(CASE
                               WHEN a.ake471 = '5' THEN
                                1
                               ELSE
                                NULL
                             END) / nullif(COUNT(1), 0),
                       4) AS bke728, --死亡率
                 COUNT(CASE
                         WHEN a.ake471 = '5' AND c.bke725 = '1' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke819, --低风险死亡数
                 round(COUNT(CASE
                               WHEN a.ake471 = '5' AND c.bke725 = '1' THEN
                                1
                               ELSE
                                NULL
                             END) / nullif(COUNT(CASE
                                                   WHEN c.bke725 = '1' THEN
                                                    1
                                                   ELSE
                                                    NULL
                                                 END),
                                           0),
                       4) AS bke787, -- 低风险死亡率
                 COUNT(CASE
                         WHEN a.ake471 = '5' AND c.bke725 = '2' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke820, --中低风险死亡数
                 round(COUNT(CASE
                               WHEN a.ake471 = '5' AND c.bke725 = '2' THEN
                                1
                               ELSE
                                NULL
                             END) / nullif(COUNT(CASE
                                                   WHEN c.bke725 = '2' THEN
                                                    1
                                                   ELSE
                                                    NULL
                                                 END),
                                           0),
                       4) AS bke821, -- 中低风险死亡率
                 COUNT(CASE
                         WHEN a.ake471 = '5' AND c.bke725 = '3' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke822, --中高风险死亡数
                 round(COUNT(CASE
                               WHEN a.ake471 = '5' AND c.bke725 = '3' THEN
                                1
                               ELSE
                                NULL
                             END) / nullif(COUNT(CASE
                                                   WHEN c.bke725 = '3' THEN
                                                    1
                                                   ELSE
                                                    NULL
                                                 END),
                                           0),
                       4) AS bke823, -- 中高风险死亡率
                 COUNT(CASE
                         WHEN a.ake471 = '5' AND c.bke725 = '4' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke824, --高风险死亡数
                 round(COUNT(CASE
                               WHEN a.ake471 = '5' AND c.bke725 = '4' THEN
                                1
                               ELSE
                                NULL
                             END) / nullif(COUNT(CASE
                                                   WHEN c.bke725 = '4' THEN
                                                    1
                                                   ELSE
                                                    NULL
                                                 END),
                                           0),
                       4) AS bke825, -- 高风险死亡率
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS aaa131, --  撤销标志
                 '' AS aae013, --  备注
                 prm_aaz706 AS aaz706, --  分组器信息id
                 nvl(a.BAC002, '9') AS BAC002 --人群类别
            FROM KEM2 a
            LEFT JOIN KAA8 c
              ON a.bke716 = c.bke716,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') b
           WHERE a.bke742 = 1 --入组病案
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    b.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    b.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    b.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    b.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY b.AAZ722, --医疗机构信息识别ID
                    b.BKE804, --统计级别
                    b.AAA027, --统筹区
                    b.AKA101, --医院等级
                    b.BAA001, --分中心
                    b.AAB301, --行政区划代码
                    b.AKB020, --医疗服务机构编码
                    b.AKB021, --医疗服务机构名称
                    b.BKF014, --科室分类编码
                    b.BKF033, --科室分类名称
                    b.AKF001, --科室编码
                    b.BKF001, --科室名称
                    b.BKF016, --医疗小组编码
                    b.BKF017, --医疗小组名称
                    b.AAF009, --医护人员职务
                    b.BKF006, --医护人员编码
                    b.AKE022, --医护人员名称
                    A.AKE554, --病案首页类型
                    A.BAC002 --人群类别;
          UNION ALL
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 b.aaz722 AS aaz722, --医疗机构信息识别id
                 round(SUM(CASE
                             WHEN a.ake471 = '5' THEN
                              a.akc023
                             ELSE
                              0
                           END) / nullif(COUNT(CASE
                                                 WHEN a.ake471 = '5' THEN
                                                  1
                                                 ELSE
                                                  NULL
                                               END),
                                         0),
                       4) AS bke817, --平均死亡年龄
                 COUNT(CASE
                         WHEN a.ake471 = '5' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke818, --死亡病案数
                 round(COUNT(CASE
                               WHEN a.ake471 = '5' THEN
                                1
                               ELSE
                                NULL
                             END) / nullif(COUNT(1), 0),
                       4) AS bke728, --死亡率
                 COUNT(CASE
                         WHEN a.ake471 = '5' AND c.bke725 = '1' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke819, --低风险死亡数
                 round(COUNT(CASE
                               WHEN a.ake471 = '5' AND c.bke725 = '1' THEN
                                1
                               ELSE
                                NULL
                             END) / nullif(COUNT(CASE
                                                   WHEN c.bke725 = '1' THEN
                                                    1
                                                   ELSE
                                                    NULL
                                                 END),
                                           0),
                       4) AS bke787, -- 低风险死亡率
                 COUNT(CASE
                         WHEN a.ake471 = '5' AND c.bke725 = '2' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke820, --中低风险死亡数
                 round(COUNT(CASE
                               WHEN a.ake471 = '5' AND c.bke725 = '2' THEN
                                1
                               ELSE
                                NULL
                             END) / nullif(COUNT(CASE
                                                   WHEN c.bke725 = '2' THEN
                                                    1
                                                   ELSE
                                                    NULL
                                                 END),
                                           0),
                       4) AS bke821, -- 中低风险死亡率
                 COUNT(CASE
                         WHEN a.ake471 = '5' AND c.bke725 = '3' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke822, --中高风险死亡数
                 round(COUNT(CASE
                               WHEN a.ake471 = '5' AND c.bke725 = '3' THEN
                                1
                               ELSE
                                NULL
                             END) / nullif(COUNT(CASE
                                                   WHEN c.bke725 = '3' THEN
                                                    1
                                                   ELSE
                                                    NULL
                                                 END),
                                           0),
                       4) AS bke823, -- 中高风险死亡率
                 COUNT(CASE
                         WHEN a.ake471 = '5' AND c.bke725 = '4' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke824, --高风险死亡数
                 round(COUNT(CASE
                               WHEN a.ake471 = '5' AND c.bke725 = '4' THEN
                                1
                               ELSE
                                NULL
                             END) / nullif(COUNT(CASE
                                                   WHEN c.bke725 = '4' THEN
                                                    1
                                                   ELSE
                                                    NULL
                                                 END),
                                           0),
                       4) AS bke825, -- 高风险死亡率
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS aaa131, --  撤销标志
                 '' AS aae013, --  备注
                 prm_aaz706 AS aaz706, --  分组器信息id
                 '0' AS BAC002 --人群类别
            FROM KEM2 a
            LEFT JOIN KAA8 c
              ON a.bke716 = c.bke716,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') b
           WHERE a.bke742 = 1 --入组病案
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    b.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    b.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    b.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    b.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY b.AAZ722, --医疗机构信息识别ID
                    b.BKE804, --统计级别
                    b.AAA027, --统筹区
                    b.AKA101, --医院等级
                    b.BAA001, --分中心
                    b.AAB301, --行政区划代码
                    b.AKB020, --医疗服务机构编码
                    b.AKB021, --医疗服务机构名称
                    b.BKF014, --科室分类编码
                    b.BKF033, --科室分类名称
                    b.AKF001, --科室编码
                    b.BKF001, --科室名称
                    b.BKF016, --医疗小组编码
                    b.BKF017, --医疗小组名称
                    b.AAF009, --医护人员职务
                    b.BKF006, --医护人员编码
                    b.AKE022, --医护人员名称
                    A.AKE554 --病案首页类型
          ;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO point_kej5;
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := '服务安全情况统计表【KEJ5】生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND aae001 = prm_aae001 --年度
       AND bke803 = prm_bke803 --报表类型
       AND bke805 = s_BKE805 --表名
       AND aaz706 = prm_aaz706 --分组器信息ID
       AND bke807 IS NULL; --制表标志
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '服务安全情况统计表【KEJ5】生成出错：' || SQLERRM;
  END prc_kej5;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEJ6(费用占比情况统计表)
  || 函数名称 : Prc_KEJ6
  || 功能描述 :生成费用占比情况统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kej6(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
  BEGIN
    /* 变量初始化 */
    prm_appcode  := pkg_comm.def_ok;
    prm_errormsg := NULL;
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '费用占比情况统计信息【KEJ6】生成出错：' || SQLERRM;
  END prc_kej6;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEJ7(MDC情况统计表)
  || 函数名称 : Prc_KEJ7
  || 功能描述 :生成MDC情况统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kej7(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    s_BKE804  VARCHAR2(4); --统计级别
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
    /*游标声明*/
    --统计级别
    CURSOR cur_level IS
      SELECT BKE804
        FROM KEK5 --KEK5(统计报表开通信息表)
       WHERE BKE805 = s_BKE805
         AND NVL(BKE803, prm_bke803) = prm_bke803
         AND AAE030 <= n_sysdate
         AND (AAE031 >= n_sysdate OR AAE031 IS NULL)
         AND NVL(AAE100, '1') = '1'
       GROUP BY BKE804;
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEJ7;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    SAVEPOINT point_kej7;
    BEGIN
      FOR rec_KEJ2 IN cur_level LOOP
        INSERT INTO kej7
          (AAE001, --  年度
           BKE803, --  报表类型
           BKE800, --  统计期号
           AAE030, --  开始日期
           AAE031, --  终止日期
           BKE804, --  统计级别
           AAZ722, --  医疗机构信息识别ID
           BKE718, --  MDC编码
           BKE719, --  MDC名称
           BKE766, --  DRG组病案数
           BKE762, --  DRG组数
           BKE795, --  CMI
           BKE779, --  总权重
           BKE796, --  内科总权重
           BKE797, --  外科总权重
           BKE798, --  非手术室操作权重
           BKE723, --  平均住院日
           BKE789, --  时间消耗指数
           BKE722, --  例均费用
           BKE788, --  费用消耗指数
           BKE729, --  平均年龄
           BKE818, --  死亡数
           BKE728, --  死亡率
           BKE817, --  平均死亡年龄
           BKE862, --  服务能力指数
           BKE801, --  制表人
           BKE802, --  制表日期
           AAA131, --  撤销标志
           AAE013, --  备注
           AAZ706, --  分组器信息ID
           BAC002 -- 人群类别
           )
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 c.aaz722 AS aaz722, --医疗机构信息识别id
                 a.bke718 AS bke718, --MDC编码
                 a.bke719 AS bke719, --MDC名称
                 SUM(a.drg_person) AS BKE766, --DRG组病案数
                 COUNT(a.bke716) AS BKE762, --DRG组数
                 SUM(b.BKE724 * a.drg_person) / SUM(a.drg_person) AS BKE795, --CMI
                 SUM(b.BKE724 * a.drg_person) AS BKE779, --总权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN
                            ('R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        0
                     END) AS BKE796, -- 内科总权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN
                            ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        NULL
                     END) AS bke797, --外科权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN ('K', 'L', 'M', 'N', 'P', 'Q') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        NULL
                     END) AS bke798, --非手术室操作权重
                 SUM(a.sum_d_bkc041) / SUM(a.drg_person) AS BKE723, --平均住院日
                 SUM(a.avg_m_bkc041 / DECODE(b.bke723, 0, NULL, b.bke723) *
                     drg_person) / SUM(drg_person) AS bke789, --时间消耗指数
                 SUM(a.sum_d_akc264) / SUM(a.drg_person) AS BKE722, --例均费用
                 SUM(a.avg_m_akc264 / DECODE(b.bke722, 0, NULL, B.bke722) *
                     drg_person) / SUM(drg_person) AS bke788, --费用消耗指数
                 SUM(a.sum_d_akc023) / SUM(a.drg_person) AS BKE729, --平均年龄
                 SUM(drg_die_person) AS BKE818, --死亡数
                 round(SUM(drg_die_person) / SUM(a.drg_person), 4) AS BKE728, --死亡率
                 round(SUM(sum_die_akc023) / SUM(a.drg_person), 4) AS BKE817, --平均死亡年龄
                 '' AS BKE862, --  服务能力指数
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS AAA131, --撤销标志
                 '' AS aae013, --  备注
                 prm_aaz706 AS aaz706, --  分组器信息id
                 nvl(a.BAC002, '9') AS BAC002 --人群类别
            FROM (SELECT AAA027, -- 统筹区编码
                         BAA001, -- 分中心编码
                         AAB301, -- 区县
                         AKB020, -- 医疗机构
                         BKE718, -- MDC编码
                         BKE719, -- MDC名称
                         bke716, -- drg编码
                         BAC002, -- 人群类别
                         COUNT(1) AS drg_person, --各组人数
                         COUNT(1) AS drg_die_person, --各组死亡人数
                         SUM(AKC023) AS sum_d_akc023, --各组总年龄
                         SUM(CASE
                               WHEN AKE471 = '5' THEN
                                AKC023
                               ELSE
                                0
                             END) AS sum_die_akc023, --各组死亡总年龄
                         SUM(bkc041) AS sum_d_bkc041, --医院各组住院天数总和
                         SUM(akc264) AS sum_d_akc264, --医院各组总费用总和
                         AVG(bkc041) AS avg_m_bkc041, --医院各组平均住院天数
                         AVG(akc264) AS avg_m_akc264 --医院各组平均住院总费用
                    FROM kem2
                   WHERE bke742 = '1'
                   GROUP BY BKE718,
                            BKE719,
                            AAA027,
                            BAA001,
                            AAB301,
                            AKB020,
                            bke716,
                            BAC002) a
            LEFT JOIN kaa8 b
              ON a.bke716 = b.bke716,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') c
           WHERE 1 = 1
                /* ---------------动态拼接级别关联条件-----------*/
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    c.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    c.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    c.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    c.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          /*---------------动态拼接级别关联条件-------------*/
           GROUP BY a.BKE718, --MDC编码
                    a.BKE719, --MDC名称
                    c.AAZ722, --医疗机构信息识别ID
                    c.BKE804, --统计级别
                    c.AAA027, --统筹区
                    c.AKA101, --医院等级
                    c.BAA001, --分中心
                    c.AAB301, --行政区划代码
                    c.AKB020, --医疗服务机构编码
                    c.AKB021, --医疗服务机构名称
                    c.BKF014, --科室分类编码
                    c.BKF033, --科室分类名称
                    c.AKF001, --科室编码
                    c.BKF001, --科室名称
                    c.BKF016, --医疗小组编码
                    c.BKF017, --医疗小组名称
                    c.AAF009, --医护人员职务
                    c.BKF006, --医护人员编码
                    c.AKE022, --医护人员名称
                    /* A.AKE554, --病案首页类型*/
                    A.BAC002 --人群类别;
          UNION ALL
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 c.aaz722 AS aaz722, --医疗机构信息识别id
                 a.bke718 AS bke718, --MDC编码
                 a.bke719 AS bke719, --MDC名称
                 SUM(a.drg_person) AS BKE766, --DRG组病案数
                 COUNT(a.bke716) AS BKE762, --DRG组数
                 SUM(b.BKE724 * a.drg_person) / SUM(a.drg_person) AS BKE795, --CMI
                 SUM(b.BKE724 * a.drg_person) AS BKE779, --总权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN
                            ('R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        0
                     END) AS BKE796, -- 内科总权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN
                            ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        NULL
                     END) AS bke797, --外科权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN ('K', 'L', 'M', 'N', 'P', 'Q') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        NULL
                     END) AS bke798, --非手术室操作权重
                 SUM(a.sum_d_bkc041) / SUM(a.drg_person) AS BKE723, --平均住院日
                 SUM(a.avg_m_bkc041 / DECODE(b.bke723, 0, NULL, b.bke723) *
                     drg_person) / SUM(drg_person) AS bke789, --时间消耗指数
                 SUM(a.sum_d_akc264) / SUM(a.drg_person) AS BKE722, --例均费用
                 SUM(a.avg_m_akc264 / DECODE(b.bke722, 0, NULL, B.bke722) *
                     drg_person) / SUM(drg_person) AS bke788, --费用消耗指数
                 SUM(a.sum_d_akc023) / SUM(a.drg_person) AS BKE729, --平均年龄
                 SUM(drg_die_person) AS BKE818, --死亡数
                 round(SUM(drg_die_person) / SUM(a.drg_person), 4) AS BKE728, --死亡率
                 round(SUM(sum_die_akc023) / SUM(a.drg_person), 4) AS BKE817, --平均死亡年龄
                 '' AS BKE862, --  服务能力指数
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS AAA131, --撤销标志
                 '' AS aae013, --  备注
                 prm_aaz706 AS aaz706, --  分组器信息id
                 '0' AS BAC002 --人群类别
            FROM (SELECT AAA027, -- 统筹区编码
                         BAA001, -- 分中心编码
                         AAB301, -- 区县
                         AKB020, -- 医疗机构
                         BKE718, -- MDC编码
                         BKE719, -- MDC名称
                         bke716, -- drg编码
                         BAC002, -- 人群类别
                         COUNT(1) AS drg_person, --各组人数
                         COUNT(1) AS drg_die_person, --各组死亡人数
                         SUM(AKC023) AS sum_d_akc023, --各组总年龄
                         SUM(CASE
                               WHEN AKE471 = '5' THEN
                                AKC023
                               ELSE
                                0
                             END) AS sum_die_akc023, --各组死亡总年龄
                         SUM(bkc041) AS sum_d_bkc041, --医院各组住院天数总和
                         SUM(akc264) AS sum_d_akc264, --医院各组总费用总和
                         AVG(bkc041) AS avg_m_bkc041, --医院各组平均住院天数
                         AVG(akc264) AS avg_m_akc264 --医院各组平均住院总费用
                    FROM kem2
                   WHERE bke742 = '1'
                   GROUP BY BKE718,
                            BKE719,
                            AAA027,
                            BAA001,
                            AAB301,
                            AKB020,
                            bke716,
                            BAC002) a
            LEFT JOIN kaa8 b
              ON a.bke716 = b.bke716,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') c
           WHERE 1 = 1
                /* ---------------动态拼接级别关联条件-----------*/
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    c.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    c.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    c.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    c.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          /*---------------动态拼接级别关联条件-------------*/
           GROUP BY a.BKE718, --MDC编码
                    a.BKE719, --MDC名称
                    c.AAZ722, --医疗机构信息识别ID
                    c.BKE804, --统计级别
                    c.AAA027, --统筹区
                    c.AKA101, --医院等级
                    c.BAA001, --分中心
                    c.AAB301, --行政区划代码
                    c.AKB020, --医疗服务机构编码
                    c.AKB021, --医疗服务机构名称
                    c.BKF014, --科室分类编码
                    c.BKF033, --科室分类名称
                    c.AKF001, --科室编码
                    c.BKF001, --科室名称
                    c.BKF016, --医疗小组编码
                    c.BKF017, --医疗小组名称
                    c.AAF009, --医护人员职务
                    c.BKF006, --医护人员编码
                    c.AKE022 --医护人员名称
          /* A.AKE554, --病案首页类型*/
          ;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO point_kej7;
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := 'MDC情况统计表【KEJ7】生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND aae001 = prm_aae001 --年度
       AND bke803 = prm_bke803 --报表类型
       AND bke805 = s_BKE805 --表名
       AND aaz706 = prm_aaz706 --分组器信息ID
       AND bke807 IS NULL; --制表标志
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := 'MDC情况统计表【KEJ7】生成出错：' || SQLERRM;
  END prc_kej7;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEJ8(ADRGs情况统计表)
  || 函数名称 : Prc_KEJ8
  || 功能描述 :生成ADRGs情况统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kej8(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    s_BKE804  VARCHAR2(4); --统计级别
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
    /*游标声明*/
    --统计级别
    CURSOR cur_level IS
      SELECT BKE804
        FROM KEK5 --KEK5(统计报表开通信息表)
       WHERE BKE805 = s_BKE805
         AND NVL(BKE803, prm_bke803) = prm_bke803
         AND AAE030 <= n_sysdate
         AND (AAE031 >= n_sysdate OR AAE031 IS NULL)
         AND NVL(AAE100, '1') = '1'
       GROUP BY BKE804;
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEJ8;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    SAVEPOINT point_kej8;
    BEGIN
      FOR rec_KEJ2 IN cur_level LOOP
        INSERT INTO kej8
          (AAE001, --  年度
           BKE803, --  报表类型
           BKE800, --  统计期号
           AAE030, --  开始日期
           AAE031, --  终止日期
           BKE804, --  统计级别
           AAZ722, --  医疗机构信息识别ID
           BKE720, --  ADRG编码
           BKE721, --  ADRG名称
           BKE766, --  DRG组病案数
           BKE762, --  DRG组数
           BKE795, --  CMI
           BKE779, --  总权重
           BKE796, --  内科总权重
           BKE797, --  外科总权重
           BKE798, --  非手术室操作权重
           BKE723, --  平均住院日
           BKE789, --  时间消耗指数
           BKE722, --  例均费用
           BKE788, --  费用消耗指数
           BKE729, --  平均年龄
           BKE818, --  死亡数
           BKE728, --  死亡率
           BKE817, --  平均死亡年龄
           BKE862, --  服务能力指数
           BKE801, --  制表人
           BKE802, --  制表日期
           AAA131, --  撤销标志
           AAE013, --  备注
           AAZ706, --  分组器信息ID
           BAC002 -- 人群类别
           )
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 c.aaz722 AS aaz722, --医疗机构信息识别id
                 a.bke720 AS bke720, --ADRG编码
                 a.bke721 AS bke721, --ADRG名称
                 SUM(a.drg_person) AS BKE766, --DRG组病案数
                 COUNT(a.bke716) AS BKE762, --DRG组数
                 SUM(b.BKE724 * a.drg_person) / SUM(a.drg_person) AS BKE795, --CMI
                 SUM(b.BKE724 * a.drg_person) AS BKE779, --总权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN
                            ('R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        0
                     END) AS BKE796, -- 内科总权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN
                            ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        NULL
                     END) AS bke797, --外科权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN ('K', 'L', 'M', 'N', 'P', 'Q') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        NULL
                     END) AS bke798, --非手术室操作权重
                 SUM(a.sum_d_bkc041) / SUM(a.drg_person) AS BKE723, --平均住院日
                 SUM(a.avg_m_bkc041 / DECODE(b.bke723, 0, NULL, b.bke723) *
                     drg_person) / SUM(drg_person) AS bke789, --时间消耗指数
                 SUM(a.sum_d_akc264) / SUM(a.drg_person) AS BKE722, --例均费用
                 SUM(a.avg_m_akc264 / DECODE(b.bke722, 0, NULL, B.bke722) *
                     drg_person) / SUM(drg_person) AS bke788, --费用消耗指数
                 SUM(a.sum_d_akc023) / SUM(a.drg_person) AS BKE729, --平均年龄
                 SUM(drg_die_person) AS BKE818, --死亡数
                 round(SUM(drg_die_person) / SUM(a.drg_person), 4) AS BKE728, --死亡率
                 round(SUM(sum_die_akc023) / SUM(a.drg_person), 4) AS BKE817, --平均死亡年龄
                 '' AS BKE862, --  服务能力指数
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS AAA131, --撤销标志
                 '' AS aae013, --  备注
                 prm_aaz706 AS aaz706, --  分组器信息id
                 nvl(a.BAC002, '9') AS BAC002 --人群类别
            FROM (SELECT AAA027, -- 统筹区编码
                         BAA001, -- 分中心编码
                         AAB301, -- 区县
                         AKB020, -- 医疗机构
                         BKE720, -- ADRG编码
                         BKE721, -- ADRG名称
                         bke716, -- drg编码
                         BAC002, -- 人群类别
                         COUNT(1) AS drg_person, --各组人数
                         COUNT(1) AS drg_die_person, --各组死亡人数
                         SUM(AKC023) AS sum_d_akc023, --各组总年龄
                         SUM(CASE
                               WHEN AKE471 = '5' THEN
                                AKC023
                               ELSE
                                0
                             END) AS sum_die_akc023, --各组死亡总年龄
                         SUM(bkc041) AS sum_d_bkc041, --医院各组住院天数总和
                         SUM(akc264) AS sum_d_akc264, --医院各组总费用总和
                         AVG(bkc041) AS avg_m_bkc041, --医院各组平均住院天数
                         AVG(akc264) AS avg_m_akc264 --医院各组平均住院总费用
                    FROM kem2
                   WHERE bke742 = '1'
                   GROUP BY BKE720,
                            BKE721,
                            AAA027,
                            BAA001,
                            AAB301,
                            AKB020,
                            bke716,
                            BAC002) a
            LEFT JOIN kaa8 b
              ON a.bke716 = b.bke716,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') c
           WHERE 1 = 1
                /* ---------------动态拼接级别关联条件-----------*/
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    c.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    c.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    c.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    c.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          /*---------------动态拼接级别关联条件-------------*/
           GROUP BY a.BKE720, --ADRG编码
                    a.BKE721, --ADRG名称
                    c.AAZ722, --医疗机构信息识别ID
                    c.BKE804, --统计级别
                    c.AAA027, --统筹区
                    c.AKA101, --医院等级
                    c.BAA001, --分中心
                    c.AAB301, --行政区划代码
                    c.AKB020, --医疗服务机构编码
                    c.AKB021, --医疗服务机构名称
                    c.BKF014, --科室分类编码
                    c.BKF033, --科室分类名称
                    c.AKF001, --科室编码
                    c.BKF001, --科室名称
                    c.BKF016, --医疗小组编码
                    c.BKF017, --医疗小组名称
                    c.AAF009, --医护人员职务
                    c.BKF006, --医护人员编码
                    c.AKE022, --医护人员名称
                    /* A.AKE554, --病案首页类型*/
                    A.BAC002 --人群类别;
          UNION ALL
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 c.aaz722 AS aaz722, --医疗机构信息识别id
                 a.bke720 AS bke720, --ADRG编码
                 a.bke721 AS bke721, --ADRG名称
                 SUM(a.drg_person) AS BKE766, --DRG组病案数
                 COUNT(a.bke716) AS BKE762, --DRG组数
                 SUM(b.BKE724 * a.drg_person) / SUM(a.drg_person) AS BKE795, --CMI
                 SUM(b.BKE724 * a.drg_person) AS BKE779, --总权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN
                            ('R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        0
                     END) AS BKE796, -- 内科总权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN
                            ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        NULL
                     END) AS bke797, --外科权重
                 SUM(CASE
                       WHEN substr(a.bke716, 2, 1) IN ('K', 'L', 'M', 'N', 'P', 'Q') THEN
                        b.BKE724 * a.drg_person
                       ELSE
                        NULL
                     END) AS bke798, --非手术室操作权重
                 SUM(a.sum_d_bkc041) / SUM(a.drg_person) AS BKE723, --平均住院日
                 SUM(a.avg_m_bkc041 / DECODE(b.bke723, 0, NULL, b.bke723) *
                     drg_person) / SUM(drg_person) AS bke789, --时间消耗指数
                 SUM(a.sum_d_akc264) / SUM(a.drg_person) AS BKE722, --例均费用
                 SUM(a.avg_m_akc264 / DECODE(b.bke722, 0, NULL, B.bke722) *
                     drg_person) / SUM(drg_person) AS bke788, --费用消耗指数
                 SUM(a.sum_d_akc023) / SUM(a.drg_person) AS BKE729, --平均年龄
                 SUM(drg_die_person) AS BKE818, --死亡数
                 round(SUM(drg_die_person) / SUM(a.drg_person), 4) AS BKE728, --死亡率
                 round(SUM(sum_die_akc023) / SUM(a.drg_person), 4) AS BKE817, --平均死亡年龄
                 '' AS BKE862, --  服务能力指数
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS AAA131, --撤销标志
                 '' AS aae013, --  备注
                 prm_aaz706 AS aaz706, --  分组器信息id
                 '0' AS BAC002 --人群类别
            FROM (SELECT AAA027, -- 统筹区编码
                         BAA001, -- 分中心编码
                         AAB301, -- 区县
                         AKB020, -- 医疗机构
                         BKE720, -- ADRG编码
                         BKE721, -- ADRG名称
                         bke716, -- drg编码
                         BAC002, -- 人群类别
                         COUNT(1) AS drg_person, --各组人数
                         COUNT(1) AS drg_die_person, --各组死亡人数
                         SUM(AKC023) AS sum_d_akc023, --各组总年龄
                         SUM(CASE
                               WHEN AKE471 = '5' THEN
                                AKC023
                               ELSE
                                0
                             END) AS sum_die_akc023, --各组死亡总年龄
                         SUM(bkc041) AS sum_d_bkc041, --医院各组住院天数总和
                         SUM(akc264) AS sum_d_akc264, --医院各组总费用总和
                         AVG(bkc041) AS avg_m_bkc041, --医院各组平均住院天数
                         AVG(akc264) AS avg_m_akc264 --医院各组平均住院总费用
                    FROM kem2
                   WHERE bke742 = '1'
                   GROUP BY BKE720,
                            BKE721,
                            AAA027,
                            BAA001,
                            AAB301,
                            AKB020,
                            bke716,
                            BAC002) a
            LEFT JOIN kaa8 b
              ON a.bke716 = b.bke716,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') c
           WHERE 1 = 1
                /* ---------------动态拼接级别关联条件-----------*/
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    c.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    c.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    c.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    c.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          /*---------------动态拼接级别关联条件-------------*/
           GROUP BY a.BKE720, --ADRG编码
                    a.BKE721, --ADRG名称
                    c.AAZ722, --医疗机构信息识别ID
                    c.BKE804, --统计级别
                    c.AAA027, --统筹区
                    c.AKA101, --医院等级
                    c.BAA001, --分中心
                    c.AAB301, --行政区划代码
                    c.AKB020, --医疗服务机构编码
                    c.AKB021, --医疗服务机构名称
                    c.BKF014, --科室分类编码
                    c.BKF033, --科室分类名称
                    c.AKF001, --科室编码
                    c.BKF001, --科室名称
                    c.BKF016, --医疗小组编码
                    c.BKF017, --医疗小组名称
                    c.AAF009, --医护人员职务
                    c.BKF006, --医护人员编码
                    c.AKE022 --医护人员名称
          /* A.AKE554, --病案首页类型*/
          ;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO point_kej8;
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := 'DRGs情况统计表【KEJ8】生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND aae001 = prm_aae001 --年度
       AND bke803 = prm_bke803 --报表类型
       AND bke805 = s_BKE805 --表名
       AND aaz706 = prm_aaz706 --分组器信息ID
       AND bke807 IS NULL; --制表标志
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := 'ADRGs情况统计表【KEJ8】生成出错：' || SQLERRM;
  END prc_kej8;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEJ9(DRGs情况统计表)
  || 函数名称 : Prc_KEJ9
  || 功能描述 :生成DRGs情况统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kej9(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    s_BKE804  VARCHAR2(4); --统计级别
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
    /*游标声明*/
    --统计级别
    CURSOR cur_level IS
      SELECT BKE804
        FROM KEK5 --KEK5(统计报表开通信息表)
       WHERE BKE805 = s_BKE805
         AND NVL(BKE803, prm_bke803) = prm_bke803
         AND AAE030 <= n_sysdate
         AND (AAE031 >= n_sysdate OR AAE031 IS NULL)
         AND NVL(AAE100, '1') = '1'
       GROUP BY BKE804;
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEJ9;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    SAVEPOINT point_kej9;
    BEGIN
      FOR rec_KEJ2 IN cur_level LOOP
        INSERT INTO kej9
          (bke716, --  drg编码
           bke717, --  drg名称
           bke779, --  权重
           bke766, --  drg组病案数
           bke725, --  风险级别
           aae001, --  年度
           bke803, --  报表类型
           bke800, --  统计期号
           aae030, --  开始日期
           aae031, --  终止日期
           bke804, --  统计级别
           aaz722, --  医疗机构信息识别id
           bke723, --  平均住院日
           bke729, --  平均年龄
           bke728, --  死亡率
           bke722, --  例均费用
           bke801, --  制表人
           bke802, --  制表日期
           bke818, --  死亡数
           bke817, --  平均死亡年龄
           aaa131, --  撤销标志
           aaz706, --  分组器信息id
           aae013, --  备注
           bac002 -- 人群类别
           )
          SELECT a.bke716 AS bke716, -- drg编码
                 a.bke717 AS bke717, -- drg名称
                 c.bke724 AS bke724, -- drg权重
                 COUNT(1) AS bke766, -- drg组病案数
                 c.bke725 AS bke725, -- 风险级别
                 prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 b.aaz722 AS aaz722, --医疗机构信息识别id
                 AVG(a.bkc041) AS bke723, -- 平均住院日
                 AVG(a.akc023) AS bke729, -- 平均年龄
                 COUNT(CASE
                         WHEN a.ake471 = '5' THEN
                          1
                         ELSE
                          NULL
                       END) / COUNT(1) AS bke728, --死亡率
                 AVG(akc264) AS bke722, --例均费用
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 COUNT(CASE
                         WHEN a.ake471 = '5' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke818, --死亡数
                 SUM(CASE
                       WHEN a.ake471 = '5' THEN
                        a.akc023
                       ELSE
                        0
                     END) / COUNT(CASE
                                    WHEN a.ake471 = '5' THEN
                                     1
                                    ELSE
                                     0
                                  END) AS bke817, --平均死亡年龄
                 '0' AS aaa131, -- 撤销标志
                 prm_aaz706 AS aaz706, -- 分组器信息id
                 '' AS aae013, --  备注
                 nvl(a.BAC002, '9') AS BAC002 --人群类别
            FROM kem2 a
            LEFT JOIN kaa8 c
              ON a.bke716 = c.bke716,
          -- group by a.bke716,a.bke717,c.bke724,c.bke725,a.AAA027,a.BAA001,a.AAB301,a.AKB020,a.BAC002 ,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') b
           WHERE a.bke742 = 1 --入组病案
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    b.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    b.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    b.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    b.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY a.bke716, --drg编码
                    a.bke717, --drg名称
                    c.bke724, --drg权重
                    c.bke725, --风险等级
                    b.AAZ722, --医疗机构信息识别ID
                    b.BKE804, --统计级别
                    b.AAA027, --统筹区
                    b.AKA101, --医院等级
                    b.BAA001, --分中心
                    b.AAB301, --行政区划代码
                    b.AKB020, --医疗服务机构编码
                    b.AKB021, --医疗服务机构名称
                    b.BKF014, --科室分类编码
                    b.BKF033, --科室分类名称
                    b.AKF001, --科室编码
                    b.BKF001, --科室名称
                    b.BKF016, --医疗小组编码
                    b.BKF017, --医疗小组名称
                    b.AAF009, --医护人员职务
                    b.BKF006, --医护人员编码
                    b.AKE022, --医护人员名称
                    A.AKE554, --病案首页类型
                    A.BAC002 --人群类别;
          UNION ALL
          SELECT a.bke716 AS bke716, -- drg编码
                 a.bke717 AS bke717, -- drg名称
                 c.bke724 AS bke724, -- drg权重
                 COUNT(1) AS bke766, -- drg组病案数
                 c.bke725 AS bke725, -- 风险级别
                 prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 b.aaz722 AS aaz722, --医疗机构信息识别id
                 AVG(a.bkc041) AS bke723, -- 平均住院日
                 AVG(a.akc023) AS bke729, -- 平均年龄
                 COUNT(CASE
                         WHEN a.ake471 = '5' THEN
                          1
                         ELSE
                          NULL
                       END) / COUNT(1) AS bke728, --死亡率
                 AVG(akc264) AS bke722, --例均费用
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 COUNT(CASE
                         WHEN a.ake471 = '5' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke818, --死亡数
                 SUM(CASE
                       WHEN a.ake471 = '5' THEN
                        a.akc023
                       ELSE
                        0
                     END) / COUNT(CASE
                                    WHEN a.ake471 = '5' THEN
                                     1
                                    ELSE
                                     0
                                  END) AS bke817, --平均死亡年龄
                 '0' AS aaa131, -- 撤销标志
                 prm_aaz706 AS aaz706, -- 分组器信息id
                 '' AS aae013, --  备注
                 '0' AS BAC002 --人群类别
            FROM kem2 a
            LEFT JOIN kaa8 c
              ON a.bke716 = c.bke716,
          -- group by a.bke716,a.bke717,c.bke724,c.bke725,a.AAA027,a.BAA001,a.AAB301,a.AKB020,a.BAC002 ,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') b
           WHERE a.bke742 = 1 --入组病案
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    b.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    b.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    b.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    b.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY a.bke716, --drg编码
                    a.bke717, --drg名称
                    c.bke724, --drg权重
                    c.bke725, --风险等级
                    b.AAZ722, --医疗机构信息识别ID
                    b.BKE804, --统计级别
                    b.AAA027, --统筹区
                    b.AKA101, --医院等级
                    b.BAA001, --分中心
                    b.AAB301, --行政区划代码
                    b.AKB020, --医疗服务机构编码
                    b.AKB021, --医疗服务机构名称
                    b.BKF014, --科室分类编码
                    b.BKF033, --科室分类名称
                    b.AKF001, --科室编码
                    b.BKF001, --科室名称
                    b.BKF016, --医疗小组编码
                    b.BKF017, --医疗小组名称
                    b.AAF009, --医护人员职务
                    b.BKF006, --医护人员编码
                    b.AKE022, --医护人员名称
                    A.AKE554 --病案首页类型
          ;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO point_kej9;
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := 'DRGs情况统计表【KEJ9】生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND aae001 = prm_aae001 --年度
       AND bke803 = prm_bke803 --报表类型
       AND bke805 = s_BKE805 --表名
       AND aaz706 = prm_aaz706 --分组器信息ID
       AND bke807 IS NULL; --制表标志
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := 'DRGs情况统计表【KEJ9】生成出错：' || SQLERRM;
  END prc_kej9;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEK1(手术能力情况统计表)
  || 函数名称 : Prc_KEK1
  || 功能描述 :生成手术能力情况统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :手术等级统计的死亡数按手术最高级别统计
  || 作    者 :raogm
  || 完成日期 :2018-08-31
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kek1(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
    /*游标声明*/
    --统计级别
    CURSOR cur_level IS
      SELECT BKE804
        FROM KEK5 --KEK5(统计报表开通信息表)
       WHERE BKE805 = s_BKE805
         AND NVL(BKE803, prm_bke803) = prm_bke803
         AND AAE030 <= n_sysdate
         AND (AAE031 >= n_sysdate OR AAE031 IS NULL)
         AND NVL(AAE100, '1') = '1'
       GROUP BY BKE804;
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEK1;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    SAVEPOINT point_kek1;
    --统计级别
    BEGIN
      FOR rec_KEJ2 IN cur_level LOOP
        INSERT INTO KEK1
          (AAE001, --年度
           BKE803, --报表类型
           BKE800, --统计期号
           AAE030, --开始日期
           AAE031, --终止日期
           BKE804, --统计级别
           AAZ722, --医疗机构信息识别ID
           BKE838, --手术总例数
           BKE727, --死亡病例数
           BKE791, --入组例数
           BKE839, --一级手术例数
           BKE840, --一级手术死亡数
           BKE841, --一级手术占比
           BKE842, --二级手术例数
           BKE843, --二级手术死亡数
           BKE844, --二级手术占比
           BKE845, --三级手术例数
           BKE846, --三级手术死亡数
           BKE847, --三级手术占比
           BKE848, --四级手术例数
           BKE849, --四级手术死亡数
           BKE850, --四级手术占比
           BKE801, --制表人
           BKE802, --制表日期
           AAA131, --撤销标志
           AAE013, --备注
           AAZ706, --分组器信息ID
           BAC002 --人群类别
           )
          WITH d AS
           (SELECT c.bke804 AS bke804, --统计级别
                   c.aaz722 AS aaz722, --医疗机构信息识别ID
                   NVL(a.bac002, '9') AS bac002, --人群类别
                   SUM(a.bke839 + a.bke842 + a.bke845 + a.bke848) AS bke838, --手术总例数
                   SUM(CASE
                         WHEN a.ake471 = '5' AND
                              (a.bke839 > 0 OR a.bke842 > 0 OR a.bke845 > 0 OR a.bke848 > 0) THEN
                          1
                         ELSE
                          0
                       END) AS bke727, --手术死亡病例数
                   SUM(CASE
                         WHEN a.bke742 = '1' AND
                              (a.bke839 > 0 OR a.bke842 > 0 OR a.bke845 > 0 OR a.bke848 > 0) THEN
                          a.bke839 + a.bke842 + a.bke845 + a.bke848
                         ELSE
                          0
                       END) AS bke791, --手术入组例数
                   SUM(a.bke839) AS bke839, --一级手术例数
                   SUM(CASE
                         WHEN a.ake471 = '5' AND a.bke839 > 0 AND a.bke842 = 0 AND a.bke845 = 0 AND
                              a.bke848 = 0 THEN
                          1
                         ELSE
                          0
                       END) AS bke840, --一级手术死亡数
                   SUM(bke842) AS bke842, --二级手术例数
                   SUM(CASE
                         WHEN a.ake471 = '5' AND a.bke842 > 0 AND a.bke845 = 0 AND a.bke848 = 0 THEN
                          1
                         ELSE
                          0
                       END) AS bke843, --二级手术死亡数
                   SUM(bke845) AS bke845, --三级手术例数
                   SUM(CASE
                         WHEN a.ake471 = '5' AND a.bke845 > 0 AND a.bke848 = 0 THEN
                          1
                         ELSE
                          0
                       END) AS bke846, --三级手术死亡数
                   SUM(bke848) AS bke848, --四级手术例数
                   SUM(CASE
                         WHEN a.ake471 = '5' AND a.bke848 > 0 THEN
                          1
                         ELSE
                          0
                       END) AS bke849 --四级手术死亡数
              FROM (SELECT a.baz506 AS baz506, --住院病案首页ID
                           a.ake554 AS ake554, --病案首页类型
                           a.akb020 AS akb020, --医疗服务机构编号
                           a.bkf002 AS bkf002, --出院科别
                           a.akf001 AS akf001, --入院科别
                           a.ake319 AS ake319, --转科科别
                           a.bkc010 AS bkc010, --出院时间
                           a.ake320 AS ake320, --出院时间时
                           a.ake471 AS ake471, --离院方式
                           a.aaz709 AS aaz709, --DRGs分组记录ID
                           a.bke742 AS bke742, --分组状态
                           a.bke718 AS bke718, --MDC编码
                           a.bke719 AS bke719, --MDC名称
                           a.bke716 AS bke716, --DRG编码
                           a.bke717 AS bke717, --DRG名称
                           a.bac002 AS bac002, --人群类别
                           a.aaa027 AS aaa027, --统筹区编码
                           a.baa001 AS baa001, --分中心编码
                           a.aab301 AS aab301, --行政区划代码
                           decode(b.ake396, '1', 1, 0) +
                           decode(b.ake407, '1', 1, 0) +
                           decode(b.ake418, '1', 1, 0) +
                           decode(b.ake429, '1', 1, 0) +
                           decode(b.ake440, '1', 1, 0) +
                           decode(b.ake451, '1', 1, 0) +
                           decode(b.ake462, '1', 1, 0) AS bke839, --一级手术例数
                           decode(b.ake396, '2', 1, 0) +
                           decode(b.ake407, '2', 1, 0) +
                           decode(b.ake418, '2', 1, 0) +
                           decode(b.ake429, '2', 1, 0) +
                           decode(b.ake440, '2', 1, 0) +
                           decode(b.ake451, '2', 1, 0) +
                           decode(b.ake462, '2', 1, 0) AS bke842, --二级手术例数
                           decode(b.ake396, '3', 1, 0) +
                           decode(b.ake407, '3', 1, 0) +
                           decode(b.ake418, '3', 1, 0) +
                           decode(b.ake429, '3', 1, 0) +
                           decode(b.ake440, '3', 1, 0) +
                           decode(b.ake451, '3', 1, 0) +
                           decode(b.ake462, '3', 1, 0) AS bke845, --三级手术例数
                           decode(b.ake396, '4', 1, 0) +
                           decode(b.ake407, '4', 1, 0) +
                           decode(b.ake418, '4', 1, 0) +
                           decode(b.ake429, '4', 1, 0) +
                           decode(b.ake440, '4', 1, 0) +
                           decode(b.ake451, '4', 1, 0) +
                           decode(b.ake462, '4', 1, 0) AS bke848 --四级手术例数
                      FROM KEM2 a, KEC4 b
                     WHERE a.baz506 = b.baz506
                       AND a.AKE554 = b.AKE554) a,
                   (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                           a.BKE804 AS BKE804, --统计级别
                           a.AAA027 AS AAA027, --统筹区
                           a.AKA101 AS AKA101, --医院等级
                           a.BAA001 AS BAA001, --分中心
                           a.AAB301 AS AAB301, --行政区划代码
                           a.AKB020 AS AKB020, --医疗服务机构编码
                           a.AKB021 AS AKB021, --医疗服务机构名称
                           a.BKF014 AS BKF014, --科室分类编码
                           a.BKF033 AS BKF033, --科室分类名称
                           a.AKF001 AS AKF001, --科室编码
                           a.BKF001 AS BKF001, --科室名称
                           a.BKF016 AS BKF016, --医疗小组编码
                           a.BKF017 AS BKF017, --医疗小组名称
                           a.AAF009 AS AAF009, --医护人员职务
                           a.BKF006 AS BKF006, --医护人员编码
                           a.AKE022 AS AKE022 --医护人员名称
                      FROM KEJ2 a, --KEJ2(统计粒度信息表)
                           KEK5 b --KEK5(统计报表开通信息表)
                     WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                       AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                       AND b.BKE805 = s_BKE805 --报表表名
                       AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                       AND b.AAE030 <= n_sysdate
                       AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                       AND NVL(b.AAE100, '1') = '1') c
             WHERE 1 = 1
                  ---------------动态拼接级别关联条件-----------
               AND a.AAA027 = CASE
                     WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                      c.AAA027
                     ELSE
                      a.AAA027
                   END --统筹区级
               AND a.BAA001 = CASE
                     WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                      c.BAA001
                     ELSE
                      a.BAA001
                   END --分中心级
               AND a.AAB301 = CASE
                     WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                      c.AAB301
                     ELSE
                      a.AAB301
                   END --区县级
               AND a.AKB020 = CASE
                     WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                      c.AKB020
                     ELSE
                      a.AKB020
                   END --医院级
            ---------------动态拼接级别关联条件-------------
             GROUP BY c.AAZ722, --医疗机构信息识别ID
                      c.BKE804, --统计级别
                      c.AAA027, --统筹区
                      c.AKA101, --医院等级
                      c.BAA001, --分中心
                      c.AAB301, --行政区划代码
                      c.AKB020, --医疗服务机构编码
                      c.AKB021, --医疗服务机构名称
                      c.BKF014, --科室分类编码
                      c.BKF033, --科室分类名称
                      c.AKF001, --科室编码
                      c.BKF001, --科室名称
                      c.BKF016, --医疗小组编码
                      c.BKF017, --医疗小组名称
                      c.AAF009, --医护人员职务
                      c.BKF006, --医护人员编码
                      c.AKE022, --医护人员名称
                      A.BAC002 --人群类别
            )
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 d.bke804 AS bke804, --统计级别
                 d.aaz722 AS aaz722, --医疗机构信息识别ID
                 SUM(d.bke838) AS bke838, --手术总例数
                 SUM(d.bke727) AS bke727, --死亡病例数
                 SUM(d.bke791) AS bke791, --入组例数
                 SUM(d.bke839) AS bke839, --一级手术例数
                 SUM(d.bke840) AS bke840, --一级手术死亡数
                 trunc(SUM(d.bke839) /
                       decode(SUM(d.bke838), 0, 1, SUM(d.bke838)),
                       4) AS bke841, --一级手术占比
                 SUM(d.bke842) AS bke842, --二级手术例数
                 SUM(d.bke843) AS bke843, --二级手术死亡数
                 trunc(SUM(d.bke842) /
                       decode(SUM(d.bke838), 0, 1, SUM(d.bke838)),
                       4) AS bke844, --二级手术占比
                 SUM(d.bke845) AS bke845, --三级手术例数
                 SUM(d.bke846) AS bke846, --三级手术死亡数
                 trunc(SUM(d.bke845) /
                       decode(SUM(d.bke838), 0, 1, SUM(d.bke838)),
                       4) AS bke847, --三级手术占比
                 SUM(d.bke848) AS bke848, --四级手术例数
                 SUM(d.bke849) AS bke849, --四级手术死亡数
                 trunc(SUM(d.bke848) /
                       decode(SUM(d.bke838), 0, 1, SUM(d.bke838)),
                       4) AS bke850, --四级手术占比
                 'SystemAuto' AS bke801, --制表人
                 d_sysdate AS bke802, --制表日期
                 '0' AS aaa131, --撤销标志
                 NULL AS aae013, --备注
                 prm_aaz706 AS aaz706, --分组器信息ID
                 NVL(d.BAC002, '0') AS BAC002 --人群类别
            FROM d
           GROUP BY d.bke804, --统计级别
                    d.aaz722, --医疗机构信息识别ID
                    ROLLUP(d.BAC002);
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO point_kek1;
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := '手术能力情况统计信息【KEK1】生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND aae001 = prm_aae001 --年度
       AND bke803 = prm_bke803 --报表类型
       AND bke805 = s_BKE805 --表名
       AND aaz706 = prm_aaz706 --分组器信息ID
       AND bke807 IS NULL; --制表标志
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '手术能力情况统计信息【KEK1】生成出错：' || SQLERRM;
  END prc_kek1;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEK2(医疗机构盈亏分析统计表)
  || 函数名称 : Prc_KEK2
  || 功能描述 :生成医疗机构盈亏分析统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kek2(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    s_BKE804  VARCHAR2(4); --统计级别
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
    /*游标声明*/
    --统计级别
    CURSOR cur_level IS
      SELECT BKE804
        FROM KEK5 --KEK5(统计报表开通信息表)
       WHERE BKE805 = s_BKE805
         AND NVL(BKE803, prm_bke803) = prm_bke803
         AND AAE030 <= n_sysdate
         AND (AAE031 >= n_sysdate OR AAE031 IS NULL)
         AND NVL(AAE100, '1') = '1'
       GROUP BY BKE804;
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEK2;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    SAVEPOINT point_kek2;
    BEGIN
      FOR rec_KEJ2 IN cur_level LOOP
        INSERT INTO kek2
          (aae001, --年度
           bke803, --报表类型
           bke800, --统计期号
           aae030, --开始日期
           aae031, --终止日期
           bke804, --统计级别
           aaz722, --医疗机构信息识别id
           bac002, --人群类别
           bke708, --病案上传人次
           bke851, --医保支付人次
           akc264, --医疗费用总额
           ake039, --项目支付总额
           bke793, --非drg支付人次
           bke852, --项目支付总额（非drg支付）
           bke791, --drg支付人次
           bke853, --drg支付人次占比
           bke854, --drg支付总额
           bke855, --drg支付费用占比
           bke856, --drg支付平均费用
           bke857, --项目支付总额（drg支付）
           bke858, --项目支付平均费用（drg支付
           bke801, --制表人
           bke802, --制表日期
           aaa131, --撤销标志
           aae013, --备注
           aaz706, --分组器信息id
           ake482 --平均个人自付金额
           )
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 b.aaz722 AS aaz722, --医疗机构信息识别id
                 nvl(a.BAC002, '9') AS BAC002, --人群类别
                 COUNT(1) AS bke708, --  病案上传人次
                 COUNT(CASE
                         WHEN a.ake039 > 0 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke851, --  医保支付人次
                 SUM(a.akc264) AS akc264, --  医疗费用总额
                 SUM(a.ake039) AS ake039, --  项目支付总额
                 COUNT(CASE
                         WHEN a.ake039 > 0 AND bk.bke901 = '1' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke793, --  按项目支付人次
                 SUM(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '1' THEN
                        a.ake039
                       ELSE
                        NULL
                     END) AS bke852, --  按项目支付总额
                 COUNT(CASE
                         WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke791, --  按病种支付人次
                 COUNT(CASE
                         WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                          1
                         ELSE
                          NULL
                       END) / nullif(COUNT(CASE
                                             WHEN a.ake039 > 0 THEN
                                              1
                                             ELSE
                                              NULL
                                           END),
                                     0) AS bke853, --  按病种支付人次占比
                 SUM(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        bk.bke854
                       ELSE
                        NULL
                     END) AS bke854, --  按病种支付总额
                 SUM(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        bk.bke854
                       ELSE
                        NULL
                     END) / nullif(SUM(a.ake039), 0) AS bke855, --  按病种支付费用占比
                 AVG(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        bk.bke854
                       ELSE
                        NULL
                     END) AS bke856, --  按病种支付平均费用
                 SUM(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        a.ake039
                       ELSE
                        NULL
                     END) AS bke857, --  项目支付总额（按病种支付情况）
                 AVG(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        a.ake039
                       ELSE
                        NULL
                     END) AS bke858, --  项目支付平均费用（按病种支付情况）
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS aaa131, -- 撤销标志
                 '' AS aae013, -- 备注
                 prm_aaz706 AS aaz706, -- 分组器信息id
                 AVG(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        bk.ake482
                       ELSE
                        NULL
                     END) AS ake482 --  个人自付支付平均费用（按病种支付情况）
            FROM KHB7 a
            LEFT JOIN kec7 bk
              ON a.akc190 = bk.akc190 and a.akb020 = bk.akb020,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') b
           WHERE 1 = 1 --入组病案
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    b.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    b.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    b.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    b.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY b.AAZ722, --医疗机构信息识别ID
                    b.BKE804, --统计级别
                    b.AAA027, --统筹区
                    b.AKA101, --医院等级
                    b.BAA001, --分中心
                    b.AAB301, --行政区划代码
                    b.AKB020, --医疗服务机构编码
                    b.AKB021, --医疗服务机构名称
                    b.BKF014, --科室分类编码
                    b.BKF033, --科室分类名称
                    b.AKF001, --科室编码
                    b.BKF001, --科室名称
                    b.BKF016, --医疗小组编码
                    b.BKF017, --医疗小组名称
                    b.AAF009, --医护人员职务
                    b.BKF006, --医护人员编码
                    b.AKE022, --医护人员名称
                   -- A.AKE554, --病案首页类型
                    A.BAC002 --人群类别;
          UNION ALL
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 b.aaz722 AS aaz722, --医疗机构信息识别id
                 '0' AS BAC002, --人群类别
                  COUNT(1) AS bke708, --  病案上传人次
                 COUNT(CASE
                         WHEN a.ake039 > 0 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke851, --  医保支付人次
                 SUM(a.akc264) AS akc264, --  医疗费用总额
                 SUM(a.ake039) AS ake039, --  项目支付总额
                 COUNT(CASE
                         WHEN a.ake039 > 0 AND bk.bke901 = '1' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke793, --  按项目支付人次
                 SUM(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '1' THEN
                        a.ake039
                       ELSE
                        NULL
                     END) AS bke852, --  按项目支付总额
                 COUNT(CASE
                         WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                          1
                         ELSE
                          NULL
                       END) AS bke791, --  按病种支付人次
                 COUNT(CASE
                         WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                          1
                         ELSE
                          NULL
                       END) / nullif(COUNT(CASE
                                             WHEN a.ake039 > 0 THEN
                                              1
                                             ELSE
                                              NULL
                                           END),
                                     0) AS bke853, --  按病种支付人次占比
                 SUM(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        bk.bke854
                       ELSE
                        NULL
                     END) AS bke854, --  按病种支付总额
                 SUM(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        bk.bke854
                       ELSE
                        NULL
                     END) / nullif(SUM(a.ake039), 0) AS bke855, --  按病种支付费用占比
                 AVG(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        bk.bke854
                       ELSE
                        NULL
                     END) AS bke856, --  按病种支付平均费用
                 SUM(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        a.ake039
                       ELSE
                        NULL
                     END) AS bke857, --  项目支付总额（按病种支付情况）
                 AVG(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        a.ake039
                       ELSE
                        NULL
                     END) AS bke858, --  项目支付平均费用（按病种支付情况）
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS aaa131, -- 撤销标志
                 '' AS aae013, -- 备注
                 prm_aaz706 AS aaz706, -- 分组器信息id
                 AVG(CASE
                       WHEN a.ake039 > 0 AND bk.bke901 = '2' THEN
                        bk.ake482
                       ELSE
                        NULL
                     END) AS ake482 --  个人自付支付平均费用（按病种支付情况）
            FROM KHB7 a
            LEFT JOIN kec7 bk
              ON a.akc190 = bk.akc190 and a.akb020 = bk.akb020,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') b
           WHERE 1 = 1 --入组病案
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    b.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    b.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    b.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    b.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY b.AAZ722, --医疗机构信息识别ID
                    b.BKE804, --统计级别
                    b.AAA027, --统筹区
                    b.AKA101, --医院等级
                    b.BAA001, --分中心
                    b.AAB301, --行政区划代码
                    b.AKB020, --医疗服务机构编码
                    b.AKB021, --医疗服务机构名称
                    b.BKF014, --科室分类编码
                    b.BKF033, --科室分类名称
                    b.AKF001, --科室编码
                    b.BKF001, --科室名称
                    b.BKF016, --医疗小组编码
                    b.BKF017, --医疗小组名称
                    b.AAF009, --医护人员职务
                    b.BKF006, --医护人员编码
                    b.AKE022 --医护人员名称
                   -- A.AKE554 --病案首页类型
          ;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO point_kek2;
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := '医疗机构盈亏分析统计信息【KEK2】生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND aae001 = prm_aae001 --年度
       AND bke803 = prm_bke803 --报表类型
       AND bke805 = s_BKE805 --表名
      -- AND aaz706 = prm_aaz706 --分组器信息ID
       AND bke807 IS NULL; --制表标志
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '医疗机构盈亏分析统计信息【KEK2】生成出错：' || SQLERRM;
  END prc_kek2;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEK3(DRGs盈亏分析统计表)
  || 函数名称 : Prc_KEK3
  || 功能描述 :生成DRGs盈亏分析统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kek3(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    s_BKE804  VARCHAR2(4); --统计级别
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
    /*游标声明*/
    --统计级别
    CURSOR cur_level IS
      SELECT BKE804
        FROM KEK5 --KEK5(统计报表开通信息表)
       WHERE BKE805 = s_BKE805
         AND NVL(BKE803, prm_bke803) = prm_bke803
         AND AAE030 <= n_sysdate
         AND (AAE031 >= n_sysdate OR AAE031 IS NULL)
         AND NVL(AAE100, '1') = '1'
       GROUP BY BKE804;
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEK3;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    SAVEPOINT point_kek3;
    BEGIN
      FOR rec_KEJ2 IN cur_level LOOP
        INSERT INTO kek3
          (aae001, --年度
           bke803, --报表类型
           bke800, --统计期号
           aae030, --开始日期
           aae031, --终止日期
           bke804, --统计级别
           aaz722, --医疗机构信息识别id
           bke716, --drg编码
           bke717, --drg名称
           bac002, --人群类别
           akc264, --医疗费用总额
           bke859, --drg支付人次
           bke854, --drg支付总额
           bke855, --drg支付费用占比
           bke856, --drg支付平均费用
           bke857, --项目支付总额（drg支付）
           bke858, --项目支付平均费用（drg支付）
           bke801, --制表人
           bke802, --制表日期
           aaa131, --撤销标志
           aae013, --备注
           aaz706, --分组器信息id
           ake482 --  DRG组平均自付费用
           )
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 b.aaz722 AS aaz722, --医疗机构信息识别id
                 a.bke716 AS bke716, -- drg编码
                 a.bke717 AS bke717, -- drg名称
                 nvl(a.BAC002, '9') AS BAC002, --人群类别
                 SUM(a.akc264) AS akc264, --  医疗费用总额
                 COUNT(CASE
                         WHEN bk.bke854 > 0 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke791, --  drg支付人次
                 SUM(CASE
                       WHEN bk.bke854 > 0 THEN
                        bk.bke854
                       ELSE
                        NULL
                     END) AS bke854, --  drg支付总额
                 DECODE(SUM(a.ake039),
                        0,
                        0,
                        SUM(CASE
                              WHEN bk.bke854 > 0 THEN
                               bk.bke854
                              ELSE
                               NULL
                            END) / SUM(a.ake039)) AS bke855, --  drg支付费用占比
                 AVG(CASE
                       WHEN bk.bke854 > 0 THEN
                        bk.bke854
                       ELSE
                        NULL
                     END) AS bke856, --  drg支付平均费用
                 SUM(CASE
                       WHEN bk.bke854 > 0 THEN
                        a.ake039
                       ELSE
                        NULL
                     END) AS bke857, --  项目支付总额（drg支付）
                 AVG(CASE
                       WHEN bk.bke854 > 0 THEN
                        a.ake039
                       ELSE
                        NULL
                     END) AS bke858, --  项目支付平均费用（drg支付）
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS aaa131, -- 撤销标志
                 '' AS aae013, -- 备注
                 prm_aaz706 AS aaz706, -- 分组器信息id
                 AVG(a.ake051) AS ake482 --  DRG组平均自付费用
            FROM kem2 a
            LEFT JOIN kec7 bk
              ON a.baz506 = bk.baz506,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') b
           WHERE a.bke742 = '1' --入组病案
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    b.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    b.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    b.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    b.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY a.bke716, --drg编码
                    a.bke717, --drg名称
                    b.AAZ722, --医疗机构信息识别ID
                    b.BKE804, --统计级别
                    b.AAA027, --统筹区
                    b.AKA101, --医院等级
                    b.BAA001, --分中心
                    b.AAB301, --行政区划代码
                    b.AKB020, --医疗服务机构编码
                    b.AKB021, --医疗服务机构名称
                    b.BKF014, --科室分类编码
                    b.BKF033, --科室分类名称
                    b.AKF001, --科室编码
                    b.BKF001, --科室名称
                    b.BKF016, --医疗小组编码
                    b.BKF017, --医疗小组名称
                    b.AAF009, --医护人员职务
                    b.BKF006, --医护人员编码
                    b.AKE022, --医护人员名称
                    A.AKE554, --病案首页类型
                    A.BAC002 --人群类别;
          UNION ALL
          SELECT prm_aae001 AS aae001, --年度
                 prm_bke803 AS bke803, --报表类型
                 prm_bke800 AS bke800, --统计期号
                 prm_aae030 AS aae030, --开始日期
                 prm_aae031 AS aae031, --终止日期
                 rec_KEJ2.Bke804 AS BKE804, --统计级别
                 b.aaz722 AS aaz722, --医疗机构信息识别id
                 a.bke716 AS bke716, -- drg编码
                 a.bke717 AS bke717, -- drg名称
                 '0' AS BAC002, --人群类别
                 SUM(a.akc264) AS akc264, --  医疗费用总额
                 COUNT(CASE
                         WHEN bk.bke854 > 0 THEN
                          1
                         ELSE
                          NULL
                       END) AS bke791, --  drg支付人次
                 SUM(CASE
                       WHEN bk.bke854 > 0 THEN
                        bk.bke854
                       ELSE
                        NULL
                     END) AS bke854, --  drg支付总额
                 DECODE(SUM(a.ake039),
                        0,
                        0,
                        SUM(CASE
                              WHEN bk.bke854 > 0 THEN
                               bk.bke854
                              ELSE
                               NULL
                            END) / SUM(a.ake039)) AS bke855, --  drg支付费用占比
                 AVG(CASE
                       WHEN bk.bke854 > 0 THEN
                        bk.bke854
                       ELSE
                        NULL
                     END) AS bke856, --  drg支付平均费用
                 SUM(CASE
                       WHEN bk.bke854 > 0 THEN
                        a.ake039
                       ELSE
                        NULL
                     END) AS bke857, --  项目支付总额（drg支付）
                 AVG(CASE
                       WHEN bk.bke854 > 0 THEN
                        a.ake039
                       ELSE
                        NULL
                     END) AS bke858, --  项目支付平均费用（drg支付）
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS aaa131, -- 撤销标志
                 '' AS aae013, -- 备注
                 prm_aaz706 AS aaz706, -- 分组器信息id
                 AVG(a.ake051) AS ake482 --  DRG组平均自付费用
            FROM kem2 a
            LEFT JOIN kec7 bk
              ON a.baz506 = bk.baz506,
           (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') b
           WHERE a.bke742 = '1' --入组病案
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    b.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    b.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    b.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    b.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY a.bke716, --drg编码
                    a.bke717, --drg名称
                    b.AAZ722, --医疗机构信息识别ID
                    b.BKE804, --统计级别
                    b.AAA027, --统筹区
                    b.AKA101, --医院等级
                    b.BAA001, --分中心
                    b.AAB301, --行政区划代码
                    b.AKB020, --医疗服务机构编码
                    b.AKB021, --医疗服务机构名称
                    b.BKF014, --科室分类编码
                    b.BKF033, --科室分类名称
                    b.AKF001, --科室编码
                    b.BKF001, --科室名称
                    b.BKF016, --医疗小组编码
                    b.BKF017, --医疗小组名称
                    b.AAF009, --医护人员职务
                    b.BKF006, --医护人员编码
                    b.AKE022, --医护人员名称
                    A.AKE554 --病案首页类型
          ;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO point_kek3;
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := '医疗机构盈亏分析统计信息【KEK2】生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND aae001 = prm_aae001 --年度
       AND bke803 = prm_bke803 --报表类型
       AND bke805 = s_BKE805 --表名
       AND aaz706 = prm_aaz706 --分组器信息ID
       AND bke807 IS NULL; --制表标志
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := 'DRGs盈亏分析统计信息【KEK3】生成出错：' || SQLERRM;
  END prc_kek3;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEK4(考核情况统计表)
  || 函数名称 : Prc_KEK4
  || 功能描述 :生成考核情况统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_aae001            年度                   IN     VARCHAR2
  ||           prm_bke803            报表类型               IN     VARCHAR2
  ||           prm_aae030            开始日期               IN     VARCHAR2
  ||           prm_aae031            终止日期               IN     VARCHAR2
  ||           prm_aaz706            分组器信息ID           IN     NUMBER
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :
  || 完成日期 :
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kek4(prm_bke800   IN VARCHAR2, --统计期号
                     prm_aae001   IN VARCHAR2, --年度
                     prm_bke803   IN VARCHAR2, --报表类型
                     prm_aae030   IN VARCHAR2, --开始日期
                     prm_aae031   IN VARCHAR2, --终止日期
                     prm_aaz706   IN NUMBER, --分组器信息ID
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
    /*游标声明*/
    --统计级别
    CURSOR cur_level IS
      SELECT BKE804
        FROM KEK5 --KEK5(统计报表开通信息表)
       WHERE BKE805 = s_BKE805
         AND NVL(BKE803, prm_bke803) = prm_bke803
         AND AAE030 <= n_sysdate
         AND (AAE031 >= n_sysdate OR AAE031 IS NULL)
         AND NVL(AAE100, '1') = '1'
       GROUP BY BKE804;
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEK4;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    SAVEPOINT point_kek4;
    --统计级别
    BEGIN
      FOR rec_KEJ2 IN cur_level LOOP
        INSERT INTO KEK4
          (AAE001, --年度
           BKE803, --报表类型
           BKE800, --统计期号
           AAE030, --开始日期
           AAE031, --终止日期
           BKE804, --统计级别
           AAZ722, --医疗机构信息识别ID
           BKE783, --考核类型
           BKE781, --考核主体
           BKE035, --考核平均分
           BKE861, --考核排名
           BKE801, --制表人
           BKE802, --制表日期
           AAA131, --撤销标志
           AAE013, --备注
           BAC002 --人群类别
           )
          SELECT prm_aae001 AS AAE001, --年度
                 prm_bke803 AS BKE803, --报表类型
                 prm_bke800 AS BKE800, --统计期号
                 prm_aae030 AS AAE030, --开始日期
                 prm_aae031 AS AAE031, --终止日期
                 c.BKE804, --统计级别
                 C.AAZ722, --医疗机构信息识别ID
                 '1' AS BKE783, --考核类型
                 b.bke781 AS bke781, --考核主体
                 AVG(b.bke782) AS BKE035, --病案平均分
                 --b.BKE861, --考核排名
                 RANK() OVER(PARTITION BY c.BKE804, a.bac002 ORDER BY AVG(b.bke782) DESC) AS BKE861, --考核排名
                 -- null,      --考核排名
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS AAA131, --撤销标志
                 NULL AS AAE013, --备注
                 NVL(a.bac002, '9') AS bac002 --人群类别
            FROM KEM2 a,
                 (SELECT a.aaz721, --病案首页考核评分id
                         a.baz506, --住院病案首页id
                         a.ake554, --住院病案首页类型
                         a.akc190, --就诊登记号
                         a.bke781, --考核主体
                         a.bke782, --病案总分
                         a.aae011, --经办人
                         a.aae036, --经办时间
                         a.aaa131, --撤销标志
                         a.aae013, --备注
                         b.bac002 --人群类别
                  -- RANK() OVER(PARTITION BY bke781,b.bac002 ORDER BY bke782 DESC) AS BKE861 --考核排名
                    FROM KEB8 a, kem2 b
                   WHERE a.baz506 = b.baz506) b,
                 (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') c
           WHERE 1 = 1
             AND a.baz506 = b.baz506
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    c.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    c.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    c.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    c.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY c.AAZ722, --医疗机构信息识别ID
                    c.BKE804, --统计级别
                    c.AAA027, --统筹区
                    c.AKA101, --医院等级
                    c.BAA001, --分中心
                    c.AAB301, --行政区划代码
                    c.AKB020, --医疗服务机构编码
                    c.AKB021, --医疗服务机构名称
                    c.BKF014, --科室分类编码
                    c.BKF033, --科室分类名称
                    c.AKF001, --科室编码
                    c.BKF001, --科室名称
                    c.BKF016, --医疗小组编码
                    c.BKF017, --医疗小组名称
                    c.AAF009, --医护人员职务
                    c.BKF006, --医护人员编码
                    c.AKE022, --医护人员名称
                    A.BAC002, --人群类别
                    b.bke781 --考核主体
          --  b.BKE861  --考核排名
          UNION ALL
          SELECT prm_aae001 AS AAE001, --年度
                 prm_bke803 AS BKE803, --报表类型
                 prm_bke800 AS BKE800, --统计期号
                 prm_aae030 AS AAE030, --开始日期
                 prm_aae031 AS AAE031, --终止日期
                 c.BKE804, --统计级别
                 C.AAZ722, --医疗机构信息识别ID
                 '1' AS BKE783, --考核类型
                 b.bke781 AS bke781, --考核主体
                 AVG(b.bke782) AS BKE035, --病案平均分
                 -- b.BKE861, --考核排名
                 RANK() OVER(PARTITION BY c.BKE804 ORDER BY AVG(b.bke782) DESC) AS BKE861, --考核排名
                 -- null, --考核排名
                 'SystemAuto' AS BKE801, --制表人
                 d_sysdate AS BKE802, --制表日期
                 '0' AS AAA131, --撤销标志
                 NULL AS AAE013, --备注
                 '0' AS bac002 --人群类别
            FROM KEM2 a,
                 (SELECT a.aaz721, --病案首页考核评分id
                         a.baz506, --住院病案首页id
                         a.ake554, --住院病案首页类型
                         a.akc190, --就诊登记号
                         a.bke781, --考核主体
                         a.bke782, --病案总分
                         a.aae011, --经办人
                         a.aae036, --经办时间
                         a.aaa131, --撤销标志
                         a.aae013 --备注
                  -- RANK() OVER(PARTITION BY bke781 ORDER BY bke782 DESC) AS BKE861 --考核排名
                    FROM KEB8 a) b,
                 (SELECT a.AAZ722 AS AAZ722, --医疗机构信息识别ID
                         a.BKE804 AS BKE804, --统计级别
                         a.AAA027 AS AAA027, --统筹区
                         a.AKA101 AS AKA101, --医院等级
                         a.BAA001 AS BAA001, --分中心
                         a.AAB301 AS AAB301, --行政区划代码
                         a.AKB020 AS AKB020, --医疗服务机构编码
                         a.AKB021 AS AKB021, --医疗服务机构名称
                         a.BKF014 AS BKF014, --科室分类编码
                         a.BKF033 AS BKF033, --科室分类名称
                         a.AKF001 AS AKF001, --科室编码
                         a.BKF001 AS BKF001, --科室名称
                         a.BKF016 AS BKF016, --医疗小组编码
                         a.BKF017 AS BKF017, --医疗小组名称
                         a.AAF009 AS AAF009, --医护人员职务
                         a.BKF006 AS BKF006, --医护人员编码
                         a.AKE022 AS AKE022 --医护人员名称
                    FROM KEJ2 a, --KEJ2(统计粒度信息表)
                         KEK5 b --KEK5(统计报表开通信息表)
                   WHERE a.AAZ722 = b.AAZ722 --医疗机构信息识别ID
                     AND b.BKE804 = rec_KEJ2.BKE804 --统计级别
                     AND b.BKE805 = s_BKE805 --报表表名
                     AND NVL(b.BKE803, prm_bke803) = prm_bke803 --报表类型
                     AND b.AAE030 <= n_sysdate
                     AND (b.AAE031 >= n_sysdate OR b.AAE031 IS NULL)
                     AND NVL(b.AAE100, '1') = '1') c
           WHERE 1 = 1
             AND a.baz506 = b.baz506
                ---------------动态拼接级别关联条件-----------
             AND a.AAA027 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aaa027 THEN
                    c.AAA027
                   ELSE
                    a.AAA027
                 END --统筹区级
             AND a.BAA001 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_baa001 THEN
                    c.BAA001
                   ELSE
                    a.BAA001
                 END --分中心级
             AND a.AAB301 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_aab301 THEN
                    c.AAB301
                   ELSE
                    a.AAB301
                 END --区县级
             AND a.AKB020 = CASE
                   WHEN rec_KEJ2.BKE804 = pkg_comm.bke804_akb020 THEN
                    c.AKB020
                   ELSE
                    a.AKB020
                 END --医院级
          ---------------动态拼接级别关联条件-------------
           GROUP BY c.AAZ722, --医疗机构信息识别ID
                    c.BKE804, --统计级别
                    c.AAA027, --统筹区
                    c.AKA101, --医院等级
                    c.BAA001, --分中心
                    c.AAB301, --行政区划代码
                    c.AKB020, --医疗服务机构编码
                    c.AKB021, --医疗服务机构名称
                    c.BKF014, --科室分类编码
                    c.BKF033, --科室分类名称
                    c.AKF001, --科室编码
                    c.BKF001, --科室名称
                    c.BKF016, --医疗小组编码
                    c.BKF017, --医疗小组名称
                    c.AAF009, --医护人员职务
                    c.BKF006, --医护人员编码
                    c.AKE022, --医护人员名称
                    -- A.BAC002, --人群类别
                    b.bke781 --考核主体
          -- b.BKE861  --考核排名
          ;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        ROLLBACK TO point_kek4;
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := 'KEK4(考核情况统计表)生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND aae001 = prm_aae001 --年度
       AND bke803 = prm_bke803 --报表类型
       AND bke805 = s_BKE805 --表名
       AND aaz706 = prm_aaz706 --分组器信息ID
       AND bke807 IS NULL; --制表标志
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '考核情况统计信息【KEK4】生成出错：' || SQLERRM;
  END prc_kek4;

  /*--------------------------------------------------------------------------
  || 业务环节 : KEK6(服务评分统计表)
  || 函数名称 : Prc_KEK6
  || 功能描述 :生成服务评分统计信息
  || 使用场合 :
  || 参数描述 : 标识                  名称             输入输出   数据类型
  ||            ---------------------------------------------------------------
  ||           prm_bke800            统计期号               IN     VARCHAR2
  ||           prm_appcode           执行代码               OUT     NUMBER
  ||           prm_errormsg           错误信息              OUT     VARCHAR2
  ||            ---------------------------------------------------------------
  ||
  || 其它说明 :
  || 作    者 :raogm
  || 完成日期 :2018-09-07
  ||---------------------------------------------------------------------------
  ||                                 修改记录
  ||---------------------------------------------------------------------------
  || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
  || 修改描述 :
  ||-------------------------------------------------------------------------*/
  PROCEDURE prc_kek6(prm_bke800   IN VARCHAR2, --统计期号
                     prm_appcode  OUT NUMBER, --执行代码
                     prm_errormsg OUT VARCHAR2) --错误信息
   IS
    --变量定义
    d_sysdate DATE; --系统时间
    n_sysdate NUMBER(8); --系统日期
    s_BKE805  VARCHAR2(20); --报表表名
    rec_KEJ2  KEJ2%ROWTYPE; --KEJ2(统计粒度信息表)
    rec_KEM1  KEM1%ROWTYPE; --KEM1(统计信息生成日志表)
  BEGIN
    /* 变量初始化 */
    prm_appcode     := pkg_comm.def_ok;
    prm_errormsg    := NULL;
    d_sysdate       := SYSDATE;
    n_sysdate       := to_char(d_sysdate, 'yyyymmdd');
    s_BKE805        := pkg_comm.bke805_KEK6;
    rec_KEM1.BKE807 := pkg_comm.def_bke807_ok; --制表标志
    rec_KEM1.BAE108 := d_sysdate; --执行开始时间
    rec_KEM1.BAE191 := NULL; --错误代码
    rec_KEM1.BAE188 := NULL; -- 错误信息
    BEGIN
      INSERT INTO KEK6
        (AAE001, --年度
         BKE803, --报表类型
         BKE800, --统计期号
         AAE030, --开始日期
         AAE031, --终止日期
         BKE804, --统计级别
         AAZ722, --医疗机构信息识别ID
         BKE035, --服务总分
         BKE881, --能力得分
         BKE762, --DRG组数
         BKE882, --DRG组数平均值
         BKE795, --CMI
         BKE883, --CMI平均值
         BKE884, --服务效率得分
         BKE788, --费用消耗指数
         BKE789, --时间消耗指数
         BKE885, --服务安全得分
         BKE787, --低风险死亡率
         BKE821, --中低风险死亡率
         BKE886, --病案质量得分
         BKE801, --制表人
         BKE802, --制表日期
         AAA131, --撤销标志
         AAE013, --备注
         AAZ706, --分组器信息ID
         BAC002 --人群类别
         )
        WITH d AS
         (SELECT a.AAZ722 AS aaz722, --医疗机构信息识别ID
                 a.BKE804 AS BKE804, --统计级别
                 a.AAE001 AS AAE001, --年度
                 a.BKE803 AS BKE803, --报表类型
                 a.BKE800 AS BKE800, -- 统计期号
                 a.AAE030 AS AAE030, --开始日期
                 a.AAE031 AS AAE031, --终止日期
                 a.AAZ706 AS AAZ706, --分组器ID
                 a.AAA131 AS AAA131, --撤销标志
                 a.bac002 AS bac002, --人群类别
                 a.BKE762 AS BKE762, --DRG组数
                 AVG(a.BKE762) over(PARTITION BY a.BKE804, a.AAE001, a.BKE803, a.BKE800, a.AAZ706, a.AAA131, a.bac002) AS BKE882, --DRG组数平均值
                 a.BKE795 AS BKE795, --CMI
                 AVG(a.BKE795) over(PARTITION BY a.BKE804, a.AAE001, a.BKE803, a.BKE800, a.AAZ706, a.AAA131, a.bac002) AS BKE883, --CMI平均值
                 b.BKE788 AS BKE788, --费用消耗指数
                 b.BKE789 AS BKE789, --时间消耗指数
                 c.BKE787 AS BKE787, --低风险死亡率
                 CASE
                   WHEN c.BKE787 = 0 THEN
                    1
                   ELSE
                    CASE
                      WHEN 0.9 - 0.1 * trunc(c.BKE787 / 0.0005) < 0 THEN
                       0
                      ELSE
                       0.9 - 0.1 * trunc(c.BKE787 / 0.0005)
                    END
                 END AS l_score, --低风险死亡分数
                 c.BKE821 AS BKE821, --中低风险死亡率
                 CASE
                   WHEN c.BKE821 = 0 THEN
                    1
                   ELSE
                    CASE
                      WHEN 0.9 - 0.1 * trunc(c.BKE821 / 0.0025) < 0 THEN
                       0
                      ELSE
                       0.9 - 0.1 * trunc(c.BKE821 / 0.0025)
                    END
                 END AS ml_score, --中低风险死亡分数
                 trunc(d.BKE035 / 100, 4) AS BKE886 --病案质量得分
            FROM KEJ3 a, KEJ4 b, KEJ5 c, KEK4 d
           WHERE a.AAZ722 = b.aaz722
             AND a.bac002 = b.bac002
             AND a.AAE001 = b.AAE001
             AND a.BKE803 = b.BKE803
             AND a.BKE800 = b.BKE800
             AND a.AAZ706 = b.AAZ706
             AND a.AAA131 = b.AAA131
             AND a.AAZ722 = c.aaz722
             AND a.bac002 = c.bac002
             AND a.AAE001 = c.AAE001
             AND a.BKE803 = c.BKE803
             AND a.BKE800 = c.BKE800
             AND a.AAZ706 = c.AAZ706
             AND a.AAA131 = c.AAA131
             AND a.AAZ722 = d.aaz722
             AND a.bac002 = d.bac002
             AND a.AAE001 = d.AAE001
             AND a.BKE803 = d.BKE803
             AND a.BKE800 = d.BKE800
             AND a.AAA131 = d.AAA131
             AND a.BKE800 = prm_BKE800),
        e AS
         (SELECT AAE001 AS AAE001, --年度
                 BKE803 AS BKE803, --报表类型
                 BKE800 AS BKE800, --统计期号
                 AAE030 AS AAE030, --开始日期
                 AAE031 AS AAE031, --终止日期
                 BKE804 AS BKE804, --统计级别
                 AAZ722 AS AAZ722, --医疗机构信息识别ID
                 trunc(sqrt((BKE762 / BKE882) * (BKE795 / BKE882)), 2) AS BKE881, --能力得分
                 BKE762 AS BKE762, --DRG组数
                 BKE882 AS BKE882, --DRG组数平均值
                 BKE795 AS BKE795, --CMI
                 BKE883 AS BKE883, --CMI平均值
                 trunc(sqrt((1 / BKE788) * (1 / BKE789)), 2) AS BKE884, --服务效率得分
                 BKE788 AS BKE788, --费用消耗指数
                 BKE789 AS BKE789, --时间消耗指数
                 trunc(sqrt(l_score * ml_score), 2) AS BKE885, --服务安全得分
                 BKE787 AS BKE787, --低风险死亡率
                 BKE821 AS BKE821, --中低风险死亡率
                 trunc(sqrt(BKE886), 2) AS BKE886, --病案质量得分
                 AAZ706 AS AAZ706, --分组器信息ID
                 BAC002 AS BAC002 --人群类别
            FROM d)
        SELECT AAE001 AS AAE001, --年度
               BKE803 AS BKE803, --报表类型
               BKE800 AS BKE800, --统计期号
               AAE030 AS AAE030, --开始日期
               AAE031 AS AAE031, --终止日期
               BKE804 AS BKE804, --统计级别
               AAZ722 AS AAZ722, --医疗机构信息识别ID
               nvl(BKE881, 0) + nvl(BKE884, 0) + nvl(BKE885, 0) +
               nvl(BKE886, 0) AS BKE035, --服务总分
               BKE881 AS BKE881, --能力得分
               BKE762 AS BKE762, --DRG组数
               BKE882 AS BKE882, --DRG组数平均值
               BKE795 AS BKE795, --CMI
               BKE883 AS BKE883, --CMI平均值
               BKE884 AS BKE884, --服务效率得分
               BKE788 AS BKE788, --费用消耗指数
               BKE789 AS BKE789, --时间消耗指数
               BKE885 AS BKE885, --服务安全得分
               BKE787 AS BKE787, --低风险死亡率
               BKE821 AS BKE821, --中低风险死亡率
               BKE886 AS BKE886, --病案质量得分
               'SystemAuto' AS BKE801, --制表人
               d_sysdate AS BKE802, --制表日期
               '0' AS AAA131, --撤销标志
               '服务安全【死亡率=0 分数=1;0<死亡率<0.0005 低风险组死亡分数=0.9以此类推;中低风险同理:截距为0.0025】' AS AAE013, --备注
               AAZ706 AS AAZ706, --分组器信息ID
               BAC002 AS BAC002 --人群类别
          FROM e;
    EXCEPTION
      WHEN OTHERS THEN
        prm_appcode     := pkg_comm.def_err;
        prm_errormsg    := 'KEK6(服务评分统计表)生成出错：' || SQLERRM;
        rec_KEM1.BKE807 := pkg_comm.def_bke807_err; --制表标志
        rec_KEM1.BAE191 := prm_appcode; --错误代码
        rec_KEM1.BAE188 := prm_errormsg; -- 错误信息
    END;
    rec_KEM1.BAE109 := SYSDATE; --执行结束时间
    UPDATE KEM1
       SET BKE807 = rec_KEM1.BKE807, --制表标志
           BAE108 = rec_KEM1.BAE108, --执行开始时间
           BAE109 = rec_KEM1.BAE109, --执行结束时间
           BAE191 = rec_KEM1.BAE191, --错误代码
           BAE188 = rec_KEM1.BAE188 --错误信息
     WHERE bke800 = prm_bke800 --统计期号
       AND bke805 = s_BKE805 --表名
       AND bke807 IS NULL; --制表标志
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '服务评分统计信息【KEK6】生成出错：' || SQLERRM;
  END prc_kek6;

END pkg_a_statistics_dip;
/

