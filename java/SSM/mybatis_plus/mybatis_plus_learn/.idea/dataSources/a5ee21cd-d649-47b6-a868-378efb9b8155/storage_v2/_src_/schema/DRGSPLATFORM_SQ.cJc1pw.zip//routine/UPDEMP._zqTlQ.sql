create procedure updemp as
       TYPE t_kha0 IS TABLE OF kha0%ROWTYPE INDEX BY BINARY_INTEGER;
       l_kha0 t_kha0;-- 声明 bainfo 表结构一致变量

begin

  SELECT akb020 BULK COLLECT INTO l_kha0 FROM kh40 where bkeh86 in ('35','93','94') and bkf044 = '2' group by akb020;

  FOR i IN 1 .. l_kha0.COUNT LOOP
        update kh40 set bke709 = '0' where bkeh86 in ('35','93','94') and bkf044 = '2' and bke709 = '1'
        and akb020 = l_kha0(i).akb020;
  end loop;


end;


/

