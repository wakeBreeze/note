create view V_KEJ3_KEJ4_KEJ5 as
SELECT
a.aaz722,--医疗机构信息识别id
a.bke804,--统计级别
a.aaa027,--统筹区
a.aka101,--医院等级
a.baa001,--分中心
a.aab301,--行政区划代码
a.akb020,--医疗服务机构编码
a.akb021,--医疗服务机构名称
a.bkf014,--科室分类编码
a.bkf033,--科室分类名称
a.akf001,--科室编码
a.bkf001,--科室名称
a.bkf016,--医疗小组编码
a.bkf017,--医疗小组名称
a.aaf009,--医护人员职务
a.bkf006,--医护人员编码
a.ake022,--医护人员名称
a.aae030,--开始日期
a.aae031,--终止日期
a.aae100,--有效标志
a.aae013,--备注
b.aae001,--年度
b.bke803,--报表类型
b.bke800,--统计期号
b.bke708,--病案总数
b.bke758,--有效病案数
b.bke760,--排除病案数
b.bke790,--分组病案数
b.bke791,--入组病案数
b.bke762,--drg组数
b.bkb276,--drg入组率
b.bke792,--医保支付分析入组病案数
b.bke793,--未入组病案数
b.bke794,--未入组歧义病案数
b.bke795,--cmi
b.bke724,--总权重
b.bke796,--内科权重
b.bke797,--外科权重
b.bke798,--非手术室操作权重
b.bke799,--未入组权重
b.bke810,--歧义病案权重
b.bke801,--制表人
b.bke802,--制表日期
b.aaa131,--撤销标志
b.aaz706,--分组器信息id
b.bac002,--人群类别
c.bke723,--平均住院日
c.bke789,--时间消耗指数
c.bke722,--例均费用
c.bke788,--费用消耗指数
c.bke811,--药品费用
c.bke812,--药品消耗指数
c.bke813,--耗材费用
c.bke814,--耗材消耗指数
c.bke815,--平均抗生素费用
c.bke816,--抗生素消耗指数
d.bke817,--平均死亡年龄
d.bke818,--死亡病案数
d.bke728,--死亡率
d.bke819,--低风险死亡数
d.bke787,--低风险死亡率
d.bke820,--中低风险死亡数
d.bke821,--中低风险死亡率
d.bke822,--中高风险死亡数
d.bke823,--中高风险死亡率
d.bke824,--高风险死亡数
d.bke825,--高风险死亡率
d.bke974,--无风险死亡数
d.bke975 --无风险死亡率
from KEJ2 a
inner join KEJ3 b on a.AAZ722 = b.aaz722
left  join KEJ4 c on
    b.aaz722 = c.aaz722
and b.bac002 = c.bac002
and b.AAE001 = c.AAE001
and b.BKE803 = c.BKE803
and b.BKE800 = c.BKE800
and b.AAZ706 = c.AAZ706
and b.AAA131 = c.AAA131
left  join KEJ5 d on
    b.aaz722 = d.aaz722
and b.bac002 = d.bac002
and b.AAE001 = d.AAE001
and b.BKE803 = d.BKE803
and b.BKE800 = d.BKE800
and b.AAZ706 = d.AAZ706
and b.AAA131 = d.AAA131


/

