create FUNCTION f_genera_name_or_code(param_name_or_code in VARCHAR2,
                                                 param_operation_code in VARCHAR2,
                                                 param_mcc_code IN VARCHAR2,
                                                 param_age IN VARCHAR2,
                                                 param_curType IN NUMBER)
return VARCHAR2
AS
       v_dis_code_or_name VARCHAR2(1000);
       v_dis_code VARCHAR2(1000);
       v_dis_name VARCHAR2(1000);
       v_operation_count NUMBER(10); -- 当前有多少手术
       v_flag NUMBER(1) := 1; -- 1：治疗方式，2：治疗分类
BEGIN

  -- 查询有几个手术
  SELECT COUNT(1) INTO v_operation_count
  FROM  (
      SELECT regexp_substr(param_operation_code,'[^-]+',1,ROWNUM) AS operation_code FROM dual
      CONNECT BY ROWNUM <= LENGTH(param_operation_code)-LENGTH(REPLACE(param_operation_code,'-','')) + 1
  ) WHERE operation_code IS NOT NULL;

  -- 获取病种名称或编码
  IF param_name_or_code IS NOT NULL THEN
    v_dis_code := param_name_or_code;
    v_dis_name := param_name_or_code;
    -- 手术
    IF param_operation_code IS NOT NULL THEN
      v_dis_code := CONCAT(v_dis_code,'-' || param_operation_code);
      v_dis_name := CONCAT(v_dis_name,'/');
      -- 判断是治疗方式还是治疗分类： 1：治疗方式，2：治疗分类
      IF param_operation_code = 'C0' OR
         param_operation_code = 'C1' OR
         param_operation_code = 'C2' OR
         param_operation_code = 'C3' THEN
       v_flag := 2;
      END IF;

      -- 连接手术编码或名称
      IF v_flag = 1 THEN
        IF param_operation_code = 'M0' THEN
          v_dis_name := CONCAT(v_dis_name,'无手术');
        ELSE
          v_dis_name := CONCAT(v_dis_name,'存在' || v_operation_count || '个手术');
        END IF;
      ELSE
        IF param_operation_code = 'C0' THEN
          v_dis_name := CONCAT(v_dis_name,'无手术');
        ELSIF param_operation_code = 'C1' THEN
          v_dis_name := CONCAT(v_dis_name,'诊断性操作');
        ELSIF param_operation_code = 'C2' THEN
          v_dis_name := CONCAT(v_dis_name,'治疗性操作');
        ELSIF param_operation_code = 'C3' THEN
          v_dis_name := CONCAT(v_dis_name,'相关手术');
        END IF;
      END IF;

      -- 连接严重程度
      IF param_mcc_code IS NOT NULL THEN
        v_dis_name := CONCAT(v_dis_name,'/');
        v_dis_code := CONCAT(v_dis_code,'-' || param_mcc_code);
        IF param_mcc_code = '1' THEN
            v_dis_name := CONCAT(v_dis_name,'严重并发症与合并症');
        ELSIF param_mcc_code = '3' THEN
            v_dis_name := CONCAT(v_dis_name,'一般并发症与合并症');
        ELSIF param_mcc_code = '5' THEN
            v_dis_name := CONCAT(v_dis_name,'无并发症与合并症');
        END IF;

         -- 连接年龄
         IF param_age IS NOT NULL THEN
           v_dis_code := CONCAT(v_dis_code,'-' || param_age);
           v_dis_name := CONCAT(v_dis_name,'/');
           IF param_age = 'A' THEN
             v_dis_name := CONCAT(v_dis_name,'0-28天');
           ELSIF param_age = 'B' THEN
             v_dis_name := CONCAT(v_dis_name,'29天-1岁');
           ELSIF param_age = 'C' THEN
             v_dis_name := CONCAT(v_dis_name,'1-3岁');
           ELSIF param_age = 'D' THEN
             v_dis_name := CONCAT(v_dis_name,'4-6岁');
           ELSIF param_age = 'E' THEN
             v_dis_name := CONCAT(v_dis_name,'7-12岁');
           ELSIF param_age = 'F' THEN
             v_dis_name := CONCAT(v_dis_name,'13-17岁');
           ELSIF param_age = 'G' THEN
             v_dis_name := CONCAT(v_dis_name,'18-65岁');
           ELSIF param_age = 'H' THEN
             v_dis_name := CONCAT(v_dis_name,'66-72岁');
           ELSIF param_age = 'I' THEN
             v_dis_name := CONCAT(v_dis_name,'73-84岁');
           ELSE
             v_dis_name := CONCAT(v_dis_name,'85岁及以上');
           END IF;
         END IF;
      END IF;
    END IF;
  END IF;

  IF param_curType = 1 THEN
    v_dis_code_or_name := v_dis_code;
  ELSE
    v_dis_code_or_name := v_dis_name;
  END IF;

  RETURN v_dis_code_or_name;
end f_genera_name_or_code;


/

