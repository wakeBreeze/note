create function fun_query_bkf206(paramValue in varchar2)
return varchar2
is
 returnValue varchar2(100):=null;
 numberValue number;
begin
  select count(*) into numberValue from khc5 a where a.bkf172=paramValue;
  if(numberValue>0)
  then
  select  a.bkf206 into returnValue
  from khc5 a where a.bkf172=paramValue and rownum<=1;
  return returnValue;
  end if;
  return null;
end fun_query_bkf206;


/

