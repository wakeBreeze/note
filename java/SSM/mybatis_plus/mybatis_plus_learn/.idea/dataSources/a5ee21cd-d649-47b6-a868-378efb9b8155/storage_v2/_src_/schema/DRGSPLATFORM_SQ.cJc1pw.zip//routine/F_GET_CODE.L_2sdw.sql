create FUNCTION f_get_code(param_code           in VARCHAR2,
                                      param_mzfs           IN VARCHAR2,
                                      param_AKA130         IN VARCHAR2,
                                      param_AKE304         IN VARCHAR2,
                                      param_AKC023         IN VARCHAR2,
                                      param_operation_code in VARCHAR2,
                                      param_bkf242         in VARCHAR2

                                      ) return VARCHAR2 AS
  v_operation_code VARCHAR2(1000);
  v_count          NUMBER(10); -- 编码是否存在
  v_count1         NUMBER(10); -- 编码是否存在
  v_type           VARCHAR2(1); -- 编码类型 1：除新生儿外 0：无排除

BEGIN

  -- 手术排除判断
  IF param_mzfs IN ('全身麻醉', '01', '1') OR param_AKA130 = '27' OR
     param_bkf242 = '1' THEN
    IF param_operation_code IS NOT NULL THEN
      v_operation_code := CONCAT(param_operation_code, '-');
    END IF;
    v_operation_code := concat(v_operation_code, param_code);
  ELSE
    SELECT COUNT(1) INTO v_count FROM khg3 WHERE bke739 = param_code and aaa131='0';
    SELECT COUNT(1) INTO v_count1 FROM kbf3 WHERE bke739 = param_code and aaa131='0';
    IF v_count = 0 AND v_count1 = 0 THEN
      IF param_operation_code IS NOT NULL THEN
        v_operation_code := CONCAT(param_operation_code, '-');
      END IF;
      v_operation_code := concat(v_operation_code, param_code);
    ELSIF v_count != 0 AND v_count1 = 0 THEN
      SELECT bkf259 INTO v_type FROM khg3 WHERE bke739 = param_code and aaa131='0';
      IF v_type = '1' AND param_AKE304 = '0' AND
         param_AKC023 = '0' THEN
        IF param_operation_code IS NOT NULL THEN
          v_operation_code := CONCAT(param_operation_code, '-');
        END IF;
        v_operation_code := concat(v_operation_code, param_code);
      ELSE
        v_operation_code := CONCAT(param_operation_code, NULL);
        v_operation_code := concat(v_operation_code, NULL);
      END IF;
    ELSE
      v_operation_code := CONCAT(param_operation_code, NULL);
      v_operation_code := concat(v_operation_code, NULL);
    END IF;
  END IF;

  RETURN v_operation_code;
END;
/

