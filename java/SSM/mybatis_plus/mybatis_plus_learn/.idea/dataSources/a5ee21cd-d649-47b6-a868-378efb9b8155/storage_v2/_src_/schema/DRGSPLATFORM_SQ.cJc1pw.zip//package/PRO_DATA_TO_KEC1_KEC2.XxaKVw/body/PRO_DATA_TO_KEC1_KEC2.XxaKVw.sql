create PACKAGE BODY pro_data_to_kec1_kec2 IS
/**kec1和kec2抽取
*/
  PROCEDURE pro_data IS
                     v_AppCode  VARCHAR2(10); --执行代码
                     v_ErrorMsg VARCHAR2(400);
  BEGIN
    pro_hisdata_to_kec1();
    pro_hisdata_to_kec2();
  EXCEPTION
    WHEN OTHERS THEN
      v_AppCode  := pkg_comm.def_err;
      v_ErrorMsg := '【PKG_A_Statistics.prc_execute】执行出错：' || SQLERRM;
  END pro_data;

  procedure pro_hisdata_to_kec1 IS
    v_AppCode     VARCHAR2(10); -- 错误码
    v_ErrorMsg    VARCHAR2(400); -- 错误信息
    v_repeat_flag NUMBER(10); -- 去重标志
    v_baz506      NUMBER(20); -- 住院首页ID
    v_bke139      kea3.bke139%TYPE; -- 批次号
    v_akb020_bke139      kea3.bke139%TYPE; -- 批次号
    v_bke708      NUMBER := 0; -- 病案总数
    TYPE t_yh_drg_bainfo IS TABLE OF medplatform.kec1%ROWTYPE INDEX BY BINARY_INTEGER;
    l_yh_drg_bainfo t_yh_drg_bainfo; -- 声明 bainfo 表结构一致变量
    TYPE t_akb020s IS TABLE OF tab_akb020s%ROWTYPE INDEX BY BINARY_INTEGER;
    l_akb020s t_akb020s; -- 声明 tab_akb020s 表结构一致变量
  begin
   -- SELECT AKB020,COUNT(1)
    -- 生成批次号
    SELECT se_bke139.nextval INTO v_bke139 from dual;
  
    -- 查询前60天数据（当天）
    SELECT *
      BULK COLLECT
      INTO l_yh_drg_bainfo
      FROM medplatform.kec1
     WHERE 
     --to_date(cysj, 'yyyy-MM-dd') >=
      --     to_date(to_char(SYSDATE - 180, 'yyyyMMdd'), 'yyyyMMdd')
      -- and to_date(cysj, 'yyyy-MM-dd') <=
        --   to_date(to_char(SYSDATE, 'yyyyMMdd'), 'yyyyMMdd')
        to_date(cysj,'yyyy-MM-dd') >= to_date('20200401','yyyyMMdd')
        and to_date(cysj,'yyyy-MM-dd') <= to_date('20200402','yyyyMMdd')
       and aaa131 = '0';
  
    FOR i IN 1 .. l_yh_drg_bainfo.COUNT LOOP
      -- 根据病案号医院编码和入院时间判断是否重复
      SELECT COUNT(1)
        INTO v_repeat_flag
        FROM kec1
       WHERE bah = l_yh_drg_bainfo(i).bah
         AND rysj = l_yh_drg_bainfo(i).rysj
         AND akb020 = l_yh_drg_bainfo(i).akb020;
      IF v_repeat_flag = 0 THEN
        SELECT se_baz506.nextval INTO v_baz506 from dual;
        INSERT INTO kec1
        VALUES
          (l_yh_drg_bainfo(i).username,
           l_yh_drg_bainfo(i).ylfkfs,
           l_yh_drg_bainfo(i).jkkh,
           l_yh_drg_bainfo(i).zycs,
           l_yh_drg_bainfo(i).bah,
           l_yh_drg_bainfo(i).xm,
           l_yh_drg_bainfo(i).xb,
           l_yh_drg_bainfo(i).csrq,
           l_yh_drg_bainfo(i).nl,
           l_yh_drg_bainfo(i).gj,
           l_yh_drg_bainfo(i).bzyzs_nl,
           l_yh_drg_bainfo(i).xsetz,
           l_yh_drg_bainfo(i).xserytz,
           l_yh_drg_bainfo(i).csd,
           l_yh_drg_bainfo(i).gg,
           l_yh_drg_bainfo(i).mz,
           l_yh_drg_bainfo(i).sfzh,
           l_yh_drg_bainfo(i).zy,
           l_yh_drg_bainfo(i).hy,
           l_yh_drg_bainfo(i).xzz,
           l_yh_drg_bainfo(i).dh,
           l_yh_drg_bainfo(i).yb1,
           l_yh_drg_bainfo(i).hkdz,
           l_yh_drg_bainfo(i).yb2,
           l_yh_drg_bainfo(i).gzdwjdz,
           l_yh_drg_bainfo(i).dwdh,
           l_yh_drg_bainfo(i).yb3,
           l_yh_drg_bainfo(i).lxrxm,
           l_yh_drg_bainfo(i).gx,
           l_yh_drg_bainfo(i).dz,
           l_yh_drg_bainfo(i).dh1,
           l_yh_drg_bainfo(i).rytj,
           l_yh_drg_bainfo(i).rysj,
           l_yh_drg_bainfo(i).rykb,
           l_yh_drg_bainfo(i).rybf,
           l_yh_drg_bainfo(i).zkkb,
           l_yh_drg_bainfo(i).cysj,
           l_yh_drg_bainfo(i).cykb,
           l_yh_drg_bainfo(i).cybf,
           l_yh_drg_bainfo(i).sjzy,
           l_yh_drg_bainfo(i).jbbm,
           l_yh_drg_bainfo(i).zyzd,
           l_yh_drg_bainfo(i).jbdm,
           l_yh_drg_bainfo(i).sslclj,
           l_yh_drg_bainfo(i).zyyj,
           l_yh_drg_bainfo(i).zyzlsb,
           l_yh_drg_bainfo(i).qtzd1,
           l_yh_drg_bainfo(i).bzsh,
           l_yh_drg_bainfo(i).rybq1,
           l_yh_drg_bainfo(i).zb_jbbm,
           l_yh_drg_bainfo(i).zb_rybq,
           l_yh_drg_bainfo(i).qtzd2,
           l_yh_drg_bainfo(i).xy_rybq,
           l_yh_drg_bainfo(i).rybq2,
           l_yh_drg_bainfo(i).zz_jbbm1,
           l_yh_drg_bainfo(i).zz_rybq1,
           l_yh_drg_bainfo(i).qtzd3,
           l_yh_drg_bainfo(i).rybq3,
           l_yh_drg_bainfo(i).zz_jbbm2,
           l_yh_drg_bainfo(i).zz_rybq2,
           l_yh_drg_bainfo(i).qtzd4,
           l_yh_drg_bainfo(i).rybq4,
           l_yh_drg_bainfo(i).zz_jbbm3,
           l_yh_drg_bainfo(i).zz_rybq3,
           l_yh_drg_bainfo(i).qtzd5,
           l_yh_drg_bainfo(i).rybq5,
           l_yh_drg_bainfo(i).zz_jbbm4,
           l_yh_drg_bainfo(i).zz_rybq4,
           l_yh_drg_bainfo(i).qtzd6,
           l_yh_drg_bainfo(i).rybq6,
           l_yh_drg_bainfo(i).zz_jbbm5,
           l_yh_drg_bainfo(i).zz_rybq5,
           l_yh_drg_bainfo(i).qtzd7,
           l_yh_drg_bainfo(i).rybq7,
           l_yh_drg_bainfo(i).zz_jbbm6,
           l_yh_drg_bainfo(i).zz_rybq6,
           l_yh_drg_bainfo(i).wbyy,
           l_yh_drg_bainfo(i).blzd,
           l_yh_drg_bainfo(i).zz_jbbm7,
           l_yh_drg_bainfo(i).blh,
           l_yh_drg_bainfo(i).ywgm,
           l_yh_drg_bainfo(i).gmyw,
           l_yh_drg_bainfo(i).xx,
           l_yh_drg_bainfo(i).rh,
           l_yh_drg_bainfo(i).kzr,
           l_yh_drg_bainfo(i).zrys,
           l_yh_drg_bainfo(i).zzys,
           l_yh_drg_bainfo(i).zyys,
           l_yh_drg_bainfo(i).zrhs,
           l_yh_drg_bainfo(i).jxys,
           l_yh_drg_bainfo(i).sxys,
           l_yh_drg_bainfo(i).bmy,
           l_yh_drg_bainfo(i).bazl,
           l_yh_drg_bainfo(i).zkys,
           l_yh_drg_bainfo(i).zkhs,
           l_yh_drg_bainfo(i).zkrq,
           l_yh_drg_bainfo(i).ssjczbm1,
           l_yh_drg_bainfo(i).ssjczrq1,
           l_yh_drg_bainfo(i).ssjczmc1,
           l_yh_drg_bainfo(i).sz1,
           l_yh_drg_bainfo(i).yz1,
           l_yh_drg_bainfo(i).ez1,
           l_yh_drg_bainfo(i).qkdj1,
           l_yh_drg_bainfo(i).mzfs1,
           l_yh_drg_bainfo(i).mzys1,
           l_yh_drg_bainfo(i).ssjczbm2,
           l_yh_drg_bainfo(i).ssjczrq2,
           l_yh_drg_bainfo(i).ssjczmc2,
           l_yh_drg_bainfo(i).sz2,
           l_yh_drg_bainfo(i).yz2,
           l_yh_drg_bainfo(i).ez2,
           l_yh_drg_bainfo(i).qkdj2,
           l_yh_drg_bainfo(i).mzfs2,
           l_yh_drg_bainfo(i).mzys2,
           l_yh_drg_bainfo(i).ssjczbm3,
           l_yh_drg_bainfo(i).ssjczrq3,
           l_yh_drg_bainfo(i).ssjczmc3,
           l_yh_drg_bainfo(i).sz3,
           l_yh_drg_bainfo(i).yz3,
           l_yh_drg_bainfo(i).ez3,
           l_yh_drg_bainfo(i).qkdj3,
           l_yh_drg_bainfo(i).mzfs3,
           l_yh_drg_bainfo(i).mzys3,
           l_yh_drg_bainfo(i).ssjczbm4,
           l_yh_drg_bainfo(i).ssjczrq4,
           l_yh_drg_bainfo(i).ssjczmc4,
           l_yh_drg_bainfo(i).sz4,
           l_yh_drg_bainfo(i).yz4,
           l_yh_drg_bainfo(i).ez4,
           l_yh_drg_bainfo(i).qkdj4,
           l_yh_drg_bainfo(i).mzfs4,
           l_yh_drg_bainfo(i).mzys4,
           l_yh_drg_bainfo(i).ssjczbm5,
           l_yh_drg_bainfo(i).ssjczrq5,
           l_yh_drg_bainfo(i).ssjczmc5,
           l_yh_drg_bainfo(i).sz5,
           l_yh_drg_bainfo(i).yz5,
           l_yh_drg_bainfo(i).ez5,
           l_yh_drg_bainfo(i).qkdj5,
           l_yh_drg_bainfo(i).mzfs5,
           l_yh_drg_bainfo(i).mzys5,
           l_yh_drg_bainfo(i).ssjczbm6,
           l_yh_drg_bainfo(i).ssjczrq6,
           l_yh_drg_bainfo(i).ssjczmc6,
           l_yh_drg_bainfo(i).sz6,
           l_yh_drg_bainfo(i).yz6,
           l_yh_drg_bainfo(i).ez6,
           l_yh_drg_bainfo(i).qkdj6,
           l_yh_drg_bainfo(i).mzfs6,
           l_yh_drg_bainfo(i).mzys6,
           l_yh_drg_bainfo(i).qkylb6,
           l_yh_drg_bainfo(i).yzzy_jgmc,
           l_yh_drg_bainfo(i).wsy_jgmc,
           l_yh_drg_bainfo(i).lyfs,
           l_yh_drg_bainfo(i).md,
           l_yh_drg_bainfo(i).ryq_t,
           l_yh_drg_bainfo(i).ryq_xs,
           l_yh_drg_bainfo(i).ryh_fz,
           l_yh_drg_bainfo(i).ryh_t,
           l_yh_drg_bainfo(i).ryh_xs,
           l_yh_drg_bainfo(i).ylfwf,
           l_yh_drg_bainfo(i).zfy,
           l_yh_drg_bainfo(i).zfje,
           l_yh_drg_bainfo(i).zlczf,
           l_yh_drg_bainfo(i).hlf,
           l_yh_drg_bainfo(i).qtfy,
           l_yh_drg_bainfo(i).blzdf,
           l_yh_drg_bainfo(i).yxxzdf,
           l_yh_drg_bainfo(i).lczdxmf,
           l_yh_drg_bainfo(i).fsszlxmf,
           l_yh_drg_bainfo(i).sszlf,
           l_yh_drg_bainfo(i).ssf,
           l_yh_drg_bainfo(i).kff,
           l_yh_drg_bainfo(i).zyzl,
           l_yh_drg_bainfo(i).xyf,
           l_yh_drg_bainfo(i).kjywf,
           l_yh_drg_bainfo(i).zcyf,
           l_yh_drg_bainfo(i).zcyf1,
           l_yh_drg_bainfo(i).xf,
           l_yh_drg_bainfo(i).bdblzpf,
           l_yh_drg_bainfo(i).qdblzpf,
           l_yh_drg_bainfo(i).nxyzlzpf,
           l_yh_drg_bainfo(i).xbyzlzpf,
           l_yh_drg_bainfo(i).yyclf,
           l_yh_drg_bainfo(i).qtf,
           l_yh_drg_bainfo(i).zllb,
           l_yh_drg_bainfo(i).rysj_s,
           l_yh_drg_bainfo(i).cysj_s,
           l_yh_drg_bainfo(i).mzd_zyzd,
           l_yh_drg_bainfo(i).mzzd_xyzd,
           l_yh_drg_bainfo(i).zyzljs,
           l_yh_drg_bainfo(i).zb,
           l_yh_drg_bainfo(i).zyzd_jbbm,
           l_yh_drg_bainfo(i).zz1,
           l_yh_drg_bainfo(i).zyzd_jbbm1,
           l_yh_drg_bainfo(i).zz2,
           l_yh_drg_bainfo(i).zyzd_jbbm2,
           l_yh_drg_bainfo(i).zz3,
           l_yh_drg_bainfo(i).zyzd_jbbm3,
           l_yh_drg_bainfo(i).zz4,
           l_yh_drg_bainfo(i).zyzd_jbbm4,
           l_yh_drg_bainfo(i).zz5,
           l_yh_drg_bainfo(i).zyzd_jbbm5,
           l_yh_drg_bainfo(i).zz6,
           l_yh_drg_bainfo(i).zyzd_jbbm6,
           l_yh_drg_bainfo(i).zz7,
           l_yh_drg_bainfo(i).zz_rybq7,
           l_yh_drg_bainfo(i).zyzd_jbbm7,
           l_yh_drg_bainfo(i).jbbm1,
           l_yh_drg_bainfo(i).jbbm2,
           l_yh_drg_bainfo(i).sj,
           l_yh_drg_bainfo(i).shjb1,
           l_yh_drg_bainfo(i).qkylb1,
           l_yh_drg_bainfo(i).shjb2,
           l_yh_drg_bainfo(i).qkylb2,
           l_yh_drg_bainfo(i).shjb3,
           l_yh_drg_bainfo(i).qkylb3,
           l_yh_drg_bainfo(i).shjb4,
           l_yh_drg_bainfo(i).qkylb4,
           l_yh_drg_bainfo(i).shjb5,
           l_yh_drg_bainfo(i).qkylb5,
           l_yh_drg_bainfo(i).shjb6,
           l_yh_drg_bainfo(i).zzyjh,
           l_yh_drg_bainfo(i).ryq_fz,
           l_yh_drg_bainfo(i).bzlzf,
           l_yh_drg_bainfo(i).zyblzhzf,
           l_yh_drg_bainfo(i).zdf,
           l_yh_drg_bainfo(i).zlf,
           l_yh_drg_bainfo(i).mzf,
           l_yh_drg_bainfo(i).zyl_zyzd,
           l_yh_drg_bainfo(i).zywz,
           l_yh_drg_bainfo(i).zygs,
           l_yh_drg_bainfo(i).zcyjf,
           l_yh_drg_bainfo(i).zytnzl,
           l_yh_drg_bainfo(i).zygczl,
           l_yh_drg_bainfo(i).zytszl,
           l_yh_drg_bainfo(i).zyqt,
           l_yh_drg_bainfo(i).zytstpjg,
           l_yh_drg_bainfo(i).bzss,
           l_yh_drg_bainfo(i).zyzjf,
           l_yh_drg_bainfo(i).jcyyclf,
           l_yh_drg_bainfo(i).ssycxclf,
           v_bke139,
           v_baz506,
           l_yh_drg_bainfo(i).ake554,
           l_yh_drg_bainfo(i).aae053,
           l_yh_drg_bainfo(i).akc190,
           l_yh_drg_bainfo(i).akb020,
           l_yh_drg_bainfo(i).bac001,
           l_yh_drg_bainfo(i).aaa027,
           l_yh_drg_bainfo(i).aae011,
           to_date(to_char(SYSDATE, 'yyyymmddhh24miss'), 'yyyymmddhh24miss'),
           l_yh_drg_bainfo(i).ake582,
           l_yh_drg_bainfo(i).aaa131,
           l_yh_drg_bainfo(i).ake100,
           '0',
           '0',
           l_yh_drg_bainfo(i).bke874,
           l_yh_drg_bainfo(i).bke878,
           l_yh_drg_bainfo(i).bkeb67,
           l_yh_drg_bainfo(i).bkeb68,
           l_yh_drg_bainfo(i).bkeb69,
           l_yh_drg_bainfo(i).bkec25,
           l_yh_drg_bainfo(i).bkec26,
           l_yh_drg_bainfo(i).bkec27,
           l_yh_drg_bainfo(i).aka130,
           l_yh_drg_bainfo(i).cyzgqk,
           l_yh_drg_bainfo(i).qjqk2,
           l_yh_drg_bainfo(i).qjqk1,
           l_yh_drg_bainfo(i).czzjhssj1,
           l_yh_drg_bainfo(i).czzjhssj2,
           l_yh_drg_bainfo(i).czzjhssj3,
           l_yh_drg_bainfo(i).jzzjhssj1,
           l_yh_drg_bainfo(i).jzzjhssj2,
           l_yh_drg_bainfo(i).jzzjhssj3,
           l_yh_drg_bainfo(i).zzjhbflx1,
           l_yh_drg_bainfo(i).zzjhbflx2,
           l_yh_drg_bainfo(i).zzjhbflx3,
           l_yh_drg_bainfo(i).hxjsysj);
       -- INSERT INTO KEV9 VALUES (v_baz506, l_yh_drg_bainfo(i).baz506);
        -- 累加计当前批次有多少条数据
      END IF;
    END LOOP;
    
    -- 查询 kec1
    SELECT akb020,count(1)
      BULK COLLECT
      INTO l_akb020s
      FROM kec1
     WHERE bke139 = v_bke139 group by AKB020;
     
     FOR i IN 1 .. l_akb020s.COUNT LOOP
      IF l_akb020s(i).cur_count != 0 THEN
       -- 生成医疗机构批次号
      SELECT se_bke139.nextval INTO v_akb020_bke139 from dual;
      -- 插入 kea3
      INSERT INTO kea3
      VALUES
        (se_aaz703.nextval,
         '1',
         v_akb020_bke139,
         '2',
         l_akb020s(i).cur_count,
         '0',
         null,
         null,
         null,
         '2',
         null,
         to_date(to_char(SYSDATE, 'yyyymmddhh24miss'), 'yyyymmddhh24miss'),
         to_date(to_char(SYSDATE, 'yyyymmddhh24miss'), 'yyyymmddhh24miss'),
         l_akb020s(i).akb020,
         null,
         null,
         '0');
         UPDATE KEC1 SET BKE139 = v_akb020_bke139 WHERE AKB020 = l_akb020s(i).akb020 and bke139 = v_bke139;
       END IF;
     END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      -- 错误回滚，写入日志
      rollback;
      v_AppCode  := pkg_comm.def_err;
      v_ErrorMsg := '病案数据导入错误：' || SQLERRM;
      INSERT INTO KEC_ERR
      values
        (v_AppCode,
         v_ErrorMsg,
         to_date(to_char(sysdate - 1, 'yyyy-MM-dd'), 'yyyy-MM-dd'));
  end pro_hisdata_to_kec1;

  procedure pro_hisdata_to_kec2 IS
    v_AppCode     VARCHAR2(10); -- 错误码
    v_ErrorMsg    VARCHAR2(400); -- 错误信息
    v_repeat_flag NUMBER(10); -- 去重标志
    v_baz506      NUMBER(20); -- 住院首页ID
    v_bke139      kea3.bke139%TYPE; -- 批次号
    v_akb020_bke139      kea3.bke139%TYPE; -- 批次号
    v_bke708      NUMBER := 0; -- 病案总数
    TYPE t_yh_drg_bainfo IS TABLE OF medplatform.kec2%ROWTYPE INDEX BY BINARY_INTEGER;
    l_yh_drg_bainfo t_yh_drg_bainfo; -- 声明 bainfo 表结构一致变量
    TYPE t_akb020s IS TABLE OF tab_akb020s%ROWTYPE INDEX BY BINARY_INTEGER;
    l_akb020s t_akb020s; -- 声明 tab_akb020s 表结构一致变量
  begin
  
    -- 生成批次号
    SELECT se_bke139.nextval INTO v_bke139 from dual;
  
    -- 查询前60天数据（当天）
    SELECT *
      BULK COLLECT
      INTO l_yh_drg_bainfo
      FROM medplatform.kec2
     WHERE 
    -- to_date(cysj, 'yyyy-MM-dd') >=
       --    to_date(to_char(SYSDATE - 180, 'yyyyMMdd'), 'yyyyMMdd')
     --  and to_date(cysj, 'yyyy-MM-dd') <=
       --  to_date(to_char(SYSDATE, 'yyyyMMdd'), 'yyyyMMdd')
           to_date(cysj,'yyyy-MM-dd') >= to_date('20200401','yyyyMMdd')
        and to_date(cysj,'yyyy-MM-dd') <= to_date('20200402','yyyyMMdd')
       and aaa131 = '0';
  
    FOR i IN 1 .. l_yh_drg_bainfo.COUNT LOOP
      -- 根据病案号医院编码和入院时间判断是否重复
      SELECT COUNT(1)
        INTO v_repeat_flag
        FROM kec2
       WHERE bah = l_yh_drg_bainfo(i).bah
         AND rysj = l_yh_drg_bainfo(i).rysj
         AND akb020 = l_yh_drg_bainfo(i).akb020;
      IF v_repeat_flag = 0 THEN
        SELECT se_baz506.nextval INTO v_baz506 from dual;
        INSERT INTO kec2
        VALUES
          (l_yh_drg_bainfo(i).username,
           l_yh_drg_bainfo(i).ylfkfs,
           l_yh_drg_bainfo(i).jkkh,
           l_yh_drg_bainfo(i).zycs,
           l_yh_drg_bainfo(i).bah,
           l_yh_drg_bainfo(i).xm,
           l_yh_drg_bainfo(i).xb,
           l_yh_drg_bainfo(i).csrq,
           l_yh_drg_bainfo(i).nl,
           l_yh_drg_bainfo(i).gj,
           l_yh_drg_bainfo(i).bzyzsnl,
           l_yh_drg_bainfo(i).xsecstz,
           l_yh_drg_bainfo(i).xserytz,
           l_yh_drg_bainfo(i).csd,
           l_yh_drg_bainfo(i).gg,
           l_yh_drg_bainfo(i).mz,
           l_yh_drg_bainfo(i).sfzh,
           l_yh_drg_bainfo(i).zy,
           l_yh_drg_bainfo(i).hy,
           l_yh_drg_bainfo(i).xzz,
           l_yh_drg_bainfo(i).dh,
           l_yh_drg_bainfo(i).yb1,
           l_yh_drg_bainfo(i).hkdz,
           l_yh_drg_bainfo(i).yb2,
           l_yh_drg_bainfo(i).gzdwjdz,
           l_yh_drg_bainfo(i).dwdh,
           l_yh_drg_bainfo(i).yb3,
           l_yh_drg_bainfo(i).lxrxm,
           l_yh_drg_bainfo(i).gx,
           l_yh_drg_bainfo(i).dz,
           l_yh_drg_bainfo(i).dh2,
           l_yh_drg_bainfo(i).rytj,
           l_yh_drg_bainfo(i).rysj,
           l_yh_drg_bainfo(i).rysjs,
           l_yh_drg_bainfo(i).rykb,
           l_yh_drg_bainfo(i).rybf,
           l_yh_drg_bainfo(i).zkkb,
           l_yh_drg_bainfo(i).cysj,
           l_yh_drg_bainfo(i).cysjs,
           l_yh_drg_bainfo(i).cykb,
           l_yh_drg_bainfo(i).cybf,
           l_yh_drg_bainfo(i).sjzyts,
           l_yh_drg_bainfo(i).mzzd,
           l_yh_drg_bainfo(i).jbbm,
           l_yh_drg_bainfo(i).zyzd,
           l_yh_drg_bainfo(i).jbdm,
           l_yh_drg_bainfo(i).rybq,
           l_yh_drg_bainfo(i).qtzd8,
           l_yh_drg_bainfo(i).jbdm8,
           l_yh_drg_bainfo(i).rybq8,
           l_yh_drg_bainfo(i).qtzd1,
           l_yh_drg_bainfo(i).jbdm1,
           l_yh_drg_bainfo(i).rybq1,
           l_yh_drg_bainfo(i).qtzd9,
           l_yh_drg_bainfo(i).jbdm9,
           l_yh_drg_bainfo(i).rybq9,
           l_yh_drg_bainfo(i).qtzd2,
           l_yh_drg_bainfo(i).jbdm2,
           l_yh_drg_bainfo(i).rybq2,
           l_yh_drg_bainfo(i).qtzd10,
           l_yh_drg_bainfo(i).jbdm10,
           l_yh_drg_bainfo(i).rybq10,
           l_yh_drg_bainfo(i).qtzd3,
           l_yh_drg_bainfo(i).jbdm3,
           l_yh_drg_bainfo(i).rybq3,
           l_yh_drg_bainfo(i).qtzd11,
           l_yh_drg_bainfo(i).jbdm11,
           l_yh_drg_bainfo(i).rybq11,
           l_yh_drg_bainfo(i).qtzd4,
           l_yh_drg_bainfo(i).jbdm4,
           l_yh_drg_bainfo(i).rybq4,
           l_yh_drg_bainfo(i).qtzd12,
           l_yh_drg_bainfo(i).jbdm12,
           l_yh_drg_bainfo(i).rybq12,
           l_yh_drg_bainfo(i).qtzd5,
           l_yh_drg_bainfo(i).jbdm5,
           l_yh_drg_bainfo(i).rybq5,
           l_yh_drg_bainfo(i).qtzd13,
           l_yh_drg_bainfo(i).jbdm13,
           l_yh_drg_bainfo(i).rybq13,
           l_yh_drg_bainfo(i).qtzd6,
           l_yh_drg_bainfo(i).jbdm6,
           l_yh_drg_bainfo(i).rybq6,
           l_yh_drg_bainfo(i).qtzd14,
           l_yh_drg_bainfo(i).jbdm14,
           l_yh_drg_bainfo(i).rybq14,
           l_yh_drg_bainfo(i).qtzd7,
           l_yh_drg_bainfo(i).jbdm7,
           l_yh_drg_bainfo(i).rybq7,
           l_yh_drg_bainfo(i).qtzd15,
           l_yh_drg_bainfo(i).jbdm15,
           l_yh_drg_bainfo(i).rybq15,
           l_yh_drg_bainfo(i).wbyy,
           l_yh_drg_bainfo(i).h23,
           l_yh_drg_bainfo(i).blzd,
           l_yh_drg_bainfo(i).jbmm,
           l_yh_drg_bainfo(i).blh,
           l_yh_drg_bainfo(i).ywgm,
           l_yh_drg_bainfo(i).gmyw,
           l_yh_drg_bainfo(i).swhzsj,
           l_yh_drg_bainfo(i).xx,
           l_yh_drg_bainfo(i).rh,
           l_yh_drg_bainfo(i).kzr,
           l_yh_drg_bainfo(i).zrys,
           l_yh_drg_bainfo(i).zzys,
           l_yh_drg_bainfo(i).zyys,
           l_yh_drg_bainfo(i).zrhs,
           l_yh_drg_bainfo(i).jxys,
           l_yh_drg_bainfo(i).sxys,
           l_yh_drg_bainfo(i).bmy,
           l_yh_drg_bainfo(i).bazl,
           l_yh_drg_bainfo(i).zkys,
           l_yh_drg_bainfo(i).zkhs,
           l_yh_drg_bainfo(i).zkrq,
           l_yh_drg_bainfo(i).ssjczbm1,
           l_yh_drg_bainfo(i).ssjczrq1,
           l_yh_drg_bainfo(i).ssjb1,
           l_yh_drg_bainfo(i).ssjczmc1,
           l_yh_drg_bainfo(i).sz1,
           l_yh_drg_bainfo(i).yz1,
           l_yh_drg_bainfo(i).ez1,
           l_yh_drg_bainfo(i).qkdj1,
           l_yh_drg_bainfo(i).qkyhlb1,
           l_yh_drg_bainfo(i).mzfs1,
           l_yh_drg_bainfo(i).mzys1,
           l_yh_drg_bainfo(i).ssjczbm2,
           l_yh_drg_bainfo(i).ssjczrq2,
           l_yh_drg_bainfo(i).ssjb2,
           l_yh_drg_bainfo(i).ssjczmc2,
           l_yh_drg_bainfo(i).sz2,
           l_yh_drg_bainfo(i).yz2,
           l_yh_drg_bainfo(i).ez2,
           l_yh_drg_bainfo(i).qkdj2,
           l_yh_drg_bainfo(i).qkyhlb2,
           l_yh_drg_bainfo(i).mzfs2,
           l_yh_drg_bainfo(i).mzys2,
           l_yh_drg_bainfo(i).ssjczbm3,
           l_yh_drg_bainfo(i).ssjczrq3,
           l_yh_drg_bainfo(i).ssjb3,
           l_yh_drg_bainfo(i).ssjczmc3,
           l_yh_drg_bainfo(i).sz3,
           l_yh_drg_bainfo(i).yz3,
           l_yh_drg_bainfo(i).ez3,
           l_yh_drg_bainfo(i).qkdj3,
           l_yh_drg_bainfo(i).qkyhlb3,
           l_yh_drg_bainfo(i).mzfs3,
           l_yh_drg_bainfo(i).mzys3,
           l_yh_drg_bainfo(i).ssjczbm4,
           l_yh_drg_bainfo(i).ssjczrq4,
           l_yh_drg_bainfo(i).ssjb4,
           l_yh_drg_bainfo(i).ssjczmc4,
           l_yh_drg_bainfo(i).sz4,
           l_yh_drg_bainfo(i).yz4,
           l_yh_drg_bainfo(i).ez4,
           l_yh_drg_bainfo(i).qkdj4,
           l_yh_drg_bainfo(i).qkyhlb4,
           l_yh_drg_bainfo(i).mzfs4,
           l_yh_drg_bainfo(i).mzys4,
           l_yh_drg_bainfo(i).ssjczbm5,
           l_yh_drg_bainfo(i).ssjczrq5,
           l_yh_drg_bainfo(i).ssjb5,
           l_yh_drg_bainfo(i).ssjczmc5,
           l_yh_drg_bainfo(i).sz5,
           l_yh_drg_bainfo(i).yz5,
           l_yh_drg_bainfo(i).ez5,
           l_yh_drg_bainfo(i).qkdj5,
           l_yh_drg_bainfo(i).qkyhlb5,
           l_yh_drg_bainfo(i).mzfs5,
           l_yh_drg_bainfo(i).mzys5,
           l_yh_drg_bainfo(i).ssjczbm6,
           l_yh_drg_bainfo(i).ssjczrq6,
           l_yh_drg_bainfo(i).ssjb6,
           l_yh_drg_bainfo(i).ssjczmc6,
           l_yh_drg_bainfo(i).sz6,
           l_yh_drg_bainfo(i).yz6,
           l_yh_drg_bainfo(i).ez6,
           l_yh_drg_bainfo(i).qkdj6,
           l_yh_drg_bainfo(i).qkyhlb6,
           l_yh_drg_bainfo(i).mzfs6,
           l_yh_drg_bainfo(i).mzys6,
           l_yh_drg_bainfo(i).ssjczbm7,
           l_yh_drg_bainfo(i).ssjczrq7,
           l_yh_drg_bainfo(i).ssjb7,
           l_yh_drg_bainfo(i).ssjczmc7,
           l_yh_drg_bainfo(i).sz7,
           l_yh_drg_bainfo(i).yz7,
           l_yh_drg_bainfo(i).ez7,
           l_yh_drg_bainfo(i).qkdj7,
           l_yh_drg_bainfo(i).qkyhlb7,
           l_yh_drg_bainfo(i).mzfs7,
           l_yh_drg_bainfo(i).mzys7,
           l_yh_drg_bainfo(i).lyfs,
           l_yh_drg_bainfo(i).yzzy_yljg,
           l_yh_drg_bainfo(i).wsy_yljg,
           l_yh_drg_bainfo(i).sfzzyjh,
           l_yh_drg_bainfo(i).md,
           l_yh_drg_bainfo(i).ryq_t,
           l_yh_drg_bainfo(i).ryq_xs,
           l_yh_drg_bainfo(i).ryq_f,
           l_yh_drg_bainfo(i).ryh_t,
           l_yh_drg_bainfo(i).ryh_xs,
           l_yh_drg_bainfo(i).ryh_f,
           l_yh_drg_bainfo(i).zfy,
           l_yh_drg_bainfo(i).zfje,
           l_yh_drg_bainfo(i).ylfuf,
           l_yh_drg_bainfo(i).zlczf,
           l_yh_drg_bainfo(i).hlf,
           l_yh_drg_bainfo(i).qtfy,
           l_yh_drg_bainfo(i).blzdf,
           l_yh_drg_bainfo(i).syszdf,
           l_yh_drg_bainfo(i).yxxzdf,
           l_yh_drg_bainfo(i).lczdxmf,
           l_yh_drg_bainfo(i).fsszlxmf,
           l_yh_drg_bainfo(i).wlzlf,
           l_yh_drg_bainfo(i).sszlf,
           l_yh_drg_bainfo(i).maf,
           l_yh_drg_bainfo(i).ssf,
           l_yh_drg_bainfo(i).kff,
           l_yh_drg_bainfo(i).zyzlf,
           l_yh_drg_bainfo(i).xyf,
           l_yh_drg_bainfo(i).kjywf,
           l_yh_drg_bainfo(i).zcyf,
           l_yh_drg_bainfo(i).zcyf1,
           l_yh_drg_bainfo(i).xf,
           l_yh_drg_bainfo(i).bdblzpf,
           l_yh_drg_bainfo(i).qdblzpf,
           l_yh_drg_bainfo(i).nxyzlzpf,
           l_yh_drg_bainfo(i).xbyzlzpf,
           l_yh_drg_bainfo(i).hcyyclf,
           l_yh_drg_bainfo(i).yyclf,
           l_yh_drg_bainfo(i).ycxyyclf,
           l_yh_drg_bainfo(i).qtf,
           v_bke139,
           v_baz506,
           l_yh_drg_bainfo(i).ake554,
           l_yh_drg_bainfo(i).aae053,
           l_yh_drg_bainfo(i).akc190,
           l_yh_drg_bainfo(i).akb020,
           l_yh_drg_bainfo(i).bac001,
           l_yh_drg_bainfo(i).aaa027,
           l_yh_drg_bainfo(i).aae011,
           to_date(to_char(SYSDATE, 'yyyymmddhh24miss'), 'yyyymmddhh24miss'),
           l_yh_drg_bainfo(i).ake582,
           l_yh_drg_bainfo(i).aaa131,
           l_yh_drg_bainfo(i).ake100,
           '0',
           '0',
           l_yh_drg_bainfo(i).bke874,
           l_yh_drg_bainfo(i).bke878,
           l_yh_drg_bainfo(i).bkeb67,
           l_yh_drg_bainfo(i).bkeb68,
           l_yh_drg_bainfo(i).bkeb69,
           l_yh_drg_bainfo(i).bkec25,
           l_yh_drg_bainfo(i).bkec26,
           l_yh_drg_bainfo(i).bkec27,
           l_yh_drg_bainfo(i).aka130,
           l_yh_drg_bainfo(i).cyzgqk,
           l_yh_drg_bainfo(i).qjqk2,
           l_yh_drg_bainfo(i).qjqk1);
       -- INSERT INTO KEV9 VALUES (v_baz506, l_yh_drg_bainfo(i).baz506);
        -- 累加计当前批次有多少条数据
        v_bke708 := v_bke708 + 1;
      END IF;
    END LOOP;
    -- 查询 kec1
    SELECT akb020,count(1)
      BULK COLLECT
      INTO l_akb020s
      FROM kec2
     WHERE bke139 = v_bke139 group by AKB020;
     
     FOR i IN 1 .. l_akb020s.COUNT LOOP
      IF l_akb020s(i).cur_count != 0 THEN
       -- 生成医疗机构批次号
      SELECT se_bke139.nextval INTO v_akb020_bke139 from dual;
      -- 插入 kea3
      INSERT INTO kea3
      VALUES
        (se_aaz703.nextval,
         '1',
         v_akb020_bke139,
         '1',
         l_akb020s(i).cur_count,
         '0',
         null,
         null,
         null,
         '2',
         null,
         to_date(to_char(SYSDATE, 'yyyymmddhh24miss'), 'yyyymmddhh24miss'),
         to_date(to_char(SYSDATE, 'yyyymmddhh24miss'), 'yyyymmddhh24miss'),
         l_akb020s(i).akb020,
         null,
         null,
         '0');
         UPDATE KEC2 SET BKE139 = v_akb020_bke139 WHERE AKB020 = l_akb020s(i).akb020 and bke139 = v_bke139;
       END IF;
    END LOOP;
  EXCEPTION
    WHEN OTHERS THEN
      -- 错误回滚，写入日志
      rollback;
      v_AppCode  := pkg_comm.def_err;
      v_ErrorMsg := '病案数据导入错误：' || SQLERRM;
      INSERT INTO KEC_ERR
      values
        (v_AppCode,
         v_ErrorMsg,
         to_date(to_char(sysdate - 1, 'yyyy-MM-dd'), 'yyyy-MM-dd'));
  end pro_hisdata_to_kec2;
END pro_data_to_kec1_kec2;
/

