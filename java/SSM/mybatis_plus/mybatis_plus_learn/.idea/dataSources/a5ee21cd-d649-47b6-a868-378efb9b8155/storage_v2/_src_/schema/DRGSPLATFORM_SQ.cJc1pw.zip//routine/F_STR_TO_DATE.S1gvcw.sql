create function                 F_STR_TO_DATE(str in varchar2) return date is
result VARCHAR(10);
v_date date;
begin
  CASE
    WHEN NOT regexp_like(str,'^[1-9][0-9]{3}[/|-]?((1[0-2])|(0?[1-9]))[/|-]?(([1-2][0-9])|(3[0-1])|(0?[1-9]))$')
      THEN RETURN NULL;
    WHEN INSTR(str,'/') > 0 AND length(str)-length(replace(str, '/', ''))=2
      THEN
        result := SUBSTR(str,0,INSTR(str,'/',1,1)-1)|| '-' ||
          replace(lpad(SUBSTR(str,INSTR(str,'/',1,1)+1,LENGTH(str)-INSTR(str,'/',1,2)),2),' ','0')|| '-' ||
          replace(lpad(SUBSTR(str,INSTR(str,'/',1,2)+1),2),' ','0');
    WHEN INSTR(str,'-') > 0 AND length(str)-length(replace(str, '-', ''))=2
      THEN
        result := SUBSTR(str,0,INSTR(str,'-',1,1)-1)|| '-' ||
          replace(lpad(SUBSTR(str,INSTR(str,'-',1,1)+1,LENGTH(str)-INSTR(str,'-',1,2)),2),' ','0')|| '-' ||
          replace(lpad(SUBSTR(str,INSTR(str,'-',1,2)+1),2),' ','0');
    WHEN LENGTH(str) = 8
      THEN
        result := SUBSTR(str,0,4)|| '-' ||
          replace(lpad(SUBSTR(str,5,2),2),' ','0')|| '-' ||
          replace(lpad(SUBSTR(str,7),2),' ','0');
    ELSE RETURN str;
  END CASE;
  v_date :=to_date(result,'yyyy-MM-dd');
  return v_date;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
end F_STR_TO_DATE;


/

