create procedure PRC_EXTRACT_KES5(prm_bke930 IN VARCHAR2,
                                             ExtractNum OUT NUMBER,
                                             AppCode    OUT VARCHAR2,
                                             ErrorMsg   OUT VARCHAR2) is
  v_insert_num NUMBER;

BEGIN
  insert into kes5
  (aaz828,
   baz506,
   ake554,
   akb020,
   bked12,
   bkec74,
   bkec75,
   bkec76,
   bkec77,
   bkec78,
   bkec79,
   bkec80,
   bkec81,
   bkec82,
   bkec83,
   bkec84,
   bkec85,
   bkec86,
   bkec87,
   bkec88,
   bkec89,
   bkec90,
   bkec91,
   bkec92,
   bkec93,
   bkec94,
   bkec95,
   bkec96,
   bkec97,
   bkec98,
   bkec99,
   bked01,
   bked02,
   bked03,
   bked04,
   bked05,
   bked06,
   bked07,
   bked08,
   bked09,
   bked10,
   bked11,
   bked13,
   bke139,
   aae036)
  SELECT se_aaz828.nextval,
         baz506,
         ake554,
         akb020,
         bked12,
         bkec74,
         bkec75,
         bkec76,
         bkec77,
         bkec78,
         bkec79,
         bkec80,
         bkec81,
         bkec82,
         bkec83,
         bkec84,
         bkec85,
         bkec86,
         bkec87,
         bkec88,
         bkec89,
         bkec90,
         bkec91,
         bkec92,
         bkec93,
         bkec94,
         bkec95,
         bkec96,
         bkec97,
         bkec98,
         bkec99,
         bked01,
         bked02,
         bked03,
         bked04,
         bked05,
         bked06,
         bked07,
         bked08,
         bked09,
         bked10,
         bked11,
         bked13,
         bke139,
         aae036
    from (select a.*
            FROM KES5@medplatform a
           inner join (select baz506
                        from kec1@medplatform a
                        left join kea5 b
                          on a.akc190 = b.akc190
                         and a.akb020 = b.akb020
                         and a.aaa131 = '0'
                         and b.aaa131 = '0'
                       where to_char(b.ake100, 'yyyyMM') =prm_bke930
                      union all
                      select baz506
                        from kec2@medplatform a
                        left join kea5 b
                          on a.akc190 = b.akc190
                         and a.akb020 = b.akb020
                         and a.aaa131 = '0'
                         and b.aaa131 = '0'
                       where to_char(b.ake100, 'yyyyMM') = prm_bke930) b
              on a.baz506 = b.baz506);

  v_insert_num := SQL%ROWCOUNT;
  ExtractNum   := v_insert_num;
  AppCode    := '1';

EXCEPTION
  WHEN OTHERS THEN
    AppCode  := pkg_comm.def_err;
    ErrorMsg := '抽取表KES5有误：' || SQLERRM;
    commit;
end PRC_EXTRACT_KES5;
/

