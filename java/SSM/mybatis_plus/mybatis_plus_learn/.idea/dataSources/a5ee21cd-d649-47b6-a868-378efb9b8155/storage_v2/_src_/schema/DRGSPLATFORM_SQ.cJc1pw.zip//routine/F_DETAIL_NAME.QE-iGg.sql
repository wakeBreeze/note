create FUNCTION f_detail_name(param_code in VARCHAR2)
return VARCHAR2
AS
      v_detail_name VARCHAR(1000);
      CURSOR cur_codes IS
      SELECT bkf411,bkf412 FROM (
        SELECT bkf411,bkf412,row_num
        FROM (
        SELECT regexp_substr(param_code,'[^+]+',1,ROWNUM) AS operation_code,ROWNUM AS row_num
        FROM dual
        CONNECT BY ROWNUM <= LENGTH(param_code)-LENGTH(REPLACE(param_code,'+','')) + 1
        ) a LEFT JOIN (
          SELECT bkf411,bkf412 FROM khf2 GROUP BY bkf411,bkf412
        ) b
        ON a.operation_code = b.bkf411
      ) ORDER BY row_num;
BEGIN
      FOR c IN cur_codes LOOP
         v_detail_name := CONCAT(v_detail_name,c.bkf412);
         v_detail_name := CONCAT(v_detail_name,'+');
      END LOOP;

  RETURN substr(v_detail_name,0,LENGTH(v_detail_name) - 1);
end f_detail_name;


/

