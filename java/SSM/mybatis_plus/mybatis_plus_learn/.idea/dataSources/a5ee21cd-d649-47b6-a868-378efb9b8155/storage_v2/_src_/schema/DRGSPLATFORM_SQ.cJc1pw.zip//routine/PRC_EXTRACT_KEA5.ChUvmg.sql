create procedure PRC_EXTRACT_KEA5(prm_bke930 IN VARCHAR2, --抽取时间
                                             ExtractNum OUT NUMBER,
                                             AppCode    OUT VARCHAR2,
                                             ErrorMsg   OUT VARCHAR2) is
  v_insert_num  NUMBER;
  v_insert_num1 NUMBER;
BEGIN
  INSERT INTO kea5
    (aaz605, -- 结算id
     akb024, -- 清算经办机构
     akb050, -- 医药机构结算id
     akc190, -- 就诊登记号
     akb051, -- 原结算id
     bac001, -- 个人编码
     akb052, -- 人员参保关系id
     aac003, -- 姓名
     aac058, -- 人员证件类型
     aac002, -- 证件号码
     aac004, -- 性别
     aac005, -- 民族
     aac006, -- 出生日期
     akc023, -- 年龄
     akb025, -- 险种类型
     bac002, -- 人群类别
     akb026, -- 公务员标志
     akb027, -- 公务员等级
     akb028, -- 特殊人员类型
     akb029, -- 特殊人员类型等级
     akb030, -- 缴费档次
     akb031, -- 灵活就业标志
     akb032, -- 新生儿标志
     kkh152, -- 参保地编码
     aab001, -- 单位编号
     aab002, -- 单位名称
     aab003, -- 单位类型
     aab004, -- 经济类型
     aab005, -- 所属行业
     aab006, -- 隶属关系
     aab007, -- 单位管理类型
     aab008, -- 支付地点类别
     akb020, -- 医疗服务机构编号
     akb021, -- 定点医药机构名称
     aka101, -- 医院等级
     baa001, -- 分中心
     akb035, -- 限价医院等级
     akb036, -- 起付线医院等级
     bkc009, -- 入院日期
     bkc010, -- 出院日期
     ake100, -- 结算时间
     akb037, -- 就诊凭证类型
     akb038, -- 就诊凭证编号
     aka130, -- 医疗类别
     aka030, -- 结算类别
     akb039, -- 清算类别
     akb040, -- 清算方式
     akb041, -- 个人结算方式
     akc264, -- 医疗费总额
     ake051, -- 全自费金额
     bkc040, -- 超限自付金额
     akb053, -- 先行自付金额
     bkc027, -- 符合报销范围金额
     akc270, -- 起付标准
     akc271, -- 本次起付线
     akc272, -- 实际支付起付线
     ake039, -- 基本医疗基金支出
     bkc030, -- 基本医疗统筹支付比例
     akc266, -- 医保认可费用总额
     ake035, -- 公务员补助基金支出
     aaa113, -- 补充医疗保险基金支出
     bkf160, -- "救助金支付"
     bkf159, -- "补充保险支付费用"
     akc273, -- 伤残人员医疗保障基金支出
     bkf158, -- 民政补助支付
     ake072, -- 其他基金支出(除基本医疗基金支出、大额医疗基金支出、自付金额以外的基金支出)
     akc274, -- 基金支付总额
     bkf161, -- 个人自付（个人账户支出+个人现金支出）
     ake034, -- 个人账户支出
     bkf246, -- 个人现金支出
     bkf244, -- 医院垫付
     akb043, -- 余额
     akb044, -- 账户共济支付金额
     akb045, -- 退费结算标志
     akb046, -- 计算住院次数标志
     akb047, -- 结算现金支付方式
     kkh003, -- 年度
     bkeh39, -- 病种编号
     bkeh40, -- 病种名称
     kkh145, -- 发票号
     akb048, -- 零星报销原因
     aaa131, -- 撤销标志
     aae013, -- 备注
     oae001, -- 数据唯一记录号
     bkf268, -- 数据更新时间
     aaa104, -- 创建人id
     aaa105, -- 创建人姓名
     aaa106, -- 数据创建时间
     aaa107, -- 创建机构编号
     aae413, -- 经办人id
     aae011, -- 经办人姓名
     aae036, -- 经办时间
     aaa108, -- 经办机构编号
     aaa027, -- 统筹区
     akc236, -- 中途结算标志
     aaa109, -- 账户使用标志
     aaa110, -- 编制类型
     aaa111, -- 按病种结算支付金额
     aaa112, -- 除外项目基金支付金额
     ake029, -- 大额医疗基金支出
     bkf245, -- 人寿直付赔付金额
     bkel28, -- 大病保险
     bke746, -- 测算类型(1:病种，2:异地，3:自费(二乙离休))
     ake073, --  其它基金支付)
     ake026, -- 企业补充医疗基金支出
     bkc037) --医疗照顾人员补助基金支出
    SELECT setl_id, -- 结算id
           clr_optins, -- 清算经办机构
           medins_setl_id, -- 医药机构结算id
           mdtrt_id, -- 就诊登记号
           init_setl_id, -- 原结算id
           substr(PSN_NO, -10), -- 个人编码
           psn_insu_rlts_id, -- 人员参保关系id
           psn_name, -- 姓名
           psn_cert_type, -- 人员证件类型
           certno, -- 证件号码
           gend, -- 性别
           naty, -- 民族
           brdy, -- 出生日期
           age, -- 年龄
           insutype, -- 险种类型
           CASE
             WHEN insutype = '390' THEN
              '2'
             ELSE
              '1'
           END, -- 人群类别
           cvlserv_flag, -- 公务员标志
           cvlserv_lv, -- 公务员等级
           sp_psn_type, -- 特殊人员类型
           sp_psn_type_lv, -- 特殊人员类型等级
           clct_grde, -- 缴费档次
           flxempe_flag, -- 灵活就业标志
           nwb_flag, -- 新生儿标志
           insu_admdvs, -- 参保地编码
           emp_no, -- 单位编号
           emp_name, -- 单位名称
           emp_type, -- 单位类型
           econ_type, -- 经济类型
           afil_indu, -- 所属行业
           afil_rlts, -- 隶属关系
           emp_mgt_type, -- 单位管理类型
           pay_loc, -- 支付地点类别
           CASE
             WHEN b.akb020 IS NULL THEN
              a.fixmedins_code
             ELSE
              b.akb020
           END, -- 医疗服务机构编号
           CASE
             WHEN b.akb021 IS NULL THEN
              a.fixmedins_name
             ELSE
              b.akb021
           END, -- 定点医药机构名称
           hosp_lv, -- 医院等级
           CASE
             WHEN b.baa001 IS NOT NULL THEN
              b.baa001
             ELSE
              a.fix_blng_admdvs
           END, -- 分中心
           lmtpric_hosp_lv, -- 限价医院等级
           dedc_hosp_lv, -- 起付线医院等级
           begndate, -- 入院日期
           enddate, -- 出院日期
           setl_time, -- 结算时间
           mdtrt_cert_type, -- 就诊凭证类型
           mdtrt_cert_no, -- 就诊凭证编号
           case
             when med_type = '28' then
              '27'
             else
              med_type
           end med_type, -- 医疗类别
           setl_type, -- 结算类别
           clr_type, -- 清算类别
           clr_way, -- 清算方式
           psn_setlway, -- 个人结算方式
           medfee_sumamt, -- 医疗费总额
           fulamt_ownpay_amt, -- 全自费金额
           overlmt_selfpay, -- 超限自付金额
           preselfpay_amt, -- 先行自付金额
           inscp_amt, -- 符合报销范围金额
           dedc_std, -- 起付标准
           crt_dedc, -- 本次起付线
           act_pay_dedc, -- 实际支付起付线
           hifp_pay, -- 基本医疗基金支出
           pool_prop_selfpay, -- 基本医疗统筹支付比例
           hi_agre_sumfee, -- 医保认可费用总额
           cvlserv_pay, -- 公务员补助基金支出
           hifes_pay, -- 补充医疗保险基金支出
           hifmi_pay, -- "救助金支付"
           hifob_pay, -- "补充保险支付费用"
           hifdm_pay, -- 伤残人员医疗保障基金支出
           maf_pay, -- 民政补助支付
           nvl(cvlserv_pay, 0) + nvl(hifes_pay, 0) + nvl(hifmi_pay, 0) +
           nvl(hifob_pay, 0) + nvl(hifdm_pay, 0) + nvl(maf_pay, 0) +
           nvl(othfund_pay, 0) + nvl(ownpay_hosp_part, 0), -- 其他基金支出(除基本医疗基金支出、大额医疗基金支出、自付金额以外的基金支出)
           fund_pay_sumamt, -- 基金支付总额
           psn_pay, -- 个人自付（个人账户支出+个人现金支出）
           acct_pay, -- 个人账户支出
           cash_payamt, -- 个人现金支出
           ownpay_hosp_part, -- 医院垫付
           balc, -- 余额
           acct_mulaid_pay, -- 账户共济支付金额
           refd_setl_flag, -- 退费结算标志
           cal_ipt_cnt, -- 计算住院次数标志
           setl_cashpay_way, -- 结算现金支付方式
           YEAR, -- 年度
           dise_no, -- 病种编号
           dise_name, -- 病种名称
           invono, -- 发票号
           manl_reim_rea, -- 零星报销原因
           CASE
             WHEN vali_flag = '1' THEN
              '0'
             ELSE
              '1'
           END, -- 撤销标志
           memo, -- 备注
           rid, -- 数据唯一记录号
           updt_time, -- 数据更新时间
           crter_id, -- 创建人id
           crter_name, -- 创建人姓名
           crte_time, -- 数据创建时间
           crte_optins_no, -- 创建机构编号
           opter_id, -- 经办人id
           opter_name, -- 经办人姓名
           opt_time, -- 经办时间
           optins_no, -- 经办机构编号
           poolarea_no, -- 统筹区
           mid_setl_flag, -- 中途结算标志
           acct_used_flag, -- 账户使用标志
           quts_type, -- 编制类型
           bydise_setl_payamt, -- 按病种结算支付金额
           exct_item_fund_payamt, -- 除外项目基金支付金额
           NULL, -- 大额医疗基金支出
           NULL, -- 人寿直付赔付金额
           NULL, -- 大病保险
           CASE
             WHEN psn_type IN ('13', '1300') THEN
              '3'
             ELSE
              CASE
                WHEN pay_loc IN ('3', '4') THEN
                 '2'
                ELSE
                 '1'
              END
           END, -- 测算类型(1:病种，2:异地，3:自费(二乙离休))
           othfund_pay, --  其它基金支付)
           NULL, -- 企业补充医疗基金支出
           NULL --医疗照顾人员补助基金支出
      FROM data_sync.setl_d_hosp a
     INNER JOIN kb01 b
        ON a.fixmedins_code = b.bkf498
     WHERE med_type IN ('21', '22', '52', '5302', '28') --医疗类别(21:普通住院,22:外伤住院,52:生育住院,5302:计划生育住院,9905:床日住院)
       AND refd_setl_flag = '0' --退费标志(0:未退费,1:退费)
       AND vali_flag = '1' --有效标志
       AND pay_loc = 2 --支付地点类别(1:中心,2:医院,3:省内异地,4:省外异地)
       AND setl_type = 2 --结算类别(1:中心报销,2:联网结算,3:补充报销)
       AND clr_type = 21 --清算类别(11:门诊,21:住院,41:药店,51:暂缓)
       AND to_char(setl_time, 'yyyyMM') = prm_bke930; --结算时间
  v_insert_num := SQL%ROWCOUNT;

  INSERT INTO kea5
    (aaz605, -- 结算id
     akb024, -- 清算经办机构
     akb050, -- 医药机构结算id
     akc190, -- 就诊登记号
     akb051, -- 原结算id
     bac001, -- 个人编码
     akb052, -- 人员参保关系id
     aac003, -- 姓名
     aac058, -- 人员证件类型
     aac002, -- 证件号码
     aac004, -- 性别
     aac005, -- 民族
     aac006, -- 出生日期
     akc023, -- 年龄
     akb025, -- 险种类型
     bac002, -- 人群类别
     akb026, -- 公务员标志
     akb027, -- 公务员等级
     akb028, -- 特殊人员类型
     akb029, -- 特殊人员类型等级
     akb030, -- 缴费档次
     akb031, -- 灵活就业标志
     akb032, -- 新生儿标志
     kkh152, -- 参保地编码
     aab001, -- 单位编号
     aab002, -- 单位名称
     aab003, -- 单位类型
     aab004, -- 经济类型
     aab005, -- 所属行业
     aab006, -- 隶属关系
     aab007, -- 单位管理类型
     aab008, -- 支付地点类别
     akb020, -- 医疗服务机构编号
     akb021, -- 定点医药机构名称
     aka101, -- 医院等级
     baa001, -- 分中心
     akb035, -- 限价医院等级
     akb036, -- 起付线医院等级
     bkc009, -- 入院日期
     bkc010, -- 出院日期
     ake100, -- 结算时间
     akb037, -- 就诊凭证类型
     akb038, -- 就诊凭证编号
     aka130, -- 医疗类别
     aka030, -- 结算类别
     akb039, -- 清算类别
     akb040, -- 清算方式
     akb041, -- 个人结算方式
     akc264, -- 医疗费总额
     ake051, -- 全自费金额
     bkc040, -- 超限自付金额
     akb053, -- 先行自付金额
     bkc027, -- 符合报销范围金额
     akc270, -- 起付标准
     akc271, -- 本次起付线
     akc272, -- 实际支付起付线
     ake039, -- 基本医疗基金支出
     bkc030, -- 基本医疗统筹支付比例
     akc266, -- 医保认可费用总额
     ake035, -- 公务员补助基金支出
     aaa113, -- 补充医疗保险基金支出
     bkf160, -- "救助金支付"
     bkf159, -- "补充保险支付费用"
     akc273, -- 伤残人员医疗保障基金支出
     bkf158, -- 民政补助支付
     ake072, -- 其他基金支出(除基本医疗基金支出、大额医疗基金支出、自付金额以外的基金支出)
     akc274, -- 基金支付总额
     bkf161, -- 个人自付（个人账户支出+个人现金支出）
     ake034, -- 个人账户支出
     bkf246, -- 个人现金支出
     bkf244, -- 医院垫付
     akb043, -- 余额
     akb044, -- 账户共济支付金额
     akb045, -- 退费结算标志
     akb046, -- 计算住院次数标志
     akb047, -- 结算现金支付方式
     kkh003, -- 年度
     bkeh39, -- 病种编号
     bkeh40, -- 病种名称
     kkh145, -- 发票号
     akb048, -- 零星报销原因
     aaa131, -- 撤销标志
     aae013, -- 备注
     oae001, -- 数据唯一记录号
     bkf268, -- 数据更新时间
     aaa104, -- 创建人id
     aaa105, -- 创建人姓名
     aaa106, -- 数据创建时间
     aaa107, -- 创建机构编号
     aae413, -- 经办人id
     aae011, -- 经办人姓名
     aae036, -- 经办时间
     aaa108, -- 经办机构编号
     aaa027, -- 统筹区
     akc236, -- 中途结算标志
     aaa109, -- 账户使用标志
     aaa110, -- 编制类型
     aaa111, -- 按病种结算支付金额
     aaa112, -- 除外项目基金支付金额
     ake029, -- 大额医疗基金支出
     bkf245, -- 人寿直付赔付金额
     bkel28, -- 大病保险
     bke746, -- 测算类型(1:病种，2:异地，3:自费(二乙离休))
     ake073, --  其它基金支付)
     ake026, -- 企业补充医疗基金支出
     bkc037) --医疗照顾人员补助基金支出
    SELECT setl_id,
           clr_optins,
           medins_setl_id,
           mdtrt_id,
           init_setl_id,
           psn_no,
           psn_insu_rlts_id,
           psn_name,
           psn_cert_type,
           certno,
           gend,
           naty,
           brdy,
           age,
           insutype,
           CASE
             WHEN insutype = '390' THEN
              '2'
             ELSE
              '1'
           END,
           cvlserv_flag,
           cvlserv_lv,
           sp_psn_type,
           sp_psn_type_lv,
           clct_grde,
           flxempe_flag,
           nwb_flag,
           insu_admdvs,
           emp_no,
           emp_name,
           emp_type,
           econ_type,
           afil_indu,
           afil_rlts,
           emp_mgt_type,
           pay_loc,
           CASE
             WHEN b.akb020 IS NULL THEN
              a.fixmedins_code
             ELSE
              b.akb020
           END,
           CASE
             WHEN b.akb021 IS NULL THEN
              a.fixmedins_name
             ELSE
              b.akb021
           END,
           hosp_lv,
           CASE
             WHEN b.baa001 IS NOT NULL THEN
              b.baa001
             ELSE
              a.fix_blng_admdvs
           END,
           lmtpric_hosp_lv,
           dedc_hosp_lv,
           begndate,
           enddate,
           setl_time,
           mdtrt_cert_type,
           mdtrt_cert_no,
           case
             when med_type = '28' then
              '27'
             else
              med_type
           end as med_type,
           setl_type,
           clr_type,
           clr_way,
           psn_setlway,
           medfee_sumamt,
           fulamt_ownpay_amt,
           overlmt_selfpay,
           preselfpay_amt,
           inscp_amt,
           dedc_std,
           crt_dedc,
           act_pay_dedc,
           hifp_pay,
           pool_prop_selfpay,
           hi_agre_sumfee,
           cvlserv_pay,
           hifes_pay,
           hifmi_pay,
           hifob_pay,
           hifdm_pay,
           maf_pay,
           nvl(cvlserv_pay, 0) + nvl(hifes_pay, 0) + nvl(hifmi_pay, 0) +
           nvl(hifob_pay, 0) + nvl(hifdm_pay, 0) + nvl(maf_pay, 0) +
           nvl(othfund_pay, 0) + nvl(ownpay_hosp_part, 0),
           fund_pay_sumamt,
           psn_pay,
           acct_pay,
           cash_payamt,
           ownpay_hosp_part,
           balc,
           acct_mulaid_pay,
           refd_setl_flag,
           cal_ipt_cnt,
           setl_cashpay_way,
           YEAR,
           dise_no,
           dise_name,
           invono,
           manl_reim_rea,
           CASE
             WHEN vali_flag = '1' THEN
              '0'
             ELSE
              '1'
           END,
           memo,
           rid,
           updt_time,
           crter_id,
           crter_name,
           crte_time,
           crte_optins_no,
           opter_id,
           opter_name,
           opt_time,
           optins_no,
           poolarea_no,
           null,
           null,
           null,
           null,
           null,
           NULL,
           NULL,
           NULL,
           CASE
             WHEN psn_type IN ('13', '1300') THEN
              '3'
             ELSE
              CASE
                WHEN pay_loc IN ('3', '4') THEN
                 '2'
                ELSE
                 '1'
              END
           END,
           othfund_pay,
           NULL,
           NULL
      FROM data_sync.outmed_setl_d a
     INNER JOIN drgsplatform_sq.kb01 b
        ON a.fixmedins_code = b.bkf498
     WHERE med_type IN ('21', '2301', '2302','52') --医疗类别(21:普通住院,2301:转外住院,2302:异地就医)
       AND refd_setl_flag = '0' --退费标志(0:未退费,1:退费)
       AND vali_flag = '1' --有效标志
       AND pay_loc != 1 --支付地点类别(1:中心,2:医院,3:省内异地,4:省外异地)
       AND clr_type = 21 --清算类别(11:门诊,21:住院,41:药店,51:暂缓)
       and to_char(setl_time, 'yyyymm') = prm_bke930;
  v_insert_num1 := SQL%ROWCOUNT;
  ExtractNum    := (v_insert_num + v_insert_num1);
  AppCode    := '1';

EXCEPTION
  WHEN OTHERS THEN
    AppCode  := pkg_comm.def_err;
    ErrorMsg := '抽取表KEA5有误：' || SQLERRM;
    commit;
end PRC_EXTRACT_KEA5;
/

