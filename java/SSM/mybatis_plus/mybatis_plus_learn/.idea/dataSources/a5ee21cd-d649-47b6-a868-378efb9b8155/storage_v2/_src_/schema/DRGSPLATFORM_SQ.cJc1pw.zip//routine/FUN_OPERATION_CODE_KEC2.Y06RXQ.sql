create function fun_operation_code_kec2
return number
is
PRAGMA AUTONOMOUS_TRANSACTION;
cursor cur is select baz506, SSJCZBM1,  SSJCZBM2,  SSJCZBM3, SSJCZBM4,  SSJCZBM5, SSJCZBM6  from kec2;
tempValue varchar2(100);
begin
FOR v_kec1_record IN cur
 LOOP
  IF (v_kec1_record.SSJCZBM1 is not null)
      THEN
        tempValue:=fun_query_bkf206(v_kec1_record.SSJCZBM1);
        if( tempValue is not null)
        then
           UPDATE kec2
             SET SSJCZBM1=tempValue
           WHERE baz506=v_kec1_record.baz506;
        end if;
    END IF;
    IF (v_kec1_record.SSJCZBM2 is not null)
      THEN
        tempValue:=fun_query_bkf206(v_kec1_record.SSJCZBM2);
        if(tempValue is not null)
        then
           UPDATE kec2
             SET SSJCZBM2=tempValue
           WHERE baz506=v_kec1_record.baz506;
        end if;
    END IF;
    IF ( v_kec1_record.SSJCZBM3 is not null)
      THEN
        tempValue:=fun_query_bkf206(v_kec1_record.SSJCZBM3);
        if( tempValue is not null)
        then
           UPDATE kec2
             SET SSJCZBM3=tempValue
           WHERE baz506=v_kec1_record.baz506;
        end if;
    END IF;
    IF ( v_kec1_record.SSJCZBM4 is not null)
      THEN
        tempValue:=fun_query_bkf206(v_kec1_record.SSJCZBM4);
        if(tempValue is not null)
        then
           UPDATE kec2
             SET SSJCZBM4=tempValue
           WHERE baz506=v_kec1_record.baz506;
        end if;
    END IF;
    IF ( v_kec1_record.SSJCZBM5 is not null)
      THEN
        tempValue:=fun_query_bkf206(v_kec1_record.SSJCZBM5);
        if( tempValue is not null)
        then
           UPDATE kec2
             SET SSJCZBM5=tempValue
           WHERE baz506=v_kec1_record.baz506;
        end if;
    END IF;
    IF ( v_kec1_record.SSJCZBM6 is not null)
      THEN
        tempValue:=fun_query_bkf206(v_kec1_record.SSJCZBM6);
        if( tempValue is not null)
        then
           UPDATE kec2
             SET SSJCZBM6=tempValue
           WHERE baz506=v_kec1_record.baz506;
        end if;
    END IF;
 END LOOP;
  COMMIT;
 return 0;
end fun_operation_code_kec2;


/

