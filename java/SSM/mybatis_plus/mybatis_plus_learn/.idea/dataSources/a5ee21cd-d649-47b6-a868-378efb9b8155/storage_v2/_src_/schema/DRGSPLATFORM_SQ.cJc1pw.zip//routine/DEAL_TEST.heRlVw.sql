create procedure deal_test is

BEGIN
  UPDATE kea3 SET aaa131 = 0 WHERE aaz703 IN (
  SELECT aaz703 FROM (
  SELECT aaz703 FROM kea3 WHERE aaa131 = 1) WHERE ROWNUM < 5);
  COMMIT;
END;
/

