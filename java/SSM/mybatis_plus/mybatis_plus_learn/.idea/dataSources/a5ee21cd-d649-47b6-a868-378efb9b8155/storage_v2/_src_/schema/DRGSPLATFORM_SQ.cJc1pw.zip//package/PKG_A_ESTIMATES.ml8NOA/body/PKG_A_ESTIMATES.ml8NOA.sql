create PACKAGE BODY pkg_a_estimates
/******************************************************************************/
/*  程序包名 : pkg_a_estimates                                               */
/*  业务环节 : DRG数据测算                                                 */
/*  对象列表 : 私有过程函数                                                   */
/*             ---------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*             公用过程函数                                                   */
/*             ---------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/******************************************************************************/
/*  其它说明 :                                                                */
/*  完成日期 :                                                                */
/*  版本编号 : Ver 1.0                                                        */
/*  审 查 人 : ×××                      审查日期 : YYYY-MM-DD                 */
/******************************************************************************/
 IS

   /*-------------------------------------------------------------------------*/
   /* 公用全局数据类型声明                                                    */
   /*-------------------------------------------------------------------------*/
   /*-------------------------------------------------------------------------*/
   /* 公用全局常量声明                                                        */
   /*-------------------------------------------------------------------------*/
   /*-------------------------------------------------------------------------*/
   /* 公用全局变量声明                                                        */
   /*-------------------------------------------------------------------------*/
   /*-------------------------------------------------------------------------*/
   /* 公用过程函数声明                                                        */
   /*-------------------------------------------------------------------------*/
   /*--------------------------------------------------------------------------
   || 业务环节 : 测算执行入口
   || 函数名称 : prc_execute
   || 功能描述 :
   || 使用场合 :
   || 参数描述 : 标识                  名称             输入输出   数据类型
   ||            ---------------------------------------------------------------
   ||           prm_type              测算类型               IN     VARCHAR2
   ||           prm_InString          输入参数               IN     VARCHAR2
   ||           Prm_OutString         输出参数               OUT     VARCHAR2
   ||           prm_appcode           执行代码               OUT     NUMBER
   ||           prm_errormsg           错误信息              OUT     VARCHAR2
   ||            ---------------------------------------------------------------
   ||
   || 其它说明 :测算类型 ：1 总费用 | 2 基金费用 3  |总额预算费用

   || 作    者 :raogm
   || 完成日期 :2018-12-13
   ||---------------------------------------------------------------------------
   ||                                 修改记录
   ||---------------------------------------------------------------------------
   || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
   || 修改描述 :
   ||-------------------------------------------------------------------------*/
   PROCEDURE prc_execute(prm_type      IN VARCHAR2, --测算类型
                         prm_InString  IN VARCHAR2,
                         Prm_OutString OUT VARCHAR2,
                         prm_appcode   OUT NUMBER, --执行代码
                         prm_errormsg  OUT VARCHAR2) --错误信息
    IS
      --变量定义
   BEGIN
      /* 变量初始化 */
      prm_appcode  := pkg_comm.def_ok;
      prm_errormsg := NULL;
      IF prm_type = '3' THEN
         prc_totalAmountControl(prm_type, --测算类型
                                prm_InString, --输入参数
                                Prm_OutString, --输出参数
                                prm_appcode, --执行代码
                                prm_errormsg); --错误信息
         IF prm_appcode != pkg_comm.def_ok THEN
            RETURN;
         END IF;
      ELSE
         NULL;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
         prm_appcode  := pkg_comm.def_err;
         prm_errormsg := '【pkg_a_estimates.prc_execute】执行出错：' || SQLERRM;
   END prc_execute;

   /*--------------------------------------------------------------------------
   || 业务环节 : 总控测算
   || 函数名称 : prc_totalAmountControl
   || 功能描述 :
   || 使用场合 :
   || 参数描述 : 标识                  名称             输入输出   数据类型
   ||            ---------------------------------------------------------------
   ||           prm_type              测算类型               IN     VARCHAR2
   ||           prm_InString          输入参数               IN     VARCHAR2
   ||           Prm_OutString         输出参数               OUT     VARCHAR2
   ||           prm_appcode           执行代码               OUT     NUMBER
   ||           prm_errormsg           错误信息              OUT     VARCHAR2
   ||            ---------------------------------------------------------------
   ||
   || 其它说明 :测算类型 ：1 总费用 | 2 基金费用 3  |总额预算费用

   || 作    者 :raogm
   || 完成日期 :2018-12-13
   ||---------------------------------------------------------------------------
   ||                                 修改记录
   ||---------------------------------------------------------------------------
   || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
   || 修改描述 :
   --单病种基金占比取该医疗机构单病种基金支出占全市单病种基金支出比例（修改于2018-12-20）
   --基金增长率算上当前年度（修改于2018-12-24）
   ||-------------------------------------------------------------------------*/
   PROCEDURE prc_totalAmountControl(prm_type      IN VARCHAR2, --测算类型
                                    prm_InString  IN VARCHAR2, --输入参数
                                    Prm_OutString OUT VARCHAR2, --输出参数
                                    prm_appcode   OUT NUMBER, --执行代码
                                    prm_errormsg  OUT VARCHAR2) --错误信息
    IS
      --变量定义
      d_sysdate DATE; --系统时间
      n_aae001  VARCHAR2(4); --当前年度
      n_count   NUMBER(8); --计数器
      --全市年度参考值(临时变量)
      n_akc264_all NUMBER(16, 2); --医疗费总额
      n_bkc135_all NUMBER(16, 2); --医疗机构负担金额
      n_bkb001_all NUMBER(8); --人次
      n_bke938_all NUMBER(16, 2); --基金支出
      n_BKE957_all NUMBER(16, 2); --全口径基金支出
      --年度差值(临时变量)
      n_akc264_other     NUMBER(16, 2); --本医院医疗费总额
      n_BKB001_other     NUMBER(8); --本医院人次
      n_BKE938_other     NUMBER(16, 2); --本医院基金支出
      n_akc264_other_all NUMBER(16, 2); --全市医疗费总额
      n_BKB001_other_all NUMBER(8); --全市人次
      n_BKE938_other_all NUMBER(16, 2); --全市基金支出
      --全市当前年度预估值(临时变量)
      n_akc264_cur_all NUMBER(16, 2); --当前年度预估医疗费总额
      n_BKB001_cur_all NUMBER(8); --当前年度预估人次
      n_BKE938_cur_all NUMBER(16, 2); --当前年度预估基金支出
      --年度值(临时变量)
      n_BKE935_nd NUMBER(16, 2); --次均住院费用
      n_BKB001_nd NUMBER(8); --人次
      n_BKE938_nd NUMBER(16, 2); --基金支出
      --当前年度增长率
      n_BKE936 NUMBER(16, 4); --费用增长率
      n_BKE937 NUMBER(16, 4); --人次增长率
      n_BKE939 NUMBER(16, 4); --基金支出增长率
      --游标变量
      rec_ked7         KED7%ROWTYPE; --KED7(医疗机构预算额度测算事件表)
      rec_ked8         KED8%ROWTYPE; --KED8(医疗机构预算额度测算过程表)
      rec_keD8_cur     KED8%ROWTYPE; --KED8(医疗机构预算额度测算过程表)
      rec_keD8_pre     KED8%ROWTYPE; --KED8(医疗机构预算额度测算过程表)
      rec_keD8_pre_all KED8%ROWTYPE; --KED8(医疗机构预算额度测算过程表)
      rec_ked9         KED9%ROWTYPE; --KED9(医疗机构预算额度测算明细表)
      rec_KB01         KB01%ROWTYPE; --KB01(定点医疗机构)
      CURSOR cur_ked6 IS
         SELECT AAE001, --测算年度
                MIN(AAE209) AS BKE772, --测算开始期号
                MAX(AAE209) AS BKE773, --测算终止期号
                SUM(nvl(AKC264, 0)) AS AKC264, --医疗费总额
                SUM(nvl(BKC135, 0)) AS BKC135, --医疗机构负担金额
                SUM(nvl(BKB001, 0)) AS BKB001, --人次
                SUM(CASE
                       WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '1' THEN
                        nvl(AKE039, 0) --基本医疗基金支出
                       WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '2' THEN
                        nvl(AKE029, 0) --大额医疗基金支出
                       WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '3' THEN
                        nvl(AKE039, 0) + nvl(AKE029, 0) --基本医疗基金支出 +大额医疗基金支出
                       WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '1' THEN
                        nvl(BKB006, 0) --结算基本医疗基金实际支出
                       WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '2' THEN
                        nvl(BKB007, 0) --结算大额医疗基金实际支出
                       WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '3' THEN
                        nvl(BKB007, 0) + nvl(BKB007, 0) --结算大额医疗基金实际支出
                       ELSE
                        0
                    END) AS BKE938
           FROM KED6 --KED6(医疗机构费用结算台账表)
          WHERE BAC002 = rec_KED7.BAC002
            AND AKA130 = rec_KED7.AKA130
            AND AAE209 >= rec_KED7.BKE772
            AND AAE209 <= rec_KED7.BKE773
            AND (bke969 = rec_KED7.BKE969 OR rec_KED7.BKE969 IS NULL) --单病种标志
            AND NVL(AAA131, '0') != '1'
               --试点医院
            AND (rec_KED9.BKE804 != '9' OR akb020 IN (SELECT akb020 FROM kb01 WHERE AKA022 = '1'))
               --医疗机构编号
            AND (rec_KED9.BKE804 != '4' OR akb020 = rec_KED9.AKB020)
          GROUP BY AAE001
          ORDER BY AAE001;
   BEGIN
      /* 变量初始化 */
      prm_appcode  := pkg_comm.def_ok;
      prm_errormsg := NULL;
      d_sysdate    := SYSDATE;
      n_akc264_all := 0.00; --医疗费总额
      n_bkc135_all := 0.00; --医疗机构负担金额
      n_bkb001_all := 0; --人次
      n_bke938_all := 0.00; --基金支出
      n_BKE935_nd  := 0.00; --次均住院费用
      n_BKB001_nd  := 0; --人次
      n_BKE938_nd  := 0.00; --基金支出
      n_count      := 0; --计数
      --参数检查
      IF prm_type != '3' THEN
         RETURN;
      END IF;
      --入参解析
      rec_KED7.AAE001 := pkg_comm.fun_ParseXML(prm_InString, 'aae001'); --预算年度
      rec_KED7.BKE754 := pkg_comm.fun_ParseXML(prm_InString, 'bke754'); --测算批次号
      rec_KED7.BKE772 := pkg_comm.fun_ParseXML(prm_InString, 'bke772'); --测算开始期号
      rec_KED7.BKE773 := pkg_comm.fun_ParseXML(prm_InString, 'bke773'); --测算终止期号
      rec_KED7.BKE933 := pkg_comm.fun_ParseXML(prm_InString, 'bke933'); --测算数据类型
      rec_KED7.BAC002 := pkg_comm.fun_ParseXML(prm_InString, 'bac002'); --人群类别
      rec_KED7.AKA130 := pkg_comm.fun_ParseXML(prm_InString, 'aka130'); --医疗类别
      rec_KED7.BKE934 := pkg_comm.fun_ParseXML(prm_InString, 'bke934'); --基金类别
      rec_KED7.BKE941 := pkg_comm.fun_ParseXML(prm_InString, 'bke941'); --预算额度
      rec_KED7.AAE011 := pkg_comm.fun_ParseXML(prm_InString, 'aae011'); --经办人员
      rec_KED7.AAA027 := pkg_comm.fun_ParseXML(prm_InString, 'aaa027'); --统筹区
      rec_KED7.BKE969 := pkg_comm.fun_ParseXML(prm_InString, 'bke969'); --单病种标志
      rec_KED9.AKB020 := pkg_comm.fun_ParseXML(prm_InString, 'akb020'); --医疗机构编码
      rec_KED9.BKE804 := pkg_comm.fun_ParseXML(prm_InString, 'bke804'); --统计级别
      n_aae001        := TO_CHAR(ADD_MONTHS(to_date(rec_KED7.AAE001, 'yyyy'), -12), 'yyyy'); --预算年度上年度
      --获取医疗机构信息
      IF rec_KED9.BKE804 = '4' THEN
         BEGIN
            SELECT * INTO rec_KB01 FROM KB01 WHERE AKB020 = rec_KED9.AKB020;
         EXCEPTION
            WHEN OTHERS THEN
               prm_appcode  := pkg_comm.def_err;
               prm_errormsg := '查询医疗机构信息出错：' || SQLERRM;
               RETURN;
         END;
      END IF;
      --写测算事件表
      BEGIN
         SELECT * INTO rec_ked7 FROM KED7 WHERE BKE754 = rec_KED7.BKE754;
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
            rec_KED7.AAZ747 := pkg_comm.fun_GetSequence('SE_AAZ747', 0, ''); --医疗机构预算额度测算事件ID
            rec_KED7.AAE100 := '1'; --有效标志
            rec_KED7.AAE036 := d_sysdate; --经办时间
            rec_KED7.AAE013 := NULL; --备注
            INSERT INTO KED7 VALUES rec_KED7;
         WHEN OTHERS THEN
            prm_appcode  := pkg_comm.def_err;
            prm_errormsg := '查询预算额度测算事件表出错：' || SQLERRM;
            RETURN;
      END;
      --生成医疗机构预算额度测算明细ID
      rec_KED9.AAZ749 := pkg_comm.fun_GetSequence('SE_AAZ749', 0, ''); --医疗机构预算额度测算明细ID
      --KED8(医疗机构预算额度测算过程表)
      FOR rec_ked6 IN cur_ked6 LOOP
         n_count := n_count + 1;
         --获取年度全市结算信息(单病种情况取单病种对应值)
         BEGIN
            SELECT SUM(nvl(AKC264, 0)) AS AKC264, --医疗费总额
                   SUM(nvl(BKC135, 0)) AS BKC135, --医疗机构负担金额
                   SUM(nvl(BKB001, 0)) AS BKB001, --人次
                   SUM(CASE
                          WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '1' THEN
                           nvl(AKE039, 0) --基本医疗基金支出
                          WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '2' THEN
                           nvl(AKE029, 0) --大额医疗基金支出
                          WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '3' THEN
                           nvl(AKE039, 0) + nvl(AKE029, 0) --基本医疗基金支出 +大额医疗基金支出
                          WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '1' THEN
                           nvl(BKB006, 0) --结算基本医疗基金实际支出
                          WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '2' THEN
                           nvl(BKB007, 0) --结算大额医疗基金实际支出
                          WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '3' THEN
                           nvl(BKB007, 0) + nvl(BKB007, 0) --结算大额医疗基金实际支出
                          ELSE
                           0
                       END) AS BKE938
              INTO n_akc264_all,
                   n_bkc135_all,
                   n_bkb001_all,
                   n_BKE938_all
              FROM KED6 --KED6(医疗机构费用结算台账表)
             WHERE BAC002 = rec_KED7.BAC002
               AND AKA130 = rec_KED7.AKA130
               AND AAE001 = rec_KED6.aae001
               AND (bke969 = rec_KED7.BKE969 OR rec_KED7.BKE969 IS NULL) --单病种标志
               AND NVL(AAA131, '0') != '1';
         EXCEPTION
            WHEN OTHERS THEN
               prm_appcode  := pkg_comm.def_err;
               prm_errormsg := '查询医疗机构费用结算台账（全市信息）出错：' || SQLERRM;
               RETURN;
         END;
         /* IF rec_KED7.BKE969 IS NOT NULL THEN
            --单病种情况占比取全口径基金占比
            BEGIN
               SELECT SUM(CASE
                             WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '1' THEN
                              nvl(AKE039, 0) --基本医疗基金支出
                             WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '2' THEN
                              nvl(AKE029, 0) --大额医疗基金支出
                             WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '3' THEN
                              nvl(AKE039, 0) + nvl(AKE029, 0) --基本医疗基金支出 +大额医疗基金支出
                             WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '1' THEN
                              nvl(BKB006, 0) --结算基本医疗基金实际支出
                             WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '2' THEN
                              nvl(BKB007, 0) --结算大额医疗基金实际支出
                             WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '3' THEN
                              nvl(BKB007, 0) + nvl(BKB007, 0) --结算大额医疗基金实际支出
                             ELSE
                              0
                          END) AS BKE938
                 INTO n_BKE938_all
                 FROM KED6 --KED6(医疗机构费用结算台账表)
                WHERE BAC002 = rec_KED7.BAC002
                  AND AKA130 = rec_KED7.AKA130
                  AND AAE001 = rec_KED6.aae001
                  AND NVL(AAA131, '0') != '1';
            EXCEPTION
               WHEN OTHERS THEN
                  prm_appcode  := pkg_comm.def_err;
                  prm_errormsg := '查询医疗机构费用结算台账（全市信息）出错：' || SQLERRM;
                  RETURN;
            END;
         END IF;*/
         rec_KED8.AAZ748 := pkg_comm.fun_GetSequence('SE_AAZ748', 0, ''); --医疗机构预算额度测算过程ID
         rec_KED8.AAZ747 := rec_KED7.AAZ747; --医疗机构预算额度测算事件ID
         rec_KED8.AAZ749 := rec_KED9.AAZ749; --医疗机构预算额度测算明细ID
         rec_KED8.BKE754 := rec_KED7.BKE754; --测算批次号
         rec_KED8.AAE001 := rec_KED6.aae001; --测算年度
         rec_KED8.BKE772 := rec_KED6.BKE772; --测算开始期号
         rec_KED8.BKE773 := rec_KED6.BKE773; --测算终止期号
         rec_KED8.BKE933 := rec_KED7.BKE933; --测算数据类型
         rec_KED8.BAC002 := rec_KED7.BAC002; --人群类别
         rec_KED8.AKA130 := rec_KED7.AKA130; --医疗类别
         rec_KED8.BKE934 := rec_KED7.BKE934; --基金类别
         rec_KED8.AKB020 := rec_KED9.AKB020; --医疗服务机构编号
         rec_KED8.AAZ107 := rec_KB01.AAZ107; --定点医疗机构ID
         rec_KED8.AKA101 := rec_KB01.AKA101; --医院等级
         rec_KED8.BKE935 := ROUND((rec_KED6.AKC264 - rec_KED6.BKC135) / rec_KED6.BKB001, 2); --次均住院费用
         rec_KED8.BKB001 := rec_KED6.BKB001; --人次
         rec_KED8.BKE938 := rec_KED6.BKE938; --基金支出
         rec_KED8.BKE940 := round(rec_KED6.BKE938 / n_BKE938_all, 4); --基金支出占比
         rec_KED8.BKE942 := rec_KED8.BKE938 / (rec_KED6.AKC264 - rec_KED6.BKC135); --实际补偿比
         rec_KED8.AAE013 := NULL; --备注
         --年度增长率计算
         IF n_BKE935_nd IS NULL THEN
            n_BKE935_nd := rec_KED8.BKE935; --次均住院费用
         END IF;
         IF n_BKB001_nd IS NULL THEN
            n_BKB001_nd := rec_KED8.BKB001; --人次
         END IF;
         IF n_BKE938_nd IS NULL THEN
            n_BKE938_nd := rec_KED8.BKE938; --基金支出
         END IF;
         SELECT decode(n_BKE935_nd, 0, 0, round(rec_KED8.BKE935 / n_BKE935_nd, 4) - 1), --费用增长率
                decode(n_BKB001_nd, 0, 0, round(rec_KED8.BKB001 / n_BKB001_nd, 4) - 1), --人次增长率
                decode(n_BKE938_nd, 0, 0, round(rec_KED8.BKE938 / n_BKE938_nd, 4) - 1) --基金支出增长率
           INTO rec_KED8.BKE936,
                rec_KED8.BKE937,
                rec_KED8.BKE939
           FROM dual;
         --上年度值
         n_BKE935_nd := rec_KED8.BKE935; --次均住院费用
         n_BKB001_nd := rec_KED8.BKB001; --人次
         n_BKE938_nd := rec_KED8.BKE938; --基金支出
         --当前年度数据不全，增长率计算不准确，缺省为空
         IF rec_KED6.aae001 = n_aae001 AND rec_KED6.BKE773 != n_aae001 || '12' THEN
            rec_KED8.BKE936 := NULL; --费用增长率
            rec_KED8.BKE937 := NULL; --人次增长率
            rec_KED8.BKE939 := NULL; --基金支出增长率
         END IF;
         rec_KED8.BKE804 := rec_KED9.BKE804;
         INSERT INTO KED8 VALUES rec_KED8;
      END LOOP;
      IF n_count = 0 THEN
         RETURN;
      END IF;
      --取医疗机构当前年度度值(医疗机构)
      BEGIN
         SELECT *
           INTO rec_keD8_cur
           FROM KED8 --KED8(医疗机构预算额度测算过程表)
          WHERE BKE754 = rec_KED7.BKE754 --测算批次号
            AND BKE804 = rec_KED9.BKE804 --统计级别
            AND (rec_KED9.BKE804 != '4' OR akb020 = rec_KED9.AKB020) --医疗机构编号
            AND AAE001 = n_aae001; --测算年度:预算上年度=当前年度
      EXCEPTION
         WHEN no_data_found THEN
            RETURN;
         WHEN OTHERS THEN
            prm_appcode  := pkg_comm.def_err;
            prm_errormsg := '查询医疗机构预算额度测算过程（当前年度）出错：' || SQLERRM;
            RETURN;
      END;
      --取当前年度上年度值(医疗机构)
      BEGIN
         SELECT *
           INTO rec_keD8_pre
           FROM KED8 --KED8(医疗机构预算额度测算过程表)
          WHERE BKE754 = rec_KED7.BKE754 --测算批次号
            AND BKE804 = rec_KED9.BKE804 --统计级别
            AND (rec_KED9.BKE804 != '4' OR akb020 = rec_KED9.AKB020) --医疗机构编号
            AND AAE001 = TO_CHAR(ADD_MONTHS(to_date(n_aae001, 'yyyy'), -12), 'yyyy'); --测算年度:当前年度上年度
      EXCEPTION
         WHEN no_data_found THEN
            RETURN;
         WHEN OTHERS THEN
            prm_appcode  := pkg_comm.def_err;
            prm_errormsg := '查询医疗机构预算额度测算过程（当前年度上年度）出错：' || SQLERRM;
            RETURN;
      END;
      --取当前年度上年度剩余月份值(医疗机构|试点|全市-全市)
      SELECT SUM(CASE
                    WHEN rec_KED9.BKE804 = '1' THEN
                     nvl(AKC264, 0)
                    WHEN rec_KED9.BKE804 = '4' AND akb020 = rec_KED9.AKB020 THEN
                     nvl(AKC264, 0)
                    WHEN rec_KED9.BKE804 = '9' AND
                         akb020 IN (SELECT akb020 FROM kb01 WHERE AKA022 = '1') THEN
                     nvl(AKC264, 0)
                    ELSE
                     0
                 END),
             SUM(CASE
                    WHEN rec_KED9.BKE804 = '1' THEN
                     nvl(BKB001, 0)
                    WHEN rec_KED9.BKE804 = '4' AND akb020 = rec_KED9.AKB020 THEN
                     nvl(BKB001, 0)
                    WHEN rec_KED9.BKE804 = '9' AND
                         akb020 IN (SELECT akb020 FROM kb01 WHERE AKA022 = '1') THEN
                     nvl(BKB001, 0)
                    ELSE
                     0
                 END),
             SUM(CASE
                    WHEN rec_KED9.BKE804 = '1' THEN
                     CASE
                        WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '1' THEN
                         nvl(AKE039, 0) --基本医疗基金支出
                        WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '2' THEN
                         nvl(AKE029, 0) --大额医疗基金支出
                        WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '3' THEN
                         nvl(AKE039, 0) + nvl(AKE029, 0) --基本医疗基金支出 +大额医疗基金支出
                        WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '1' THEN
                         nvl(BKB006, 0) --结算基本医疗基金实际支出
                        WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '2' THEN
                         nvl(BKB007, 0) --结算大额医疗基金实际支出
                        WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '3' THEN
                         nvl(BKB007, 0) + nvl(BKB007, 0) --结算大额医疗基金实际支出
                        ELSE
                         0
                     END
                    WHEN rec_KED9.BKE804 = '4' AND akb020 = rec_KED9.AKB020 THEN
                     CASE
                        WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '1' THEN
                         nvl(AKE039, 0) --基本医疗基金支出
                        WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '2' THEN
                         nvl(AKE029, 0) --大额医疗基金支出
                        WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '3' THEN
                         nvl(AKE039, 0) + nvl(AKE029, 0) --基本医疗基金支出 +大额医疗基金支出
                        WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '1' THEN
                         nvl(BKB006, 0) --结算基本医疗基金实际支出
                        WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '2' THEN
                         nvl(BKB007, 0) --结算大额医疗基金实际支出
                        WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '3' THEN
                         nvl(BKB007, 0) + nvl(BKB007, 0) --结算大额医疗基金实际支出
                        ELSE
                         0
                     END
                    WHEN rec_KED9.BKE804 = '9' AND
                         akb020 IN (SELECT akb020 FROM kb01 WHERE AKA022 = '1') THEN
                     CASE
                        WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '1' THEN
                         nvl(AKE039, 0) --基本医疗基金支出
                        WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '2' THEN
                         nvl(AKE029, 0) --大额医疗基金支出
                        WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '3' THEN
                         nvl(AKE039, 0) + nvl(AKE029, 0) --基本医疗基金支出 +大额医疗基金支出
                        WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '1' THEN
                         nvl(BKB006, 0) --结算基本医疗基金实际支出
                        WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '2' THEN
                         nvl(BKB007, 0) --结算大额医疗基金实际支出
                        WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '3' THEN
                         nvl(BKB007, 0) + nvl(BKB007, 0) --结算大额医疗基金实际支出
                        ELSE
                         0
                     END
                    ELSE
                     0
                 END),
             SUM(nvl(AKC264, 0)) AS AKC264, --医疗费总额
             SUM(nvl(BKB001, 0)) AS BKB001, --人次
             SUM(CASE
                    WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '1' THEN
                     nvl(AKE039, 0) --基本医疗基金支出
                    WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '2' THEN
                     nvl(AKE029, 0) --大额医疗基金支出
                    WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '3' THEN
                     nvl(AKE039, 0) + nvl(AKE029, 0) --基本医疗基金支出 +大额医疗基金支出
                    WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '1' THEN
                     nvl(BKB006, 0) --结算基本医疗基金实际支出
                    WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '2' THEN
                     nvl(BKB007, 0) --结算大额医疗基金实际支出
                    WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '3' THEN
                     nvl(BKB007, 0) + nvl(BKB007, 0) --结算大额医疗基金实际支出
                    ELSE
                     0
                 END)
        INTO n_akc264_other, --本医院医疗费总额
             n_BKB001_other, --本医院人次
             n_BKE938_other, --本医院基金支出
             n_akc264_other_all, --全市医疗费总额
             n_BKB001_other_all, --全市人次
             n_BKE938_other_all --全市基金支出
        FROM KED6 --KED6(医疗机构费用结算台账表)
       WHERE BAC002 = rec_KED7.BAC002
         AND AKA130 = rec_KED7.AKA130
         AND AAE001 = TO_CHAR(ADD_MONTHS(to_date(n_aae001, 'yyyy'), -12), 'yyyy')
         AND AAE209 > TO_CHAR(ADD_MONTHS(to_date(rec_keD8_cur.BKE773, 'yyyymm'), -12), 'yyyymm')
         AND AAE209 <=
             TO_CHAR(ADD_MONTHS(to_date(rec_keD8_cur.BKE773, 'yyyymm'), -12), 'yyyy') || '12'
         AND (bke969 = rec_KED7.BKE969 OR rec_KED7.BKE969 IS NULL) --单病种标志
         AND NVL(AAA131, '0') != '1';
      --取当前年度上年度汇总值(全市)
      BEGIN
         SELECT BKB001, --人次
                BKE938 --基金支出
           INTO n_bkb001_all,
                n_BKE938_all
           FROM KED8 --KED8(医疗机构预算额度测算过程表)
          WHERE BKE754 = rec_KED7.BKE754 --测算批次号
            AND BKE804 = '1' --统计级别
            AND AAE001 = TO_CHAR(ADD_MONTHS(to_date(n_aae001, 'yyyy'), -12), 'yyyy'); --测算年度:当前年度上年度
      EXCEPTION
         WHEN no_data_found THEN
            RETURN;
         WHEN OTHERS THEN
            prm_appcode  := pkg_comm.def_err;
            prm_errormsg := '查询全市预算额度测算过程（当前年度上年度）出错：' || SQLERRM;
            RETURN;
      END;
      --全市
      BEGIN
         SELECT BKB001, --人次
                BKE938 --基金支出
           INTO n_bkb001_cur_all,
                n_BKE938_cur_all
           FROM KED8 --KED8(医疗机构预算额度测算过程表)
          WHERE BKE754 = rec_KED7.BKE754 --测算批次号
            AND BKE804 = '1' --统计级别
            AND AAE001 = n_aae001; --测算年度:当前年度上年度
      EXCEPTION
         WHEN OTHERS THEN
            prm_appcode  := pkg_comm.def_err;
            prm_errormsg := '查询全市预算额度测算过程（当前年度上年度）出错：' || SQLERRM;
            RETURN;
      END;
      --计算预算上年度预估值
      BEGIN
         rec_KED9.BKE953 := round(rec_keD8_cur.bkb001 /
                                  (1 - round(n_bkb001_other / rec_keD8_pre.bkb001, 2)),
                                  2); --预算上年度年度预估出院人次
         rec_KED9.BKE938 := round(rec_keD8_cur.BKE938 /
                                  (1 - round(n_bke938_other / rec_keD8_pre.bke938, 2)),
                                  2); --预算上年度预估基金支出
         rec_KED9.BKE957 := round(n_BKE938_cur_all /
                                  (1 - round(n_bke938_other_all / n_BKE938_all, 2)),
                                  2); --预算上年度全市预估基金支出
         n_BKE957_all    := rec_KED9.BKE957;
         --计算预算上年度增长率
         n_BKE936 := round((rec_keD8_cur.BKE935 - rec_keD8_pre.BKE935) / rec_keD8_pre.BKE935, 4); --费用增长率
         n_BKE937 := round((rec_KED9.BKE953 - rec_keD8_pre.BKB001) / rec_keD8_pre.BKB001, 4); --人次增长率
         n_BKE939 := round((rec_KED9.BKE938 - rec_keD8_pre.BKE938) / rec_keD8_pre.BKE938, 4); --基金支出增长率
      EXCEPTION
         WHEN ZERO_DIVIDE THEN
            rec_KED9.BKE953 := NULL; --预算上年度年度预估出院人次
            rec_KED9.BKE938 := NULL; --预算上年度预估基金支出
            rec_KED9.BKE957 := NULL; --预算上年度全市预估基金支出
            n_BKE957_all    := rec_KED9.BKE957;
            --计算预算上年度增长率
            n_BKE936 := 0; --费用增长率
            n_BKE937 := 0; --人次增长率
            n_BKE939 := 0; --基金支出增长率
      END;
      --计算医疗机构平均值
      SELECT round((SUM(BKE939) + n_BKE939) / (COUNT(aae001) - 1), 4), --基金支出年均增长率
             round((SUM(BKE937) + n_BKE937) / (COUNT(aae001) - 1), 4), --人次年均增长率
             round((SUM(BKE936) + n_BKE936) / (COUNT(aae001) - 1), 4) --费用年均增长率
        INTO rec_ked9.BKE939, --基金支出年均增长率
             rec_ked9.BKE954, --人次年均增长率
             rec_ked9.BKE952 --费用年均增长率
        FROM KED8 --KED8(医疗机构预算额度测算过程表)
       WHERE BKE754 = rec_KED7.BKE754 --测算批次号
         AND BKE804 = rec_KED9.BKE804 --统计级别
         AND (rec_KED9.BKE804 != '4' OR akb020 = rec_KED9.AKB020) --医疗机构编号
         AND AAE001 <= n_aae001; --测算年度:预算上年度=当前年度
      /* --单病种情况，基金占比取全口径占比
      IF rec_KED7.BKE969 IS NOT NULL THEN
         SELECT SUM(CASE
                       WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '1' THEN
                        nvl(AKE039, 0) --基本医疗基金支出
                       WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '2' THEN
                        nvl(AKE029, 0) --大额医疗基金支出
                       WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '3' THEN
                        nvl(AKE039, 0) + nvl(AKE029, 0) --基本医疗基金支出 +大额医疗基金支出
                       WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '1' THEN
                        nvl(BKB006, 0) --结算基本医疗基金实际支出
                       WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '2' THEN
                        nvl(BKB007, 0) --结算大额医疗基金实际支出
                       WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '3' THEN
                        nvl(BKB007, 0) + nvl(BKB007, 0) --结算大额医疗基金实际支出
                       ELSE
                        0
                    END)
           INTO n_BKE938_other_all --全市基金支出
           FROM KED6 --KED6(医疗机构费用结算台账表)
          WHERE BAC002 = rec_KED7.BAC002
            AND AKA130 = rec_KED7.AKA130
            AND AAE001 = TO_CHAR(ADD_MONTHS(to_date(n_aae001, 'yyyy'), -12), 'yyyy')
            AND AAE209 > TO_CHAR(ADD_MONTHS(to_date(rec_keD8_cur.BKE773, 'yyyymm'), -12), 'yyyymm')
            AND AAE209 <=
                TO_CHAR(ADD_MONTHS(to_date(rec_keD8_cur.BKE773, 'yyyymm'), -12), 'yyyy') || '12'
            AND NVL(AAA131, '0') != '1';
         --取当前年度上年度汇总值(全市)
         SELECT CASE
                   WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '1' THEN
                    SUM(nvl(AKE039, 0)) --基本医疗基金支出
                   WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '2' THEN
                    SUM(nvl(AKE029, 0)) --大额医疗基金支出
                   WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '3' THEN
                    SUM(nvl(AKE039, 0)) + SUM(nvl(AKE029, 0)) --基本医疗基金支出 +大额医疗基金支出
                   WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '1' THEN
                    SUM(nvl(BKB006, 0)) --结算基本医疗基金实际支出
                   WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '2' THEN
                    SUM(nvl(BKB007, 0)) --结算大额医疗基金实际支出
                   WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '3' THEN
                    SUM(nvl(BKB007, 0)) + SUM(nvl(BKB007, 0)) --结算大额医疗基金实际支出
                   ELSE
                    0
                END
           INTO n_BKE938_all
           FROM KED6 --KED6(医疗机构费用结算台账表)
          WHERE BAC002 = rec_KED7.BAC002
            AND AKA130 = rec_KED7.AKA130
            AND AAE001 = TO_CHAR(ADD_MONTHS(to_date(n_aae001, 'yyyy'), -12), 'yyyy')
            AND NVL(AAA131, '0') != '1';
         --取当前年度汇总值(全市)
         SELECT SUM(CASE
                       WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '1' THEN
                        nvl(AKE039, 0) --基本医疗基金支出
                       WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '2' THEN
                        nvl(AKE029, 0) --大额医疗基金支出
                       WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '3' THEN
                        nvl(AKE039, 0) + nvl(AKE029, 0) --基本医疗基金支出 +大额医疗基金支出
                       WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '1' THEN
                        nvl(BKB006, 0) --结算基本医疗基金实际支出
                       WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '2' THEN
                        nvl(BKB007, 0) --结算大额医疗基金实际支出
                       WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '3' THEN
                        nvl(BKB007, 0) + nvl(BKB007, 0) --结算大额医疗基金实际支出
                       ELSE
                        0
                    END)
           INTO n_BKE938_cur_all
           FROM KED6 --KED6(医疗机构费用结算台账表)
          WHERE BAC002 = rec_KED7.BAC002
            AND AKA130 = rec_KED7.AKA130
            AND AAE001 = n_aae001
            AND NVL(AAA131, '0') != '1';
         --计算上年度全市全口径基金预估值
         n_BKE957_all := round(n_BKE938_cur_all / (1 - round(n_bke938_other_all / n_BKE938_all, 2)),
                               2); --预算上年度全市预估基金支出
      END IF;*/
      --写医疗机构预算额度测算明细
      rec_KED9.AAZ749 := rec_KED9.AAZ749; --医疗机构预算额度测算明细ID
      rec_KED9.AAZ747 := rec_KED7.AAZ747; --医疗机构预算额度测算事件ID
      rec_KED9.AAE001 := rec_KED7.AAE001; --预算年度
      rec_KED9.BKE754 := rec_KED7.BKE754; --测算批次号
      rec_KED9.BKE933 := rec_KED7.BKE933; --测算数据类型
      rec_KED9.BAC002 := rec_KED7.BAC002; --人群类别
      rec_KED9.AKA130 := rec_KED7.AKA130; --医疗类别
      rec_KED9.BKE934 := rec_KED7.BKE934; --基金类别
      rec_KED9.AKA101 := rec_KB01.AKA101; --医院等级
      rec_KED9.AKB020 := rec_KED9.AKB020; --医疗服务机构编号
      rec_KED9.AAZ107 := rec_KB01.AAZ107; --定点医疗机构ID
      rec_KED9.BKE951 := rec_keD8_cur.BKE935; --预算上年度年度预估次均基金支出
      rec_KED9.BKE953 := rec_KED9.BKE953; --预算上年度年度预估出院人次
      rec_KED9.BKE938 := rec_KED9.BKE938; --预算上年度基金支出
      rec_KED9.BKE957 := rec_KED9.BKE957; --预算上年度全市基金支出
      rec_KED9.BKE952 := rec_KED9.BKE952; --次均费用年均增长率
      rec_KED9.BKE954 := rec_KED9.BKE954; --人次年均增长率
      rec_KED9.BKE939 := rec_KED9.BKE939; --基金支出年均增长率
      rec_KED9.BKE941 := rec_KED7.BKE941; --预算额度
      --全口径基金占比
      IF n_BKE957_all = 0 THEN
         rec_KED9.BKE940 := 0;
      ELSE
         rec_KED9.BKE940 := round(rec_KED9.BKE938 / n_BKE957_all, 4); --预算上年度预估基金支出占比
      END IF;
      rec_KED9.BKE943 := round(rec_KED9.BKE941 * rec_KED9.BKE940, 2); --按预算额度基金预测值
      rec_KED9.BKE946 := rec_KED9.BKE951; --预算年度预估次均基金支出
      rec_KED9.BKE947 := rec_KED9.BKE953 * (1 + rec_KED9.BKE954); --预算年度预估出院人次
      rec_KED9.BKE955 := round(rec_KED9.BKE946 * rec_KED9.BKE947, 2); --预算年度预估住院总费用
      rec_KED9.BKE948 := rec_keD8_cur.BKE942; --预算年度预估补偿比
      rec_KED9.BKE944 := round(rec_KED9.BKE955 * rec_KED9.BKE948, 2); --按预估补偿比基金预测值
      rec_KED9.BKE945 := rec_KED9.BKE938 * (1 + rec_KED9.BKE939); --按基金增长率基金预测值
      rec_KED9.BKE949 := round((rec_KED9.BKE943 + rec_KED9.BKE944 + rec_KED9.BKE945) / 3, 2); --基金预测平均值
      rec_KED9.BKE956 := rec_KED9.BKE949 - rec_KED9.BKE938; --统筹基金支付增长额
      IF rec_KED9.BKE948 = 0 THEN
         rec_KED9.BKE950 := 0;
      ELSE
         rec_KED9.BKE950 := round(rec_KED9.BKE949 / rec_KED9.BKE948, 2); --总费用预测值
      END IF;
      rec_KED9.AAE013 := NULL; --备注
      INSERT INTO KED9 VALUES rec_KED9;
   EXCEPTION
      WHEN OTHERS THEN
         prm_appcode  := pkg_comm.def_err;
         prm_errormsg := '【pkg_a_estimates.prc_totalAmountControl】执行出错：' || SQLERRM;
   END prc_totalAmountControl;

   /*--------------------------------------------------------------------------
   || 业务环节 : 总控占比测算
   || 函数名称 : prc_totalAmountpropControl
   || 功能描述 :
   || 使用场合 :
   || 参数描述 : 标识                  名称             输入输出   数据类型
   ||            ---------------------------------------------------------------
   ||           prm_type              测算类型               IN     VARCHAR2
   ||           prm_InString          输入参数               IN     VARCHAR2
   ||           Prm_OutString         输出参数               OUT     VARCHAR2
   ||           prm_appcode           执行代码               OUT     NUMBER
   ||           prm_errormsg           错误信息              OUT     VARCHAR2
   ||            ---------------------------------------------------------------
   ||
   || 其它说明 :

   || 作    者 :raogm
   || 完成日期 :2018-12-20
   ||---------------------------------------------------------------------------
   ||                                 修改记录
   ||---------------------------------------------------------------------------
   || 修 改 人 : ×××                  修改日期 : YYYY-MM-DD
   || 修改描述 :
   ||-------------------------------------------------------------------------*/
   PROCEDURE prc_totalAmountpropControl(prm_type      IN VARCHAR2, --测算类型
                                        prm_InString  IN VARCHAR2, --输入参数
                                        Prm_OutString OUT VARCHAR2, --输出参数
                                        prm_appcode   OUT NUMBER, --执行代码
                                        prm_errormsg  OUT VARCHAR2) --错误信息
    IS
      --变量定义
      d_sysdate    DATE; --系统时间
      n_count      NUMBER(8); --计数器
      n_basenum    NUMBER(8); --基数
      n_aae002     NUMBER(6); --开始期号
      n_sta_month  NUMBER(2); --统计月份
      n_aae030     NUMBER(8); --开始日期
      n_aae031     NUMBER(8); --终止日期
      n_bke826_pre NUMBER(16, 2); --费用总额
      n_bkb001_pre NUMBER(8); --人次
      n_bke938_pre NUMBER(16, 2); --基金支出
      rec_ked6     KED6%ROWTYPE; --KED6(医疗机构费用结算台账表)
      rec_ked7     KED7%ROWTYPE; --KED7(医疗机构预算额度测算事件表)
      rec_KEE1     KEE1%ROWTYPE; --KEE1(医疗机构预算额度占比情况表)
      rec_KEE1_pre KEE1%ROWTYPE; --KEE1(医疗机构预算额度占比情况表)
      rec_keD8     KED8%ROWTYPE; --KED8(医疗机构预算额度测算过程表)
      rec_ked9     KED9%ROWTYPE; --KED9(医疗机构预算额度测算明细表)
      CURSOR cur_ked8 IS
         SELECT BKE804,
                akb020
           FROM ked8
          WHERE BKE754 = rec_KED7.BKE754
            AND BKE804 = '1' --全市
          GROUP BY BKE804,
                   akb020
          ORDER BY BKE804,
                   akb020; -- 测算批次号
   BEGIN
      /* 变量初始化 */
      prm_appcode  := pkg_comm.def_ok;
      prm_errormsg := NULL;
      d_sysdate    := SYSDATE;
      --入参解析
      rec_KEE1.BKE754 := pkg_comm.fun_ParseXML(prm_InString, 'bke754'); --测算批次号
      rec_KEE1.BKE803 := pkg_comm.fun_ParseXML(prm_InString, 'bke803'); --类型
      --参数检查
      IF prm_type != '3' THEN
         RETURN;
      END IF;
      IF rec_KEE1.BKE754 IS NULL THEN
         prm_appcode  := pkg_comm.def_err;
         prm_errormsg := '请传入测算批次号！';
         RETURN;
      END IF;
      IF rec_KEE1.BKE803 IS NULL THEN
         prm_appcode  := pkg_comm.def_err;
         prm_errormsg := '类型不能为空！';
         RETURN;
      END IF;
      --查询测算占比
      SELECT COUNT(*) INTO n_count FROM KEE1 WHERE BKE754 = rec_KEE1.BKE754;
      IF n_count > 0 THEN
         RETURN;
      END IF;
      --查询测算事件表
      BEGIN
         SELECT * INTO rec_ked7 FROM KED7 WHERE BKE754 = rec_KEE1.BKE754;
      EXCEPTION
         WHEN OTHERS THEN
            prm_appcode  := pkg_comm.def_err;
            prm_errormsg := '查询预算额度测算事件表出错：' || SQLERRM;
            RETURN;
      END;
      --计算测算开始期号与终止期号间隔月数
      SELECT months_between(to_date(rec_ked7.AAE001 || '01', 'yyyymm'),
                            to_date(rec_ked7.BKE772, 'yyyymm'))
        INTO n_count
        FROM dual;
      --开始月份
      n_sta_month := TO_CHAR(to_date(rec_ked7.BKE773, 'yyyymm'), 'mm');
      --循环次数计算
      CASE rec_KEE1.BKE803
         WHEN pkg_comm.bke803_year THEN
            n_basenum := 12;
            n_aae002  := to_char(last_day(to_date(rec_ked7.BKE772, 'yyyymm')), 'yyyymm');
         WHEN pkg_comm.bke803_semester THEN
            n_basenum := 6;
            IF trunc(n_sta_month, n_basenum) > 0 THEN
               n_aae002 := substr(rec_ked7.BKE772, 1, 4) || '12';
            ELSE
               n_aae002 := substr(rec_ked7.BKE772, 1, 4) || '06';
            END IF;
         WHEN pkg_comm.bke803_quarter THEN
            n_basenum := 3;
            n_aae002  := to_char(add_months(trunc(to_date(rec_ked7.BKE772, 'yyyymm'), 'Q'), 3) - 1,
                                 'yyyymm');
         WHEN pkg_comm.bke803_month THEN
            n_basenum := 1;
            n_aae002  := rec_ked7.BKE772;
         WHEN pkg_comm.bke803_total THEN
            n_basenum := 1;
            n_aae002  := rec_ked7.BKE772;
         ELSE
            NULL;
      END CASE;
      IF MOD(n_count, n_basenum) = 0 THEN
         n_count := trunc(n_count / n_basenum);
      ELSE
         n_count := trunc(n_count / n_basenum) + 1;
      END IF;
      FOR rec_KED8_cur IN cur_KED8 LOOP
         FOR i IN 0 .. n_count - 1 LOOP
            pkg_comm.prc_getDate(rec_KEE1.BKE803, --报表类型
                                 n_aae002, --统计期号
                                 n_aae030, --开始日期
                                 n_aae031); --终止日期
            rec_KEE1.BKE772 := substr(n_aae030, 1, 6); --测算开始期号
            rec_KEE1.BKE773 := substr(n_aae031, 1, 6); --测算终止期号
            IF rec_KEE1.BKE772 < rec_ked7.BKE772 THEN
               rec_KEE1.BKE772 := rec_ked7.BKE772;
            END IF;
            IF rec_KEE1.BKE773 < rec_ked7.BKE772 THEN
               rec_KEE1.BKE773 := rec_ked7.BKE772;
            END IF;
            rec_KEE1.AAE001 := substr(rec_KEE1.BKE773, 1, 4);
            --查询KED8年度结算数据
            BEGIN
               SELECT *
                 INTO rec_keD8
                 FROM KED8 --KED8(医疗机构预算额度测算过程表)
                WHERE BKE754 = rec_KED7.BKE754 --测算批次号
                  AND BKE804 = rec_KED8_cur.BKE804 --统计级别
                  AND (rec_KED8_cur.BKE804 != '4' OR akb020 = rec_KED8_cur.AKB020) --医疗机构编号
                  AND AAE001 = rec_KEE1.AAE001; --测算年度:预算上年度=当前年度
            EXCEPTION
               WHEN no_data_found THEN
                  GOTO NEXT;
               WHEN OTHERS THEN
                  prm_appcode  := pkg_comm.def_err;
                  prm_errormsg := '查询医疗机构预算额度测算过程（当前年度）出错：' || SQLERRM;
                  RETURN;
            END;
            IF substr(rec_keD8.BKE773, -2) != 12 THEN
               --取DED9测算值
               BEGIN
                  SELECT *
                    INTO rec_keD9
                    FROM KED9
                   WHERE BKE754 = rec_KED7.BKE754 --测算批次号
                     AND BKE804 = rec_KED8_cur.BKE804 --统计级别
                     AND (rec_KED8_cur.BKE804 != '4' OR akb020 = rec_KED8_cur.AKB020) --医疗机构编号
                     AND AAE001 = TO_CHAR(ADD_MONTHS(to_date(rec_keD8.AAE001, 'yyyy'), 12), 'yyyy');
               EXCEPTION
                  WHEN OTHERS THEN
                     prm_appcode  := pkg_comm.def_err;
                     prm_errormsg := '查询医疗机构预算额度测算明细出错：' || SQLERRM;
                     RETURN;
               END;
               rec_KED8.BKE935 := rec_KED9.BKE951; --预算上年度年度预估次均基金支出
               rec_KED8.BKB001 := rec_KED9.BKE953; --预算上年度年度预估出院人次
               rec_KED8.BKE938 := rec_KED9.BKE938; --预算上年度基金支出
            END IF;
            IF rec_KEE1.BKE773 <= rec_ked7.BKE773 THEN
               --查询KED6期号区间内标准值
               SELECT SUM(nvl(AKC264, 0)) AS AKC264, --医疗费总额
                      SUM(nvl(BKC135, 0)) AS BKC135, --医疗机构负担金额
                      SUM(nvl(BKB001, 0)) AS BKB001, --人次
                      SUM(CASE
                             WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '1' THEN
                              nvl(AKE039, 0) --基本医疗基金支出
                             WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '2' THEN
                              nvl(AKE029, 0) --大额医疗基金支出
                             WHEN rec_KED7.BKE933 = '1' AND rec_KED7.BKE934 = '3' THEN
                              nvl(AKE039, 0) + nvl(AKE029, 0) --基本医疗基金支出 +大额医疗基金支出
                             WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '1' THEN
                              nvl(BKB006, 0) --结算基本医疗基金实际支出
                             WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '2' THEN
                              nvl(BKB007, 0) --结算大额医疗基金实际支出
                             WHEN rec_KED7.BKE933 = '2' AND rec_KED7.BKE934 = '3' THEN
                              nvl(BKB007, 0) + nvl(BKB007, 0) --结算大额医疗基金实际支出
                             ELSE
                              0
                          END) AS BKE938
                 INTO rec_KEE1.BKE826, --费用总额
                      rec_KED6.BKC135, --医疗机构负担金额
                      rec_KEE1.BKB001, --人次
                      rec_KEE1.BKE938 --基金支出
                 FROM KED6 --KED6(医疗机构费用结算台账表)
                WHERE BAC002 = rec_KED7.BAC002
                  AND AKA130 = rec_KED7.AKA130
                  AND AAE209 >= rec_KEE1.BKE772
                  AND AAE209 <= rec_KEE1.BKE773
                  AND (bke969 = rec_KED7.BKE969 OR rec_KED7.BKE969 IS NULL) --单病种标志
                  AND NVL(AAA131, '0') != '1'
                     --试点医院
                  AND (rec_KED8_cur.BKE804 != '9' OR
                      akb020 IN (SELECT akb020 FROM kb01 WHERE AKA022 = '1'))
                     --医疗机构编号
                  AND (rec_KED8_cur.BKE804 != '4' OR akb020 = rec_KED8_cur.AKB020);
            ELSE
               --通过上年度占比预估当前值
               BEGIN
                  SELECT BKE827, --费用总额占比
                         BKE853, --人次占比
                         BKE940 --基金支出占比
                    INTO rec_KEE1_pre.BKE827, --费用总额占比
                         rec_KEE1_pre.BKE853, --人次占比
                         rec_KEE1_pre.BKE940 --基金支出占比
                    FROM KEE1
                   WHERE BKE754 = rec_KED7.BKE754 --测算批次号
                     AND BKE804 = rec_KED8_cur.BKE804 --统计级别
                     AND BKE803 = rec_KEE1.BKE803 --报表类型
                     AND BKE772 =
                         TO_CHAR(ADD_MONTHS(to_date(rec_KEE1.BKE772, 'yyyymm'), -12), 'yyyymm') --测算开始期号
                     AND BKE773 =
                         TO_CHAR(ADD_MONTHS(to_date(rec_KEE1.BKE773, 'yyyymm'), -12), 'yyyymm') --测算终止期号
                     AND (rec_KED8_cur.BKE804 != '4' OR akb020 = rec_KED8_cur.AKB020); --医疗机构编号
               EXCEPTION
                  WHEN OTHERS THEN
                     prm_appcode  := pkg_comm.def_err;
                     prm_errormsg := '查询医疗机构月度预算额度出错：' || SQLERRM;
                     RETURN;
               END;
               rec_KEE1.BKE826 := round(rec_KED8.BKE935 * rec_KED8.BKB001 * rec_KEE1_pre.BKE827); --费用总额
               rec_KED6.BKC135 := 0; --医疗机构负担金额
               rec_KEE1.BKB001 := rec_KED8.BKB001 * rec_KEE1_pre.BKE853; --人次
               rec_KEE1.BKE938 := rec_KED8.BKE938 * rec_KEE1_pre.BKE940; --基金支出
               --最后一期误差处理
               IF substr(rec_KEE1.BKE773, -2) = 12 THEN
                  SELECT SUM(bke826),
                         SUM(bkb001),
                         SUM(bke938)
                    INTO n_bke826_pre, --费用总额
                         n_bkb001_pre, --人次
                         n_bke938_pre --基金支出
                    FROM KEE1
                   WHERE BKE754 = rec_KED7.BKE754 --测算批次号
                     AND BKE804 = rec_KED8_cur.BKE804 --统计级别
                     AND BKE803 = rec_KEE1.BKE803 --报表类型
                     AND (rec_KED8_cur.BKE804 != '4' OR akb020 = rec_KED8_cur.AKB020) --医疗机构编号
                     AND AAE001 = rec_KEE1.AAE001; --年度
                  rec_KEE1.BKE826 := round(rec_KED8.BKE935 * rec_KED8.BKB001) - n_bke826_pre; --费用总额
                  rec_KEE1.BKB001 := rec_KED8.BKB001 - n_bkb001_pre; --人次
                  rec_KEE1.BKE938 := rec_KED8.BKE938 - n_bke938_pre; --基金支出
               END IF;
            END IF;
            rec_KEE1.AAZ750 := pkg_comm.fun_GetSequence('SE_AAZ750', 0, ''); --医疗机构预算额度占比ID
            rec_KEE1.AAZ747 := rec_KED8.AAZ747; --医疗机构预算额度测算事件ID
            rec_KEE1.AAZ748 := rec_KED8.AAZ748; --医疗机构预算额度测算过程ID
            rec_KEE1.BKE754 := rec_KED8.BKE754; --测算批次号
            rec_KEE1.AAE001 := rec_KED8.AAE001; --测算年度
            rec_KEE1.BKE772 := rec_KEE1.BKE772; --测算开始期号
            rec_KEE1.BKE773 := rec_KEE1.BKE773; --测算终止期号
            rec_KEE1.BKE933 := rec_KED8.BKE933; --测算数据类型
            rec_KEE1.BAC002 := rec_KED8.BAC002; --人群类别
            rec_KEE1.AKA130 := rec_KED8.AKA130; --医疗类别
            rec_KEE1.BKE934 := rec_KED8.BKE934; --基金类别
            rec_KEE1.AKA101 := rec_KED8.AKA101; --医院等级
            rec_KEE1.AKB020 := rec_KED8.AKB020; --医疗服务机构编号
            rec_KEE1.AAZ107 := rec_KED8.AAZ107; --定点医疗机构ID
            rec_KEE1.BKE826 := (rec_KEE1.BKE826 - rec_KED6.BKC135); --费用总额
            rec_KEE1.BKE827 := round((rec_KEE1.BKE826 - rec_KED6.BKC135) /
                                     (rec_KED8.BKE935 * rec_KED8.BKB001),
                                     4); --费用总额占比
            rec_KEE1.BKB001 := rec_KEE1.BKB001; --人次
            rec_KEE1.BKE853 := round(rec_KEE1.BKB001 / rec_KED8.BKB001, 4); --人次占比
            rec_KEE1.BKE938 := rec_KEE1.BKE938; --基金支出
            rec_KEE1.BKE940 := round(rec_KEE1.BKE938 / rec_KED8.BKE938, 4); --基金支出占比
            rec_KEE1.AAE013 := NULL; --备注
            rec_KEE1.BKE804 := rec_KED8.BKE804; --统计级别
            rec_KEE1.BKE803 := rec_KEE1.BKE803; --报表类型
            INSERT INTO KEE1 VALUES rec_KEE1;
            <<next>>
            n_aae002 := to_char(trunc(add_months(to_date(n_aae002, 'yyyymm'), n_basenum), 'mm'),
                                'yyyymm');
         END LOOP;
      END LOOP;
   EXCEPTION
      WHEN OTHERS THEN
         prm_appcode  := pkg_comm.def_err;
         prm_errormsg := '【pkg_a_estimates.prc_totalAmountpropControl】执行出错：' || SQLERRM;
   END prc_totalAmountpropControl;

END pkg_a_estimates;
/

