create procedure PRC_EXTRACT_KBF5(prm_bke930 IN VARCHAR2,
                                             ExtractNum OUT NUMBER,
                                             AppCode    OUT VARCHAR2,
                                             ErrorMsg   OUT VARCHAR2) is
  v_insert_num NUMBER;

BEGIN
 insert into kbf4
  SELECT se_aaz628.nextval,
         a.mdtrt_id akc190,
         c.akb020,
         a.cnt KKH114,
         a.pric BKEH31,
         a.DET_ITEM_FEE_SUMAMT BKF417,
         trim(replace(b.BKA106, '*', '')) BKA106,
         b.BKA083,
         b.bka095,
         a.opt_time ake100,
         '0' as aaa131
    FROM data_sync.fee_list_d_hosp a
   inner join kbd8 b
      on a.MED_LIST_CODG = b.bka095
     and b.aaa131 = '0'
   inner join kb01 c
      on a.FIXMEDINS_CODE = c.bkf498
   where a.vali_flag = '1'
     and to_char(a.opt_time, 'yyyyMM') =prm_bke930;
  COMMIT;
  insert into kbf5
  select se_aaz629.nextval, akb020, akc190, bke930, akc263, bkf417, aaa131
    from (select akb020,
                 akc190,
                 bke930,
                 sum(bkf417_after) akc263,
                 sum(bkf417) bkf417,
                 '0' as aaa131
            from (select akb020,
                         akc190,
                         round(bka106 / bka083, 2) * kkh114 bkf417_after,
                         bkf417,
                         to_char(ake100, 'yyyyMM') bke930
                    from kbf4 m
                   where round(bka106 / bka083, 2) != round(bkeh31, 2)
                     and bka106 != bkeh31
                     AND to_char(m.ake100, 'yyyyMM') =prm_bke930;

                  )
           group by akb020, akc190, bke930);

  v_insert_num := SQL%ROWCOUNT;
  ExtractNum   := v_insert_num;
  AppCode    := '1';

EXCEPTION
  WHEN OTHERS THEN
    AppCode  := pkg_comm.def_err;
    ErrorMsg := '抽取表KBF5有误：' || SQLERRM;
    commit;
end PRC_EXTRACT_KHA5;
/

