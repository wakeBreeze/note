create FUNCTION f_get_operation_code(AKE394 in VARCHAR2, AKE405 in VARCHAR2,AKE416 IN VARCHAR2,
                           AKE427 IN VARCHAR2,AKE438 IN VARCHAR2,AKE449 IN VARCHAR2,AKE460 IN VARCHAR2,
                           AKE403 in VARCHAR2, AKE414 in VARCHAR2,AKE425 IN VARCHAR2,
                           AKE436 IN VARCHAR2,AKE447 IN VARCHAR2,AKE458 IN VARCHAR2,AKE469 IN VARCHAR2,
                           AKA130 IN VARCHAR2,AKE304 IN VARCHAR2,AKC023 IN VARCHAR2, TYPE IN VARCHAR2,BKF242 IN VARCHAR2
)
/**
  病案编码：
                    手术1：11.9100x001
                    手术2：38.9100x601
                    手术3：12.1101
  类型为1时：
            获取当前病案手术编码组合，并且排除固定编码不进行组合。
            在排除的编码中，如果当前病案是日间手术或麻醉为全麻（全麻，01,1）的不排除，
            并且其中有些编码限定新生儿不排除。
            结果1：11.9100x001 - 12.1101（不是日间手术，不是全麻，不是新生儿）
            结果2：11.9100x001 - 38.9100x601 - 12.1101（不是日间手术，是全麻，不是新生儿）
            。。。
  类型为2时：
            进行类型1的判断，并且诊断性操作和治疗性操作手术为一二级时不聚类
            结果1：11.91 - 12.11（不是日间手术，不是全麻，不是新生儿）
            结果2：11.91 - 12.11（不是日间手术，是全麻，不是新生儿） 因为手术38.9100x601为一二级并且属于诊断性操作

*/
return VARCHAR2
as
       v_operation_code VARCHAR2(1000);
BEGIN

   -- 编码1
   IF AKE394 IS NOT NULL AND ake394 NOT LIKE '%-%' THEN
     IF TYPE = 1 THEN
       v_operation_code := f_get_code(AKE394,AKE403,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     ELSE
       v_operation_code := f_get_code2(AKE394,AKE403,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     END IF;
   END IF;


   -- 编码2
   IF AKE405 IS NOT NULL AND AKE405 NOT LIKE '%-%' THEN
     IF TYPE = 1 THEN
       v_operation_code := f_get_code(AKE405,AKE414,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     ELSE
       v_operation_code := f_get_code2(AKE405,AKE414,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     END IF;
   END IF;

   -- 编码3
   IF AKE416 IS NOT NULL AND AKE416 NOT LIKE '%-%' THEN
     IF TYPE = 1 THEN
       v_operation_code := f_get_code(AKE416,AKE425,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     ELSE
       v_operation_code := f_get_code2(AKE416,AKE425,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     END IF;
   END IF;

   -- 编码4
   IF AKE427 IS NOT NULL AND AKE427 NOT LIKE '%-%' THEN
     IF TYPE = 1 THEN
       v_operation_code := f_get_code(AKE427,AKE436,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     ELSE
       v_operation_code := f_get_code2(AKE427,AKE436,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     END IF;
   END IF;

   -- 编码5
   IF AKE438 IS NOT NULL AND AKE438 NOT LIKE '%-%' THEN
     IF TYPE = 1 THEN
       v_operation_code := f_get_code(AKE438,AKE447,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     ELSE
       v_operation_code := f_get_code2(AKE438,AKE447,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     END IF;
   END IF;

    -- 编码6
   IF AKE449 IS NOT NULL AND AKE449 NOT LIKE '%-%' THEN
     IF TYPE = 1 THEN
       v_operation_code := f_get_code(AKE449,AKE458,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     ELSE
       v_operation_code := f_get_code2(AKE449,AKE458,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     END IF;
   END IF;

    -- 编码7
   IF AKE460 IS NOT NULL AND AKE460 NOT LIKE '%-%' THEN
     IF TYPE = 1 THEN
       v_operation_code := f_get_code(AKE460,AKE469,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     ELSE
       v_operation_code := f_get_code2(AKE460,AKE469,AKA130,AKE304,AKC023,v_operation_code,BKF242);
     END IF;
   END IF;


  RETURN v_operation_code;
end f_get_operation_code;


/

