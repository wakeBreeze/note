create FUNCTION f_get_two_catalogue_code(param_code in VARCHAR2,param_operation_code in VARCHAR2
)
return VARCHAR2
AS
       v_operation_code VARCHAR2(1000);
       v_new_code kaa4.bke739%TYPE; -- 新编码
       v_flag NUMBER(1); -- 新的编码1是否存在
       v_code_version VARCHAR2(1); -- 治疗分类
       v_this_param_code VARCHAR2(1000); -- 参数（不能截取参数，所以先赋值操作）
       v_ope_code_level VARCHAR(1); -- 手术级别
       v_count1 NUMBER(1);
       v_count2 NUMBER(1);
BEGIN
   v_this_param_code := param_code;

   SELECT COUNT(1) INTO v_count1 FROM kac4 b
   WHERE  bke739 = v_this_param_code
   AND b.bke734 = 'ICD-9'
   AND bke731 = '10';

   IF v_count1 != 0 THEN
     -- 获取手术治疗分类类型
     SELECT bkf305 INTO v_code_version FROM kac4 b
     WHERE  bke739 = v_this_param_code
     AND b.bke734 = 'ICD-9'
     AND bke731 = '10';
   END IF;

   SELECT COUNT(1) INTO v_count2 FROM kh71 a
   WHERE a.ake394 = v_this_param_code;
   IF v_count2 != 0 THEN
     -- 获取当前手术级别
     SELECT ake396 INTO v_ope_code_level FROM kh71 a
     WHERE a.ake394 = v_this_param_code;
   END IF;

   -- 诊断性操作和治疗性操作并且手术为一二级时不聚类（归为保守）
   IF v_code_version IN ('1','2') AND v_ope_code_level IN ('1','2') THEN
     v_this_param_code := NULL;
   END IF;

   --IF param_operation_code IS NOT NULL THEN
    -- IF v_this_param_code IS NOT NULL THEN
    --    v_operation_code := CONCAT(param_operation_code,'-');
    -- ELSE
    --    v_operation_code := CONCAT(param_operation_code,'');
    -- END IF;
   --END IF;

   IF regexp_like(v_this_param_code,'^[0-9]{2}\.[0-9]{1}x.*') THEN
     v_operation_code := v_this_param_code;
   ELSE
     v_operation_code := substr(v_this_param_code,0,5);
   END IF;

   RETURN v_operation_code;
END;


/

