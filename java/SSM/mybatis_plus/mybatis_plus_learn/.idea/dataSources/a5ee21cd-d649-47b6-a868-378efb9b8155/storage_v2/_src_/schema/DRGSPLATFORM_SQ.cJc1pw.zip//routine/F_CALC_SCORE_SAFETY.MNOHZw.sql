create FUNCTION                 f_calc_score_safety(prm_death_rate1 IN NUMBER,
                                               prm_death_rate2 IN NUMBER,
                                               ld_score OUT NUMBER
                                             ) RETURN NUMBER AS
   ld_score_rw1 NUMBER (12, 4) ; -- 低风险得分
   ld_score_rw2 NUMBER (12, 4) ; -- 中低风险得分
BEGIN
/*
  安全得分=（低风险死亡分数 *中低风险死亡分数）开方
  低风险死亡分数：低风险死亡率为0赋值1
  0＜低风险组死亡率＜0.05%赋值0.9
  0.05%≤低风险组死亡率＜0.1%赋值0.8
  如此类推（低风险死亡率+0.05%，分值减少0.1）
  中低风险死亡分数:中低风险死亡率0赋值1
  0＜中低风险组死亡率＜0.25%赋值0.9
  0.25%≤中低风险组死亡率＜0.5%赋值0.8
  如此类推（中低风险死亡+0.25%，分值减少0.1）
*/
   -- 低风险分值计算
   if prm_death_rate1 = 0 then
    ld_score_rw1 := 1;
   else
    ld_score_rw1 :=  round((10-  prm_death_rate1 / 0.0005) /10 - 0.06 ,1);
   end if;
   -- 中低风险分值计算
      IF prm_death_rate2 = 0 THEN
       ld_score_rw2 := 1;
      else
    ld_score_rw2 := round((10-  prm_death_rate2 /0.0025) /10 - 0.06,1);
   end if;
    -- 校验分数
   if ld_score_rw1<0 or ld_score_rw2<0 then
    return 0;
   end if;
    ld_score :=round(sqrt (ld_score_rw1 * ld_score_rw2),4);
   return ld_score;
END;


/

