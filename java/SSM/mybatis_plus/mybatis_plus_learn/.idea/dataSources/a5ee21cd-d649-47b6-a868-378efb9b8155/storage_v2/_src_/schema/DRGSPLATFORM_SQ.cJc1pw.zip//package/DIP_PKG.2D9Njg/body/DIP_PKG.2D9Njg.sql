create PACKAGE BODY dip_pkg is
  PROCEDURE PRC_CALL_STATISTICS_HISTORY(prm_bke800   IN VARCHAR2, --执行期号
                                        prm_bke801   IN VARCHAR2, --执行结束期号
                                        prm_appcode  OUT NUMBER, --执行代码
                                        prm_errormsg OUT VARCHAR2 --错误信息
                                        ) IS
    d_start_bke800 DATE; --开始执行期号
    d_end_bke800   DATE; --结束执行期号
    d_curr_bke800  DATE; --当前执行期号
    d_sysdate      DATE; --抽取时间
  
  BEGIN
    d_sysdate    := sysdate;
    prm_appcode  := pkg_comm.def_ok;
    prm_errormsg := '统计成功';
  
    if prm_bke800 is null then
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := 'prm_bke800执行开始期号不能为空！';
      return;
    end if;
  
    if prm_bke801 is null then
      d_end_bke800 := to_date(prm_bke800, pkg_comm.issue_format);
    else
      d_end_bke800 := to_date(prm_bke801, pkg_comm.issue_format);
    end if;
  
    d_start_bke800 := to_date(prm_bke800, pkg_comm.issue_format);
    d_curr_bke800  := d_start_bke800;
  
    while d_curr_bke800 <= d_end_bke800 loop
    
      pkg_a_statistics_dip.prc_execute(to_char(d_curr_bke800,
                                               pkg_comm.issue_format),
                                       prm_appcode,
                                       prm_errormsg);
    
      dbms_output.put_line(to_char(d_curr_bke800, pkg_comm.issue_format));
    
      d_curr_bke800 := add_months(d_curr_bke800, 1);
    
    end loop;
    prm_appcode  := pkg_comm.def_ok;
    prm_errormsg := '统计成功';
  EXCEPTION
    WHEN OTHERS THEN
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '【PKG_COMM.PRC_CALL_STATISTICS_HISTORY】执行出错：' ||
                      SQLERRM;
    
  END PRC_CALL_STATISTICS_HISTORY;

  /*连康复病例判断*/
  PROCEDURE PRC_CALL_SERIALIZE_RECOVER(prm_checkdays IN NUMBER, --执行结束期号
                                       prm_appcode   OUT NUMBER, --执行代码
                                       prm_errormsg  OUT VARCHAR2 --错误信息
                                       ) IS
    n_checkdays NUMBER; --判断连续天数
    v_curdays   NUMBER; --满足判断
    v_index     number;
    CURSOR CUR_SERIALIZE IS
      select akb020, akc190 from KANGFULEI group by akb020, akc190;
  BEGIN
    n_checkdays  := prm_checkdays;
    prm_appcode  := pkg_comm.def_ok;
    prm_errormsg := '统计成功';
    v_index      := 0;
  
    FOR CUR_SER_RECORD IN CUR_SERIALIZE LOOP
      select count(1)
        into v_curdays
        from (with t1 as (select distinct akc221 as time_value
                            from KANGFULEI t
                           where akc190 = CUR_SER_RECORD.AKC190
                             and akb020 = CUR_SER_RECORD.AKB020
                           order by akc221)
               select gn,
                      min(time_value) start_time,
                      max(time_value) end_time,
                      count(*) days
                 from (select time_value,
                              to_number(time_value -
                                        TO_DATE('1970-01-01', 'YYYY-MM-DD')) -
                              row_number() over(order by time_value) gn
                         from t1)
                group by gn)
                where days >= 15;
    
    
      v_index := v_index + 1;
      dbms_output.put_line('' || v_index);
      IF v_curdays > 0 THEN
        insert into kha5
          (aaz925, akc190, akb020)
        values
          (se_aaz925.nextval, CUR_SER_RECORD.AKC190, CUR_SER_RECORD.AKB020);
      else
        continue;
      END IF;
      COMMIT; --提交
    
    END LOOP;
    prm_appcode  := pkg_comm.def_ok;
    prm_errormsg := '统计成功';
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '【DIP_PKG.PRC_CALL_SERIALIZE_RECOVER】执行出错：' ||
                      SQLERRM;
  END PRC_CALL_SERIALIZE_RECOVER;
  /**
  *   三目录校验中间表抽取
  *   create time 2021-03-17 by hzq
  *   modify by xx    
  */
  PROCEDURE PRC_CALL_MEDICAL_INSURANCE(prm_bke800   IN VARCHAR2, --执行期号
                                       prm_appcode  OUT NUMBER, --执行代码
                                       prm_errormsg OUT VARCHAR2 --错误信息
                                       ) is
    d_start_aae030 VARCHAR2(20); --开始执行时间
    d_end_aae031   VARCHAR2(20); --结束执行时间
    d_curr_bke800  VARCHAR2(8); --当前执行期号
    d_sysdate      DATE; --抽取时间
    s_bke803       VARCHAR2(3); --报表类型 1月报， 2季报，3半年报，4年报，5累计
  
  BEGIN
    d_curr_bke800 := prm_bke800;
    d_sysdate     := sysdate;
    s_bke803      := pkg_comm.bke803_month; --以月进行数据抽取 1月报
    --调用存储过程获取时间  
    pkg_comm.prc_getDate(s_bke803,
                         d_curr_bke800,
                         d_start_aae030,
                         d_end_aae031);
  
    --1、插入聚类结果
    insert into kkj3
      (aaz867,
       akb020,
       akc190,
       bkek35,
       bkek36,
       bkeh81,
       bkeh82,
       bkf044,
       bkej33,
       bkek46,
       bkek47,
       bkeh88,
       bkf217,
       bke930,
       kkh039,
       aae036,
       bke709)
      select SE_AAZ867.nextval as aaz867, a.*
        from (select akb020,
                     akc190,
                     bkek35,
                     bkek36,
                     bkeh81,
                     bkeh82,
                     bkf044,
                     bkej33,
                     sum(nvl(bkek46, 0)) as bkek46, --数量
                     sum(nvl(bkek47, 0)) as bkek47, --收费金额
                     bkeh88,
                     bkf217,
                     d_curr_bke800 as bke930,
                     '1' kkh039,
                     d_sysdate,
                     '0' as bke709
                from KH40
               where bkeh88 != '3'
                 and bkeh81 not in (select bkeh81 from kha4)
                 and aae040 >= to_date(d_start_aae030 || ' 00:00:00',
                                       'yyyy-MM-dd HH24:mi:ss')
                 and aae040 <= to_date(d_end_aae031 || ' 23:59:59',
                                       'yyyy-MM-dd HH24:mi:ss')
              --剔除需重复收费编码
               group by akb020,
                        akc190,
                        bkek35,
                        bkek36,
                        bkeh81,
                        bkeh82,
                        bkf044,
                        bkej33,
                        bkeh88,
                        bkf217) a;
  
    --2、重复收费校验数据  
    insert into kkj3
      (aaz867,
       akb020,
       akc190,
       bkek35,
       bkek36,
       bkeh81,
       bkeh82,
       bkf044,
       bkej33,
       bkek46,
       bkek47,
       bkeh88,
       bkf217,
       bke930,
       kkh039,
       bkek45,
       aae036,
       bke709)
      select SE_AAZ867.nextval as aaz867, a.*
        from (select akb020,
                     akc190,
                     bkek35,
                     bkek36,
                     bkeh81,
                     bkeh82,
                     bkf044,
                     bkej33,
                     bkek46,
                     bkek47,
                     bkeh88,
                     bkf217,
                     d_curr_bke800 as bke930,
                     '2' kkh039,
                     bkek45,
                     d_sysdate,
                     '0' as bke709
                from KH40
               where bkeh88 != '3'
                 and aae040 >= to_date(d_start_aae030 || ' 00:00:00',
                                       'yyyy-MM-dd HH24:mi:ss')
                 and aae040 <= to_date(d_end_aae031 || ' 23:59:59',
                                       'yyyy-MM-dd HH24:mi:ss')
                 and bkeh81 in (select bkeh81 from kha4)) a;
  
   -- 同步更新诊疗项目重复收费的单位             
    update kkj3 
    set bkeh92 = '时' 
    where bkf217 = '2' and bkeh81 in (select bkeh81 from kha4 where bkg001 = '1');
  
    prm_appcode  := pkg_comm.def_ok;
    prm_errormsg := '统计成功';
    --提交事务
    commit;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      prm_appcode  := pkg_comm.def_err;
      prm_errormsg := '【DIP_PKG.PRC_CALL_MEDICAL_INSURANCE】执行出错：' ||
                      SQLERRM;
  END PRC_CALL_MEDICAL_INSURANCE;
end dip_pkg;
/

