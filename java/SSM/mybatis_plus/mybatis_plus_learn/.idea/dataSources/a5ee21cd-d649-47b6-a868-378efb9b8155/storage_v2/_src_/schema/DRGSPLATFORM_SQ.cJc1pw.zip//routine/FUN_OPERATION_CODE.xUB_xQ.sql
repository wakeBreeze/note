create function fun_operation_code
return number
is
retValue number;
begin
  retValue:=fun_operation_code_kec1();
  retValue:=fun_operation_code_kec2();
  return retValue;
end fun_operation_code;


/

