package com.zx.service.write.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zx.mapper.write.Ka92WriteMapper;
import com.zx.mapper.write.Ka94WriteMapper;
import com.zx.pojo.Ka94;
import com.zx.service.write.Ka94WriteService;
import org.springframework.stereotype.Service;

/**
 * @Description: com.zx.service.write.impl
 * @version: 1.0
 */
@Service
public class Ka94WriteServiceImpl extends ServiceImpl<Ka94WriteMapper, Ka94> implements Ka94WriteService {
}
