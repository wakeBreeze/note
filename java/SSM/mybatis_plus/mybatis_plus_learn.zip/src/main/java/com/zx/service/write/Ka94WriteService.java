package com.zx.service.write;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zx.pojo.Ka94;

/**
 * @Description: com.zx.service.write
 * @version: 1.0
 */
public interface Ka94WriteService extends IService<Ka94> {
}
