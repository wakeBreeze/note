package com.zx.service.write;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zx.pojo.Ka92;

/**
 * @Description: com.zx.service.write
 * @version: 1.0
 */
public interface Ka92WriteService extends IService<Ka92> {
}
