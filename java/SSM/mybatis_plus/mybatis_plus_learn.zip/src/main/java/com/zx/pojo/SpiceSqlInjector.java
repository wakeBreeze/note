package com.zx.pojo;

import com.baomidou.mybatisplus.core.injector.AbstractMethod;
import com.baomidou.mybatisplus.core.injector.DefaultSqlInjector;

import java.util.List;

/**
 * @Description: com.zx.pojo
 * @version: 1.0
 */
public class SpiceSqlInjector extends DefaultSqlInjector {
    @Override
    public List<AbstractMethod> getMethodList() {
        return super.getMethodList();
    }
}
