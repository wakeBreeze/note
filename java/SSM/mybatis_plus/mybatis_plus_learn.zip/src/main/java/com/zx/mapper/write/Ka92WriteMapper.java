package com.zx.mapper.write;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zx.pojo.Ka92;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description: com.zx.mapper.write
 * @version: 1.0
 */
@Mapper
public interface Ka92WriteMapper extends BaseMapper<Ka92> {

}
