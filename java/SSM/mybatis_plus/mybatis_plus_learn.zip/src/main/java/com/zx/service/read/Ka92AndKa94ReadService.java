package com.zx.service.read;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zx.mapper.read.Ka92AndKa94ReadMapper;
import com.zx.pojo.Ka92AndKa94;

import java.util.List;

/**
 * @Description: com.zx.service.read
 * @version: 1.0
 */
public interface Ka92AndKa94ReadService{
    void getKa92AndKa94s();
}
