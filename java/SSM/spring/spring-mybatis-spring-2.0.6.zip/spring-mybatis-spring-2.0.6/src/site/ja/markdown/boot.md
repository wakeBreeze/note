<a name="Using_Spring_Boot"></a>
# Using Spring Boot

詳細は [MyBatis Spring-boot-starter](http://www.mybatis.org/spring-boot-starter/mybatis-spring-boot-autoconfigure) のドキュメントを参照してください。
