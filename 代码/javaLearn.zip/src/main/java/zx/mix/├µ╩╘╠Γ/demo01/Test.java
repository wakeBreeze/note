package zx.mix.面试题.demo01;

/**
 * @Description: zx.mix.面试题.demo01
 * @version: 1.0
 */
public class Test {
    public static void main(String[] args) {
        //Double.MIN_VALUE
        System.out.println(Math.max(Double.MIN_VALUE,0.0d));

        //
    }
}
