package zx.normal.Enum.枚举加接口;

/**
 * @Description: zx.normal.Enum.枚举加接口
 * @version: 1.0
 */
public interface RoleOperation {
    String op();// 表示某个角色可以做哪些op操作
}
