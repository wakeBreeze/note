package zx.normal.Enum.枚举与设计模式.枚举实现策略模式;

/**
 * @Description: zx.normal.Enum.枚举与设计模式.枚举实现策略模式
 * @version: 1.0
 */
public interface Calculator {
    Double execute(Double x,Double y);
}
